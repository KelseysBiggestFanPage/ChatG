create table if not exists public.wishlist_unlock_attempts (
  id uuid primary key default gen_random_uuid(),

  wishlist_id uuid not null
    references public.wishlists(id)
    on delete cascade,

  visitor_key text not null,

  failed_attempts integer not null default 0,

  window_started_at timestamptz not null default now(),

  blocked_until timestamptz,

  created_at timestamptz not null default now(),

  updated_at timestamptz not null default now(),

  constraint wishlist_unlock_attempts_failed_attempts_valid
    check (failed_attempts >= 0),

  constraint wishlist_unlock_attempts_unique_visitor
    unique (wishlist_id, visitor_key)
);

create index if not exists
wishlist_unlock_attempts_wishlist_id_index
on public.wishlist_unlock_attempts (wishlist_id);

create index if not exists
wishlist_unlock_attempts_updated_at_index
on public.wishlist_unlock_attempts (updated_at);

alter table public.wishlist_unlock_attempts
enable row level security;

revoke all
on table public.wishlist_unlock_attempts
from anon;

revoke all
on table public.wishlist_unlock_attempts
from authenticated;

grant select, insert, update, delete
on table public.wishlist_unlock_attempts
to service_role;
