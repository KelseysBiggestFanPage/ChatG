create or replace function public.handle_wishlist_unlock_attempt(
  p_wishlist_id uuid,
  p_visitor_key text,
  p_code_correct boolean
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_now timestamptz := now();
  v_attempt public.wishlist_unlock_attempts%rowtype;
  v_failed_attempts integer;
  v_block_minutes integer := 0;
  v_blocked_until timestamptz := null;
  v_window_started_at timestamptz;
begin
  if p_wishlist_id is null
     or p_visitor_key is null
     or length(trim(p_visitor_key)) < 16 then
    return jsonb_build_object(
      'allowed', false,
      'blocked', false,
      'invalid', true
    );
  end if;

  insert into public.wishlist_unlock_attempts (
    wishlist_id,
    visitor_key,
    failed_attempts,
    window_started_at,
    blocked_until,
    updated_at
  )
  values (
    p_wishlist_id,
    p_visitor_key,
    0,
    v_now,
    null,
    v_now
  )
  on conflict (wishlist_id, visitor_key)
  do nothing;

  select *
  into v_attempt
  from public.wishlist_unlock_attempts
  where wishlist_id = p_wishlist_id
    and visitor_key = p_visitor_key
  for update;

  if v_attempt.blocked_until is not null
     and v_attempt.blocked_until > v_now then
    v_block_minutes :=
      case
        when v_attempt.failed_attempts >= 15 then 60
        when v_attempt.failed_attempts >= 10 then 15
        else 5
      end;

    return jsonb_build_object(
      'allowed', false,
      'blocked', true,
      'failed_attempts', v_attempt.failed_attempts,
      'block_minutes', v_block_minutes,
      'blocked_until', v_attempt.blocked_until
    );
  end if;

  if p_code_correct then
    delete from public.wishlist_unlock_attempts
    where wishlist_id = p_wishlist_id
      and visitor_key = p_visitor_key;

    return jsonb_build_object(
      'allowed', true,
      'blocked', false,
      'failed_attempts', 0,
      'block_minutes', 0
    );
  end if;

  if v_attempt.window_started_at <= v_now - interval '1 hour' then
    v_failed_attempts := 1;
    v_window_started_at := v_now;
  else
    v_failed_attempts := v_attempt.failed_attempts + 1;
    v_window_started_at := v_attempt.window_started_at;
  end if;

  if v_failed_attempts % 5 = 0 then
    v_block_minutes :=
      case
        when v_failed_attempts >= 15 then 60
        when v_failed_attempts >= 10 then 15
        else 5
      end;

    v_blocked_until :=
      v_now + make_interval(mins => v_block_minutes);
  end if;

  update public.wishlist_unlock_attempts
  set
    failed_attempts = v_failed_attempts,
    window_started_at = v_window_started_at,
    blocked_until = v_blocked_until,
    updated_at = v_now
  where wishlist_id = p_wishlist_id
    and visitor_key = p_visitor_key;

  return jsonb_build_object(
    'allowed', false,
    'blocked', v_block_minutes > 0,
    'failed_attempts', v_failed_attempts,
    'block_minutes', v_block_minutes,
    'blocked_until', v_blocked_until
  );
end;
$$;

revoke all
on function public.handle_wishlist_unlock_attempt(
  uuid,
  text,
  boolean
)
from public, anon, authenticated;

grant execute
on function public.handle_wishlist_unlock_attempt(
  uuid,
  text,
  boolean
)
to service_role;
