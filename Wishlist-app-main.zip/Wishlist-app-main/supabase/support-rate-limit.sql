create or replace function public.check_support_submission_rate_limit(
  p_visitor_key text,
  p_limit integer default 5,
  p_window_seconds integer default 3600
)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  v_now timestamptz := now();
  v_submission_count integer;
begin
  if p_visitor_key is null
     or length(trim(p_visitor_key)) < 16
     or p_limit < 1
     or p_window_seconds < 1 then
    return false;
  end if;

  insert into public.support_submission_attempts (
    visitor_key,
    submission_count,
    window_started_at,
    blocked_until,
    updated_at
  )
  values (
    p_visitor_key,
    1,
    v_now,
    null,
    v_now
  )
  on conflict (visitor_key)
  do update set
    submission_count =
      case
        when public.support_submission_attempts.window_started_at
          <= v_now - make_interval(secs => p_window_seconds)
        then 1
        else public.support_submission_attempts.submission_count + 1
      end,

    window_started_at =
      case
        when public.support_submission_attempts.window_started_at
          <= v_now - make_interval(secs => p_window_seconds)
        then v_now
        else public.support_submission_attempts.window_started_at
      end,

    blocked_until =
      case
        when public.support_submission_attempts.window_started_at
          <= v_now - make_interval(secs => p_window_seconds)
        then null

        when public.support_submission_attempts.submission_count + 1
          > p_limit
        then public.support_submission_attempts.window_started_at
          + make_interval(secs => p_window_seconds)

        else null
      end,

    updated_at = v_now

  returning submission_count
  into v_submission_count;

  return v_submission_count <= p_limit;
end;
$$;

revoke all
on function public.check_support_submission_rate_limit(
  text,
  integer,
  integer
)
from public, anon, authenticated;

grant execute
on function public.check_support_submission_rate_limit(
  text,
  integer,
  integer
)
to service_role;
