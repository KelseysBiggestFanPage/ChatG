-- Run only AFTER the per-gift address application code has been deployed and tested.
-- Delivery details must live on gifts.shipping_address from this point forward.

alter table public.wishlists
  drop column if exists shipping_address;
