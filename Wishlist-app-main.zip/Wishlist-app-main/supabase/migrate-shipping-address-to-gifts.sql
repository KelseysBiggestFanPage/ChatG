-- Add per-gift delivery details before deploying the matching application code.
-- Safe to run once; it preserves existing gift-specific values.

alter table public.gifts
  add column if not exists shipping_address text;

do $$
begin
  if exists (
    select 1
    from information_schema.columns
    where table_schema = 'public'
      and table_name = 'wishlists'
      and column_name = 'shipping_address'
  ) then
    execute $migrate$
      update public.gifts g
      set shipping_address = nullif(trim(w.shipping_address), '')
      from public.wishlists w
      where w.id = g.wishlist_id
        and nullif(trim(g.shipping_address), '') is null
        and nullif(trim(w.shipping_address), '') is not null
    $migrate$;
  end if;
end;
$$;
