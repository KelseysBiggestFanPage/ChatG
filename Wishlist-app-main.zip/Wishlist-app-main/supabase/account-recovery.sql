alter table public.deleted_wishlists
add column if not exists account_archive_id uuid
references public.deleted_accounts(id)
on delete cascade;

create index if not exists
deleted_wishlists_account_archive_id_index
on public.deleted_wishlists (account_archive_id);


create or replace function public.archive_account_for_deletion(
  p_user_id uuid,
  p_email text,
  p_auth_created_at timestamptz,
  p_deleted_by text default 'self'
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_archive_id uuid;
  v_display_name text;
  v_profile_snapshot jsonb;
  v_wishlists_snapshot jsonb;
begin
  if p_user_id is null then
    raise exception 'missing_user_id';
  end if;

  if nullif(trim(p_email), '') is null then
    raise exception 'missing_email';
  end if;

  if p_deleted_by not in (
    'self',
    'admin'
  ) then
    raise exception 'invalid_deleted_by';
  end if;

  select
    p.display_name,
    to_jsonb(p)
  into
    v_display_name,
    v_profile_snapshot
  from public.profiles p
  where p.id = p_user_id;

  if v_profile_snapshot is null then
    v_profile_snapshot := '{}'::jsonb;
  end if;

  select coalesce(
    jsonb_agg(
      jsonb_build_object(
        'wishlist',
        to_jsonb(w),

        'gifts',
        coalesce(
          (
            select jsonb_agg(
              to_jsonb(g)
              order by g.created_at
            )
            from public.gifts g
            where g.wishlist_id = w.id
          ),
          '[]'::jsonb
        ),

        'reservations',
        coalesce(
          (
            select jsonb_agg(
              to_jsonb(r)
              order by r.created_at
            )
            from public.reservations r
            where r.wishlist_id = w.id
          ),
          '[]'::jsonb
        )
      )
      order by w.created_at
    ),
    '[]'::jsonb
  )
  into v_wishlists_snapshot
  from public.wishlists w
  where w.owner_id = p_user_id;

  delete from public.deleted_accounts
  where original_user_id = p_user_id
    and restored_at is null;

  insert into public.deleted_accounts (
    original_user_id,
    email,
    display_name,
    auth_created_at,
    deleted_by,
    profile_snapshot,
    wishlists_snapshot,
    deleted_at,
    recover_until
  )
  values (
    p_user_id,
    lower(trim(p_email)),
    v_display_name,
    p_auth_created_at,
    p_deleted_by,
    v_profile_snapshot,
    v_wishlists_snapshot,
    now(),
    now() + interval '90 days'
  )
  returning id
  into v_archive_id;

  insert into public.deleted_wishlists (
    original_wishlist_id,
    original_owner_id,
    owner_email,
    title,
    original_slug,
    was_live,
    wishlist_snapshot,
    gifts_snapshot,
    reservations_snapshot,
    deleted_by,
    deleted_at,
    recover_until,
    account_archive_id
  )
  select
    w.id,
    w.owner_id,
    lower(trim(p_email)),
    w.title,
    w.slug,
    w.is_live,

    to_jsonb(w),

    coalesce(
      (
        select jsonb_agg(
          to_jsonb(g)
          order by g.created_at
        )
        from public.gifts g
        where g.wishlist_id = w.id
      ),
      '[]'::jsonb
    ),

    coalesce(
      (
        select jsonb_agg(
          to_jsonb(r)
          order by r.created_at
        )
        from public.reservations r
        where r.wishlist_id = w.id
      ),
      '[]'::jsonb
    ),

    'account_delete',
    now(),
    now() + interval '90 days',
    v_archive_id

  from public.wishlists w
  where w.owner_id = p_user_id;

  return v_archive_id;
end;
$$;


create or replace function public.discard_account_deletion_archive(
  p_archive_id uuid,
  p_user_id uuid
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  delete from public.deleted_accounts
  where id = p_archive_id
    and original_user_id = p_user_id
    and restored_at is null;
end;
$$;


revoke all
on function public.archive_account_for_deletion(
  uuid,
  text,
  timestamptz,
  text
)
from public;

revoke all
on function public.archive_account_for_deletion(
  uuid,
  text,
  timestamptz,
  text
)
from anon;

revoke all
on function public.archive_account_for_deletion(
  uuid,
  text,
  timestamptz,
  text
)
from authenticated;

grant execute
on function public.archive_account_for_deletion(
  uuid,
  text,
  timestamptz,
  text
)
to service_role;


revoke all
on function public.discard_account_deletion_archive(
  uuid,
  uuid
)
from public;

revoke all
on function public.discard_account_deletion_archive(
  uuid,
  uuid
)
from anon;

revoke all
on function public.discard_account_deletion_archive(
  uuid,
  uuid
)
from authenticated;

grant execute
on function public.discard_account_deletion_archive(
  uuid,
  uuid
)
to service_role;
