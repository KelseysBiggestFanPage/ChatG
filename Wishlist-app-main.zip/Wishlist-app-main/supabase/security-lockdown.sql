-- GoWishlist security lockdown
-- Safe to run on the existing production database.
-- This does NOT delete any user data.
-- It only removes two unnecessary direct database capabilities.

-- =========================================================
-- 1. Wishlists
-- Owners should not be able to hard-delete wishlists directly.
--
-- GoWishlist wishlist deletion goes through the
-- archive_and_delete_wishlist recovery flow instead.
-- =========================================================

drop policy if exists
"Users can delete their own wishlists"
on public.wishlists;

revoke delete
on table public.wishlists
from anon, authenticated;


-- =========================================================
-- 2. Reservations
-- Wishlist owners need to VIEW reservations and may DELETE
-- them by contacting the wishlist owner.
--
-- They do NOT need direct UPDATE access.
-- Receipt/tracking updates are handled server-side.
-- =========================================================

drop policy if exists
"Owners can update reservations"
on public.reservations;

revoke update
on table public.reservations
from anon, authenticated;
