create or replace function public.archive_and_delete_wishlist(
  p_wishlist_id uuid,
  p_owner_id uuid,
  p_owner_email text,
  p_deleted_by text default 'owner'
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_wishlist public.wishlists%rowtype;
  v_gifts jsonb;
  v_reservations jsonb;
  v_archive_id uuid;
begin
  if p_deleted_by not in (
    'owner',
    'admin',
    'account_delete',
    'account_reset'
  ) then
    raise exception 'invalid_deleted_by';
  end if;

  select *
  into v_wishlist
  from public.wishlists
  where id = p_wishlist_id
    and owner_id = p_owner_id
  for update;

  if not found then
    raise exception 'wishlist_not_found';
  end if;

  select coalesce(
    jsonb_agg(
      to_jsonb(g)
      order by g.created_at
    ),
    '[]'::jsonb
  )
  into v_gifts
  from public.gifts g
  where g.wishlist_id = v_wishlist.id;

  select coalesce(
    jsonb_agg(
      to_jsonb(r)
      order by r.created_at
    ),
    '[]'::jsonb
  )
  into v_reservations
  from public.reservations r
  where r.wishlist_id = v_wishlist.id;

  insert into public.deleted_wishlists (
    original_wishlist_id,
    original_owner_id,
    owner_email,
    title,
    original_slug,
    was_live,
    wishlist_snapshot,
    gifts_snapshot,
    reservations_snapshot,
    deleted_by,
    deleted_at,
    recover_until
  )
  values (
    v_wishlist.id,
    v_wishlist.owner_id,
    nullif(trim(p_owner_email), ''),
    v_wishlist.title,
    v_wishlist.slug,
    v_wishlist.is_live,
    to_jsonb(v_wishlist),
    v_gifts,
    v_reservations,
    p_deleted_by,
    now(),
    now() + interval '90 days'
  )
  returning id
  into v_archive_id;

  delete from public.wishlists
  where id = v_wishlist.id
    and owner_id = v_wishlist.owner_id;

  return v_archive_id;
end;
$$;

revoke all
on function public.archive_and_delete_wishlist(
  uuid,
  uuid,
  text,
  text
)
from public;

revoke all
on function public.archive_and_delete_wishlist(
  uuid,
  uuid,
  text,
  text
)
from anon;

revoke all
on function public.archive_and_delete_wishlist(
  uuid,
  uuid,
  text,
  text
)
from authenticated;

grant execute
on function public.archive_and_delete_wishlist(
  uuid,
  uuid,
  text,
  text
)
to service_role;
