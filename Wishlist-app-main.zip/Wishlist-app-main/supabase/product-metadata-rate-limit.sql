create table if not exists public.product_metadata_rate_limits (
  user_id uuid primary key references auth.users(id) on delete cascade,
  request_count integer not null default 0,
  window_started_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.product_metadata_rate_limits enable row level security;

revoke all on table public.product_metadata_rate_limits
from anon, authenticated;

create or replace function public.check_product_metadata_rate_limit(
  p_user_id uuid,
  p_limit integer default 30,
  p_window_seconds integer default 60
)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  v_now timestamptz := now();
  v_request_count integer;
begin
  insert into public.product_metadata_rate_limits (
    user_id,
    request_count,
    window_started_at,
    updated_at
  )
  values (
    p_user_id,
    1,
    v_now,
    v_now
  )
  on conflict (user_id)
  do update set
    request_count =
      case
        when product_metadata_rate_limits.window_started_at
          <= v_now - make_interval(secs => p_window_seconds)
        then 1
        else product_metadata_rate_limits.request_count + 1
      end,
    window_started_at =
      case
        when product_metadata_rate_limits.window_started_at
          <= v_now - make_interval(secs => p_window_seconds)
        then v_now
        else product_metadata_rate_limits.window_started_at
      end,
    updated_at = v_now
  returning request_count
  into v_request_count;

  return v_request_count <= p_limit;
end;
$$;

revoke all on function public.check_product_metadata_rate_limit(
  uuid,
  integer,
  integer
)
from public, anon, authenticated;

grant execute on function public.check_product_metadata_rate_limit(
  uuid,
  integer,
  integer
)
to service_role;
