create or replace function public.archive_and_reset_user_data(
  p_user_id uuid,
  p_owner_email text
)
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  v_wishlist public.wishlists%rowtype;
  v_gifts jsonb;
  v_reservations jsonb;
  v_archived_count integer := 0;
begin
  if p_user_id is null then
    raise exception 'missing_user_id';
  end if;

  if not exists (
    select 1
    from auth.users
    where id = p_user_id
  ) then
    raise exception 'user_not_found';
  end if;

  for v_wishlist in
    select *
    from public.wishlists
    where owner_id = p_user_id
    order by created_at asc
    for update
  loop
    select coalesce(
      jsonb_agg(
        to_jsonb(g)
        order by g.created_at
      ),
      '[]'::jsonb
    )
    into v_gifts
    from public.gifts g
    where g.wishlist_id =
      v_wishlist.id;

    select coalesce(
      jsonb_agg(
        to_jsonb(r)
        order by r.created_at
      ),
      '[]'::jsonb
    )
    into v_reservations
    from public.reservations r
    where r.wishlist_id =
      v_wishlist.id;

    insert into public.deleted_wishlists (
      original_wishlist_id,
      original_owner_id,
      owner_email,
      title,
      original_slug,
      was_live,
      wishlist_snapshot,
      gifts_snapshot,
      reservations_snapshot,
      deleted_by,
      deleted_at,
      recover_until,
      account_archive_id
    )
    values (
      v_wishlist.id,
      v_wishlist.owner_id,
      nullif(
        lower(
          trim(
            coalesce(
              p_owner_email,
              ''
            )
          )
        ),
        ''
      ),
      v_wishlist.title,
      v_wishlist.slug,
      v_wishlist.is_live,
      to_jsonb(v_wishlist),
      v_gifts,
      v_reservations,
      'account_reset',
      now(),
      now() + interval '90 days',
      null
    );

    delete from public.wishlists
    where id = v_wishlist.id
      and owner_id =
        p_user_id;

    v_archived_count :=
      v_archived_count + 1;
  end loop;

  return v_archived_count;
end;
$$;


revoke all
on function public.archive_and_reset_user_data(
  uuid,
  text
)
from public;

revoke all
on function public.archive_and_reset_user_data(
  uuid,
  text
)
from anon;

revoke all
on function public.archive_and_reset_user_data(
  uuid,
  text
)
from authenticated;

grant execute
on function public.archive_and_reset_user_data(
  uuid,
  text
)
to service_role;
