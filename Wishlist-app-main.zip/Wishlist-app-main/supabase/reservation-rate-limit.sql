create table if not exists public.reservation_rate_limits (
  visitor_key text primary key,
  request_count integer not null default 0,
  window_started_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.reservation_rate_limits
enable row level security;

revoke all
on table public.reservation_rate_limits
from anon, authenticated;

create or replace function public.check_reservation_rate_limit(
  p_visitor_key text,
  p_limit integer default 30,
  p_window_seconds integer default 600
)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  v_now timestamptz := now();
  v_request_count integer;
begin
  if p_visitor_key is null
     or length(trim(p_visitor_key)) < 16
     or p_limit < 1
     or p_window_seconds < 1 then
    return false;
  end if;

  insert into public.reservation_rate_limits (
    visitor_key,
    request_count,
    window_started_at,
    updated_at
  )
  values (
    p_visitor_key,
    1,
    v_now,
    v_now
  )
  on conflict (visitor_key)
  do update set
    request_count =
      case
        when reservation_rate_limits.window_started_at
          <= v_now - make_interval(secs => p_window_seconds)
        then 1
        else reservation_rate_limits.request_count + 1
      end,
    window_started_at =
      case
        when reservation_rate_limits.window_started_at
          <= v_now - make_interval(secs => p_window_seconds)
        then v_now
        else reservation_rate_limits.window_started_at
      end,
    updated_at = v_now
  returning request_count
  into v_request_count;

  return v_request_count <= p_limit;
end;
$$;

revoke all
on function public.check_reservation_rate_limit(
  text,
  integer,
  integer
)
from public, anon, authenticated;

grant execute
on function public.check_reservation_rate_limit(
  text,
  integer,
  integer
)
to service_role;
