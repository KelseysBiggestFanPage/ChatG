create table if not exists public.gifts (
  id uuid primary key default gen_random_uuid(),
  wishlist_id uuid not null references public.wishlists(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  product_url text not null,
  image_url text,
  price numeric(10, 2),
  description text,
  instructions text,
  shipping_address text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.gifts add column if not exists shipping_address text;

create index if not exists gifts_wishlist_id_index
on public.gifts (wishlist_id);

create index if not exists gifts_owner_id_index
on public.gifts (owner_id);

alter table public.gifts enable row level security;

create policy "Users can view gifts in their own wishlists"
on public.gifts
for select
to authenticated
using (auth.uid() = owner_id);

create policy "Users can add gifts to their own wishlists"
on public.gifts
for insert
to authenticated
with check (
  auth.uid() = owner_id
  and exists (
    select 1
    from public.wishlists
    where wishlists.id = gifts.wishlist_id
    and wishlists.owner_id = auth.uid()
  )
);

create policy "Users can update gifts in their own wishlists"
on public.gifts
for update
to authenticated
using (auth.uid() = owner_id)
with check (
  auth.uid() = owner_id
  and exists (
    select 1
    from public.wishlists
    where wishlists.id = gifts.wishlist_id
    and wishlists.owner_id = auth.uid()
  )
);

create policy "Users can delete gifts in their own wishlists"
on public.gifts
for delete
to authenticated
using (auth.uid() = owner_id);
