function normalizeSiteUrl(
  value: string | undefined
) {
  const trimmed = value
    ?.trim()
    .replace(/\/+$/, "");

  if (!trimmed) {
    return "";
  }

  if (
    trimmed.startsWith("http://") ||
    trimmed.startsWith("https://")
  ) {
    return trimmed;
  }

  return `https://${trimmed}`;
}

const CANONICAL_SITE_URL = "https://www.gowishlist.org";

export function getSiteUrl() {
  const configuredUrl = normalizeSiteUrl(
    process.env.NEXT_PUBLIC_SITE_URL
  );
  const isProduction = process.env.VERCEL_ENV === "production";

  if (configuredUrl) {
    if (isProduction) {
      try {
        const configuredHost = new URL(configuredUrl).hostname.toLowerCase();
        // If the production environment variable still contains the old Vercel
        // URL, prefer GoWishlist's custom domain for generated links.
        if (configuredHost.endsWith(".vercel.app")) {
          return CANONICAL_SITE_URL;
        }
      } catch {
        // normalizeSiteUrl already checks the scheme; fall through below.
      }
    }
    return configuredUrl;
  }

  if (process.env.NODE_ENV === "development") {
    return "http://localhost:3000";
  }

  if (isProduction) {
    return CANONICAL_SITE_URL;
  }

  // Preview deployments can use their own URL. The production deployment
  // above always prefers the public custom domain.
  const deploymentUrl = normalizeSiteUrl(process.env.VERCEL_URL);
  if (deploymentUrl) {
    return deploymentUrl;
  }

  const productionVercelUrl = normalizeSiteUrl(
    process.env.VERCEL_PROJECT_PRODUCTION_URL
  );
  if (productionVercelUrl) {
    return productionVercelUrl;
  }

  return CANONICAL_SITE_URL;
}

export function getWishlistUrl(
  slug: string
) {
  return `${getSiteUrl()}/wishlist/${encodeURIComponent(
    slug
  )}`;
}
