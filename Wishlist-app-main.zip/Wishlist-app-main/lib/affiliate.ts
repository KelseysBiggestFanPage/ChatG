const DEFAULT_AMAZON_ASSOCIATE_TAG = "gowishlist-20";

function getAmazonAssociateTag() {
  return (
    process.env.AMAZON_ASSOCIATE_TAG?.trim() ||
    DEFAULT_AMAZON_ASSOCIATE_TAG
  );
}

function parseUrl(value: string) {
  const trimmed = value.trim();

  if (!trimmed) {
    return null;
  }

  try {
    return new URL(trimmed);
  } catch {
    try {
      return new URL(`https://${trimmed}`);
    } catch {
      return null;
    }
  }
}

function isAmazonComHost(hostname: string) {
  const host = hostname.toLowerCase();

  return (
    host === "amazon.com" ||
    host.endsWith(".amazon.com")
  );
}

function isValidAsin(value: string) {
  return /^[A-Z0-9]{10}$/i.test(value);
}

function safeDecodePathname(pathname: string) {
  try {
    return decodeURIComponent(pathname);
  } catch {
    return pathname;
  }
}

export function extractAmazonAsin(
  productUrl: string
) {
  try {
    const url = parseUrl(productUrl);

    if (!url) {
      return null;
    }

    if (!isAmazonComHost(url.hostname)) {
      return null;
    }

    const pathname = safeDecodePathname(
      url.pathname
    );

    const patterns = [
      /\/dp\/([A-Z0-9]{10})(?:[/?]|$)/i,
      /\/gp\/product\/([A-Z0-9]{10})(?:[/?]|$)/i,
      /\/gp\/aw\/d\/([A-Z0-9]{10})(?:[/?]|$)/i,
      /\/gp\/offer-listing\/([A-Z0-9]{10})(?:[/?]|$)/i,
      /\/product\/([A-Z0-9]{10})(?:[/?]|$)/i,
      /\/exec\/obidos\/ASIN\/([A-Z0-9]{10})(?:[/?]|$)/i,
      /\/o\/ASIN\/([A-Z0-9]{10})(?:[/?]|$)/i,
    ];

    for (const pattern of patterns) {
      const match = pathname.match(pattern);

      if (
        match?.[1] &&
        isValidAsin(match[1])
      ) {
        return match[1].toUpperCase();
      }
    }

    const queryAsin =
      url.searchParams.get("asin") ||
      url.searchParams.get("ASIN");

    if (
      queryAsin &&
      isValidAsin(queryAsin)
    ) {
      return queryAsin.toUpperCase();
    }

    return null;
  } catch {
    return null;
  }
}

export function isAmazonProductUrl(
  productUrl: string
) {
  try {
    return Boolean(
      extractAmazonAsin(productUrl)
    );
  } catch {
    return false;
  }
}

export function getAffiliateUrl(
  productUrl: string
) {
  const originalUrl =
    productUrl.trim();

  if (!originalUrl) {
    return originalUrl;
  }

  try {
    const asin =
      extractAmazonAsin(originalUrl);

    if (!asin) {
      return originalUrl;
    }

    const associateTag =
      getAmazonAssociateTag();

    return `https://www.amazon.com/dp/${asin}?tag=${encodeURIComponent(
      associateTag
    )}`;
  } catch {
    return originalUrl;
  }
}
