const blockedWords = [
  "fuck",
  "fucker",
  "fucking",
  "shit",
  "bitch",
  "cunt",
  "cock",
  "pussy",
  "asshole",
  "motherfucker",
  "nigger",
  "nigga",
  "faggot",
  "retard",
];

function normalizeLeetspeak(value: string) {
  return value
    .toLowerCase()
    .replace(/[@4]/g, "a")
    .replace(/[3]/g, "e")
    .replace(/[1!|]/g, "i")
    .replace(/[0]/g, "o")
    .replace(/[$5]/g, "s")
    .replace(/[7]/g, "t");
}

/** Match blocked words as separate tokens, not substrings inside names. */
export function containsBlockedLanguage(value: string) {
  const words = normalizeLeetspeak(value)
    .split(/[^a-z]+/)
    .filter(Boolean);

  return words.some((word) => blockedWords.includes(word));
}
