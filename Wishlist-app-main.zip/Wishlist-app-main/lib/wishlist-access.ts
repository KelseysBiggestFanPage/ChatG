import { createHmac } from "crypto";

export function getWishlistAccessCookieName(
  wishlistId: string
) {
  return `wishlist_access_${wishlistId}`;
}

export function createWishlistAccessToken(
  wishlistId: string,
  accessCodeHash: string
) {
  const secret =
    process.env.SUPABASE_SECRET_KEY;

  if (!secret) {
    throw new Error(
      "SUPABASE_SECRET_KEY is missing."
    );
  }

  return createHmac(
    "sha256",
    secret
  )
    .update(
      `wishlist-access:${wishlistId}:${accessCodeHash}`
    )
    .digest("hex");
}
