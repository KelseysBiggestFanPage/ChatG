import {
  NextResponse,
  type NextRequest,
} from "next/server";
import { updateSession } from "./lib/supabase/proxy";

export async function proxy(
  request: NextRequest
) {
  const supabaseUrl =
    process.env.NEXT_PUBLIC_SUPABASE_URL;

  const supabaseKey =
    process.env
      .NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;

  if (
    !supabaseUrl ||
    !supabaseKey
  ) {
    return NextResponse.next();
  }

  try {
    return await updateSession(
      request
    );
  } catch (error) {
    console.error(
      "Supabase session refresh failed:",
      error
    );

    return NextResponse.next();
  }
}

export const config = {
  matcher: [
    "/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp|ico)$).*)",
  ],
};
