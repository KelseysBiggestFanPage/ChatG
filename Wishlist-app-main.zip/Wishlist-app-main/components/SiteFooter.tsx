import Link from "next/link";

export default function SiteFooter() {
  return (
    <footer
      style={{
        width: "100%",
        boxSizing: "border-box",
        borderTop: "1px solid #e5e7eb",
        background: "#ffffff",
        padding: "22px 30px",
      }}
    >
      <div
        style={{
          maxWidth: "1100px",
          margin: "0 auto",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          gap: "16px",
          flexWrap: "wrap",
          textAlign: "center",
        }}
      >
        <Link
          href="/privacy"
          style={{
            color: "#9ca3af",
            fontSize: "12px",
            fontWeight: "600",
            textDecoration: "none",
          }}
        >
          Privacy
        </Link>

        <span
          style={{
            color: "#d1d5db",
            fontSize: "12px",
          }}
        >
          •
        </span>

        <Link
          href="/terms"
          style={{
            color: "#9ca3af",
            fontSize: "12px",
            fontWeight: "600",
            textDecoration: "none",
          }}
        >
          Terms
        </Link>
      </div>
    </footer>
  );
}
