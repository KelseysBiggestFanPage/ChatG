"use client";

import { useState } from "react";
import { createClient } from "../lib/supabase/client";

function getSafeNextPath(value?: string) {
  if (!value) {
    return "/dashboard";
  }

  if (
    !value.startsWith("/") ||
    value.startsWith("//") ||
    value.includes("\\")
  ) {
    return "/dashboard";
  }

  return value;
}

export default function GoogleAuthButton({
  next = "/dashboard",
}: {
  next?: string;
}) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function continueWithGoogle() {
    setLoading(true);
    setError("");

    const supabase = createClient();

    const safeNext = getSafeNextPath(next);

    const callbackUrl = new URL(
      "/auth/callback",
      window.location.origin
    );

    callbackUrl.searchParams.set(
      "next",
      safeNext
    );

    const { error } =
      await supabase.auth.signInWithOAuth({
        provider: "google",
        options: {
          redirectTo: callbackUrl.toString(),
        },
      });

    if (error) {
      console.error(
        "Google sign-in start error:",
        error
      );

      setError(
        "Could not continue with Google. Please try again."
      );

      setLoading(false);
    }
  }

  return (
    <div>
      <button
        type="button"
        onClick={continueWithGoogle}
        disabled={loading}
        style={{
          width: "100%",
          minHeight: "52px",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          gap: "12px",
          background: "#ffffff",
          color: "#111827",
          border: "1px solid #d1d5db",
          borderRadius: "11px",
          padding: "13px 18px",
          fontSize: "15px",
          fontWeight: "700",
          cursor: loading
            ? "default"
            : "pointer",
          opacity: loading
            ? 0.7
            : 1,
        }}
      >
        <img
          src="/icons/Googlelogin.svg"
          alt=""
          aria-hidden="true"
          width="20"
          height="20"
          style={{
            width: "20px",
            height: "20px",
            flexShrink: 0,
          }}
        />

        <span>
          {loading
            ? "Connecting..."
            : "Continue with Google"}
        </span>
      </button>

      {error && (
        <div
          role="alert"
          style={{
            color: "#b91c1c",
            fontSize: "13px",
            fontWeight: "600",
            textAlign: "center",
            marginTop: "12px",
          }}
        >
          {error}
        </div>
      )}
    </div>
  );
}
