"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";

function generateRandomSlug() {
  const characters = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let result = "";

  for (let i = 0; i < 7; i++) {
    result += characters[Math.floor(Math.random() * characters.length)];
  }

  return result;
}

function cleanSlug(value: string) {
  return value
    .toLowerCase()
    .trim()
    .replace(/['’]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

export default function NewWishlistForm() {
  const router = useRouter();

  const [title, setTitle] = useState("My Wishlist");
  const [linkType, setLinkType] = useState<"random" | "custom">("random");
  const [randomSlug, setRandomSlug] = useState(generateRandomSlug);
  const [customSlug, setCustomSlug] = useState("");
  const [useAccessCode, setUseAccessCode] = useState(false);
  const [accessCode, setAccessCode] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const finalSlug = useMemo(() => {
    if (linkType === "custom") {
      return cleanSlug(customSlug);
    }

    return randomSlug;
  }, [linkType, customSlug, randomSlug]);

  const validAccessCode =
    !useAccessCode ||
    (accessCode.length >= 4 &&
      accessCode.length <= 8 &&
      /^[0-9]+$/.test(accessCode));

  const canCreate =
    title.trim().length > 0 &&
    finalSlug.length > 0 &&
    validAccessCode &&
    !loading;

  async function createWishlist() {
    if (!title.trim()) {
      setError("Enter a Wishlist Name.");
      return;
    }

    if (!finalSlug) {
      setError("Choose a valid wishlist link.");
      return;
    }

    if (useAccessCode && !validAccessCode) {
      setError("Access code must be 4–8 numbers.");
      return;
    }

    setLoading(true);
    setError("");

    try {
      const response = await fetch("/api/wishlists", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          title: title.trim(),
          slug: finalSlug,
          accessCode: useAccessCode ? accessCode : null,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || "Could not create your wishlist.");
        setLoading(false);
        return;
      }

      router.push(`/dashboard/wishlist/${data.id}`);
      router.refresh();
    } catch {
      setError("Something went wrong. Please try again.");
      setLoading(false);
    }
  }

  return (
    <div
      style={{
        background: "#ffffff",
        border: "1px solid #e5e7eb",
        borderRadius: "20px",
        padding: "30px",
        boxShadow: "0 15px 40px rgba(0,0,0,0.06)",
      }}
    >
      <label
        style={{
          display: "block",
          fontSize: "14px",
          fontWeight: "800",
          marginBottom: "8px",
        }}
      >
        Wishlist Name
      </label>

      <input
        value={title}
        onChange={(event) => {
          setTitle(event.target.value);
          setError("");
        }}
        placeholder="My Wishlist"
        maxLength={80}
        style={{
          width: "100%",
          boxSizing: "border-box",
          border: "1px solid #d1d5db",
          borderRadius: "11px",
          padding: "14px 16px",
          fontSize: "16px",
          outline: "none",
          marginBottom: "28px",
        }}
      />

      <div
        style={{
          fontSize: "14px",
          fontWeight: "800",
          marginBottom: "10px",
        }}
      >
        Wishlist Link
      </div>

      <button
        type="button"
        onClick={() => {
          setLinkType("random");
          setError("");
        }}
        style={{
          width: "100%",
          textAlign: "left",
          background: linkType === "random" ? "#eff6ff" : "#ffffff",
          border:
            linkType === "random"
              ? "2px solid #2563eb"
              : "1px solid #d1d5db",
          borderRadius: "14px",
          padding: "18px",
          cursor: "pointer",
          marginBottom: "12px",
        }}
      >
        <div
          style={{
            fontSize: "15px",
            fontWeight: "800",
            color: "#111827",
          }}
        >
          Random Link
        </div>

        <div
          style={{
            color: "#6b7280",
            fontSize: "13px",
            marginTop: "5px",
          }}
        >
          Automatically create a private 7-character link.
        </div>
      </button>

      <button
        type="button"
        onClick={() => {
          setLinkType("custom");
          setError("");
        }}
        style={{
          width: "100%",
          textAlign: "left",
          background: linkType === "custom" ? "#eff6ff" : "#ffffff",
          border:
            linkType === "custom"
              ? "2px solid #2563eb"
              : "1px solid #d1d5db",
          borderRadius: "14px",
          padding: "18px",
          cursor: "pointer",
          marginBottom: "18px",
        }}
      >
        <div
          style={{
            fontSize: "15px",
            fontWeight: "800",
            color: "#111827",
          }}
        >
          Custom Link
        </div>

        <div
          style={{
            color: "#6b7280",
            fontSize: "13px",
            marginTop: "5px",
          }}
        >
          Choose your own wishlist URL.
        </div>
      </button>

      {linkType === "random" && (
        <div
          style={{
            background: "#f8fafc",
            border: "1px solid #e5e7eb",
            borderRadius: "12px",
            padding: "16px",
            marginBottom: "22px",
          }}
        >
          <div
            style={{
              color: "#6b7280",
              fontSize: "12px",
              fontWeight: "700",
              marginBottom: "6px",
            }}
          >
            GENERATED LINK
          </div>

          <div
            style={{
              fontWeight: "800",
              wordBreak: "break-all",
            }}
          >
            /wishlist/{randomSlug}
          </div>

          <button
            type="button"
            onClick={() => {
              setRandomSlug(generateRandomSlug());
              setError("");
            }}
            style={{
              marginTop: "12px",
              background: "transparent",
              color: "#2563eb",
              border: "none",
              padding: 0,
              fontWeight: "700",
              cursor: "pointer",
            }}
          >
            Generate another
          </button>
        </div>
      )}

      {linkType === "custom" && (
        <div
          style={{
            marginBottom: "22px",
          }}
        >
          <label
            style={{
              display: "block",
              fontSize: "13px",
              fontWeight: "800",
              marginBottom: "8px",
            }}
          >
            Custom Link
          </label>

          <input
            value={customSlug}
            onChange={(event) => {
              setCustomSlug(event.target.value);
              setError("");
            }}
            placeholder="your-custom-link"
            maxLength={60}
            style={{
              width: "100%",
              boxSizing: "border-box",
              border: "1px solid #d1d5db",
              borderRadius: "11px",
              padding: "14px 16px",
              fontSize: "16px",
              outline: "none",
            }}
          />

          <div
            style={{
              marginTop: "10px",
              color: "#6b7280",
              fontSize: "13px",
            }}
          >
            Preview:{" "}
            <strong style={{ color: "#111827" }}>
              /wishlist/{cleanSlug(customSlug) || "your-custom-link"}
            </strong>
          </div>
        </div>
      )}

      <div
        style={{
          borderTop: "1px solid #e5e7eb",
          paddingTop: "24px",
          marginTop: "6px",
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            gap: "20px",
          }}
        >
          <div>
            <div
              style={{
                fontSize: "14px",
                fontWeight: "800",
              }}
            >
              Wishlist Access Code
            </div>

            <div
              style={{
                color: "#6b7280",
                fontSize: "13px",
                lineHeight: "1.5",
                marginTop: "4px",
              }}
            >
              Optional. Require guests to enter a code before viewing your
              wishlist.
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              setUseAccessCode(!useAccessCode);
              setAccessCode("");
              setError("");
            }}
            style={{
              width: "52px",
              height: "30px",
              borderRadius: "999px",
              border: "none",
              padding: "3px",
              background: useAccessCode ? "#2563eb" : "#d1d5db",
              cursor: "pointer",
              transition: "0.2s",
              flexShrink: 0,
            }}
          >
            <span
              style={{
                display: "block",
                width: "24px",
                height: "24px",
                borderRadius: "50%",
                background: "#ffffff",
                transform: useAccessCode
                  ? "translateX(22px)"
                  : "translateX(0)",
                transition: "0.2s",
              }}
            />
          </button>
        </div>

        {useAccessCode && (
          <div
            style={{
              marginTop: "18px",
            }}
          >
            <label
              style={{
                display: "block",
                fontSize: "13px",
                fontWeight: "800",
                marginBottom: "8px",
              }}
            >
              Access Code
            </label>

            <input
              type="text"
              inputMode="numeric"
              pattern="[0-9]*"
              value={accessCode}
              onChange={(event) => {
                const numbersOnly = event.target.value
                  .replace(/\D/g, "")
                  .slice(0, 8);

                setAccessCode(numbersOnly);
                setError("");
              }}
              placeholder="4–8 digits"
              maxLength={8}
              autoComplete="off"
              style={{
                width: "100%",
                boxSizing: "border-box",
                border: "1px solid #d1d5db",
                borderRadius: "11px",
                padding: "14px 16px",
                fontSize: "16px",
                outline: "none",
              }}
            />

            <div
              style={{
                color: "#6b7280",
                fontSize: "12px",
                marginTop: "7px",
              }}
            >
              Numbers only. Minimum 4 digits, maximum 8 digits.
            </div>
          </div>
        )}
      </div>

      <div
        style={{
          background: "#eff6ff",
          border: "1px solid #bfdbfe",
          borderRadius: "12px",
          padding: "16px",
          marginTop: "24px",
          marginBottom: error ? "12px" : "24px",
        }}
      >
        <div
          style={{
            fontSize: "12px",
            color: "#2563eb",
            fontWeight: "800",
            marginBottom: "6px",
          }}
        >
          YOUR SHARE LINK
        </div>

        <div
          style={{
            fontWeight: "800",
            wordBreak: "break-all",
          }}
        >
          /wishlist/{finalSlug || "your-custom-link"}
        </div>
      </div>

      {error && (
        <div
          style={{
            color: "#dc2626",
            fontSize: "14px",
            fontWeight: "600",
            marginBottom: "16px",
          }}
        >
          {error}
        </div>
      )}

      <button
        type="button"
        disabled={!canCreate}
        onClick={createWishlist}
        style={{
          width: "100%",
          background: canCreate ? "#2563eb" : "#93c5fd",
          color: "#ffffff",
          border: "none",
          borderRadius: "11px",
          padding: "15px 18px",
          fontSize: "16px",
          fontWeight: "800",
          cursor: canCreate ? "pointer" : "not-allowed",
        }}
      >
        {loading ? "Creating..." : "Create Wishlist"}
      </button>

      <p
        style={{
          color: "#6b7280",
          fontSize: "13px",
          lineHeight: "1.5",
          textAlign: "center",
          margin: "14px 0 0",
        }}
      >
        Your wishlist starts as a draft. You can make it live when you&apos;re
        ready.
      </p>
    </div>
  );
}
