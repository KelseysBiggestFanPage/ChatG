"use client";

import { FormEvent, useState } from "react";
import Link from "next/link";

export default function ReserveGiftForm({
  wishlistSlug,
  giftId,
  giftShippingAddress = "",
  ownerContactEmail = "",
  ownerContactPhone = "",
}: {
  wishlistSlug: string;
  giftId: string;
  giftShippingAddress?: string;
  ownerContactEmail?: string;
  ownerContactPhone?: string;
}) {
  const [name, setName] = useState("");
  const [contactMethod, setContactMethod] = useState<"email" | "phone">("email");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [loading, setLoading] = useState(false);
  const [reserved, setReserved] = useState(false);
  const [error, setError] = useState("");

  function validEmail(value: string) {
    return !value || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
  }

  function validPhone(value: string) {
    if (!value) return true;
    const numbers = value.replace(/\D/g, "");
    return numbers.length >= 7 && numbers.length <= 15;
  }

  async function reserveGift(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const trimmedName = name.trim();
    const trimmedEmail = email.trim();
    const trimmedPhone = phone.trim();

    if (trimmedName.length < 2 || trimmedName.length > 80) {
      setError("Enter a valid name.");
      return;
    }
    if (contactMethod === "email" && !trimmedEmail) {
      setError("Enter the email address the owner should use to contact you.");
      return;
    }
    if (contactMethod === "phone" && !trimmedPhone) {
      setError("Enter the phone number the owner should use to contact you.");
      return;
    }
    if (contactMethod === "email" && !validEmail(trimmedEmail)) {
      setError("Enter a valid email address.");
      return;
    }
    if (contactMethod === "phone" && !validPhone(trimmedPhone)) {
      setError("Enter a valid phone number.");
      return;
    }

    setLoading(true);
    setError("");
    try {
      const response = await fetch("/api/reservations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          giftId,
          wishlistSlug,
          name: trimmedName,
          contactMethod,
          email: contactMethod === "email" ? trimmedEmail : "",
          phone: contactMethod === "phone" ? trimmedPhone : "",
        }),
      });
      const data = await response.json();
      if (!response.ok) {
        setError(data.error || "Could not reserve this gift.");
        return;
      }
      setReserved(true);
    } catch {
      setError("Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  if (reserved) {
    return (
      <div style={{ background: "#ffffff", border: "1px solid #e5e7eb", borderRadius: "20px", padding: "32px", boxShadow: "0 15px 40px rgba(0,0,0,0.06)" }}>
        <div style={{ width: "56px", height: "56px", borderRadius: "50%", background: "#dcfce7", color: "#166534", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 18px", fontSize: "28px", fontWeight: "800" }}>✓</div>
        <h2 style={{ margin: 0, fontSize: "30px", lineHeight: "1.15", fontWeight: "800", letterSpacing: "-1px", textAlign: "center" }}>Gift Reserved!</h2>
        <p style={{ color: "#6b7280", fontSize: "15px", lineHeight: "1.6", margin: "12px 0 24px", textAlign: "center" }}>
          Thank you for reserving this gift. It is now marked as reserved so another guest cannot reserve the same gift.
        </p>
        <div style={{ background: "#fff7ed", border: "1px solid #fed7aa", borderRadius: "13px", padding: "16px", marginBottom: "24px" }}>
          <div style={{ color: "#9a3412", fontSize: "14px", fontWeight: "800", marginBottom: "5px" }}>Need to cancel?</div>
          <div style={{ color: "#9a3412", fontSize: "13px", lineHeight: "1.55" }}>Guests cannot unreserve gifts themselves. Please contact the wishlist owner and ask them to unreserve it.</div>
          {(ownerContactEmail || ownerContactPhone) && (
            <div style={{ display: "grid", gap: "8px", marginTop: "12px" }}>
              {ownerContactEmail && <a href={`mailto:${ownerContactEmail}`} style={{ color: "#9a3412", fontSize: "13px", fontWeight: "800", overflowWrap: "anywhere" }}>Email the wishlist owner</a>}
              {ownerContactPhone && <a href={`tel:${ownerContactPhone}`} style={{ color: "#9a3412", fontSize: "13px", fontWeight: "800" }}>Call the wishlist owner</a>}
            </div>
          )}
        </div>
        <Link href={`/wishlist/${wishlistSlug}`} style={{ display: "block", width: "100%", boxSizing: "border-box", background: "#2563eb", color: "#ffffff", borderRadius: "11px", padding: "14px 18px", fontSize: "15px", fontWeight: "800", textDecoration: "none", textAlign: "center" }}>Back to Wishlist</Link>
      </div>
    );
  }

  if (!giftShippingAddress.trim()) {
    return (
      <div style={{ background: "#fff7ed", border: "1px solid #fed7aa", borderRadius: "20px", padding: "24px", boxShadow: "0 15px 40px rgba(0,0,0,0.04)" }}>
        <h2 style={{ margin: "0 0 10px", color: "#9a3412", fontSize: "20px", fontWeight: "800" }}>This gift is not ready to reserve yet</h2>
        <p style={{ margin: "0 0 14px", color: "#9a3412", fontSize: "14px", lineHeight: "1.6" }}>The wishlist owner needs to add a shipping address or delivery instructions for this gift first.</p>
        {(ownerContactEmail || ownerContactPhone) && <div style={{ display: "grid", gap: "8px", marginBottom: "16px" }}>
          {ownerContactEmail && <a href={`mailto:${ownerContactEmail}`} style={{ color: "#9a3412", fontSize: "14px", fontWeight: "800", overflowWrap: "anywhere" }}>Email the wishlist owner</a>}
          {ownerContactPhone && <a href={`tel:${ownerContactPhone}`} style={{ color: "#9a3412", fontSize: "14px", fontWeight: "800" }}>Call the wishlist owner</a>}
        </div>}
        <Link href={`/wishlist/${wishlistSlug}`} style={{ display: "block", width: "100%", boxSizing: "border-box", background: "#2563eb", color: "#ffffff", borderRadius: "11px", padding: "14px 18px", fontSize: "15px", fontWeight: "800", textDecoration: "none", textAlign: "center" }}>Back to Wishlist</Link>
      </div>
    );
  }

  return (
    <form onSubmit={reserveGift} autoComplete="off" style={{ background: "#ffffff", border: "1px solid #e5e7eb", borderRadius: "20px", padding: "clamp(18px, 4vw, 30px)", boxShadow: "0 15px 40px rgba(0,0,0,0.06)", minWidth: 0 }}>
      <div style={{ background: "#eff6ff", border: "1px solid #bfdbfe", borderRadius: "13px", padding: "16px", marginBottom: "24px" }}>
        <div style={{ color: "#1d4ed8", fontSize: "14px", fontWeight: "800", marginBottom: "7px" }}>Shipping Address or Delivery Instructions for This Gift</div>
        <div style={{ color: "#1e3a8a", fontSize: "14px", lineHeight: "1.6", whiteSpace: "pre-wrap" }}>{giftShippingAddress}</div>
        <div style={{ color: "#1d4ed8", fontSize: "12px", lineHeight: "1.5", marginTop: "9px" }}>This information is shown only before reservation. It is hidden after you reserve the gift.</div>
      </div>

      <label htmlFor="reserverName" style={{ display: "block", fontSize: "14px", fontWeight: "800", marginBottom: "8px" }}>Your Name</label>
      <input id="reserverName" value={name} onChange={(event) => { setName(event.target.value); setError(""); }} placeholder="First and last name" maxLength={80} autoComplete="off" style={{ width: "100%", boxSizing: "border-box", border: "1px solid #d1d5db", borderRadius: "11px", padding: "14px 16px", fontSize: "16px", outline: "none", marginBottom: "8px" }} />
      <div style={{ color: "#6b7280", fontSize: "12px", lineHeight: "1.5", marginBottom: "24px" }}>The wishlist owner can see who reserved this gift.</div>

      <fieldset style={{ border: 0, padding: 0, margin: "0 0 18px", minWidth: 0 }}>
        <legend style={{ display: "block", fontSize: "14px", fontWeight: "800", marginBottom: "10px" }}>
          How should the wishlist owner contact you?
        </legend>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: "10px" }}>
          <label style={{ display: "flex", alignItems: "center", gap: "8px", minWidth: 0, border: contactMethod === "email" ? "1px solid #2563eb" : "1px solid #d1d5db", background: contactMethod === "email" ? "#eff6ff" : "#ffffff", borderRadius: "11px", padding: "12px", cursor: "pointer", fontSize: "14px", fontWeight: "700" }}>
            <input type="radio" name="contactMethod" value="email" checked={contactMethod === "email"} onChange={() => { setContactMethod("email"); setError(""); }} />
            Email
          </label>
          <label style={{ display: "flex", alignItems: "center", gap: "8px", minWidth: 0, border: contactMethod === "phone" ? "1px solid #2563eb" : "1px solid #d1d5db", background: contactMethod === "phone" ? "#eff6ff" : "#ffffff", borderRadius: "11px", padding: "12px", cursor: "pointer", fontSize: "14px", fontWeight: "700" }}>
            <input type="radio" name="contactMethod" value="phone" checked={contactMethod === "phone"} onChange={() => { setContactMethod("phone"); setError(""); }} />
            Phone
          </label>
        </div>
      </fieldset>

      {contactMethod === "email" ? (
        <>
          <label htmlFor="reserverEmail" style={{ display: "block", fontSize: "14px", fontWeight: "800", marginBottom: "8px" }}>Email Address</label>
          <input id="reserverEmail" name="new-reservation-email" type="email" value={email} onChange={(event) => { setEmail(event.target.value); setError(""); }} placeholder="you@example.com" maxLength={120} autoComplete="off" autoCapitalize="none" spellCheck={false} required style={{ width: "100%", boxSizing: "border-box", border: "1px solid #d1d5db", borderRadius: "11px", padding: "14px 16px", fontSize: "16px", outline: "none", marginBottom: "8px" }} />
        </>
      ) : (
        <>
          <label htmlFor="reserverPhone" style={{ display: "block", fontSize: "14px", fontWeight: "800", marginBottom: "8px" }}>Phone Number</label>
          <input id="reserverPhone" name="new-reservation-phone" type="tel" value={phone} onChange={(event) => { setPhone(event.target.value); setError(""); }} placeholder="(555) 555-5555" maxLength={25} autoComplete="off" required style={{ width: "100%", boxSizing: "border-box", border: "1px solid #d1d5db", borderRadius: "11px", padding: "14px 16px", fontSize: "16px", outline: "none", marginBottom: "8px" }} />
        </>
      )}
      <div style={{ color: "#6b7280", fontSize: "12px", lineHeight: "1.5", marginBottom: "24px" }}>Your name and selected contact method are shared with the wishlist owner. These fields start blank.</div>

      {error && <div style={{ background: "#fef2f2", border: "1px solid #fecaca", color: "#b91c1c", borderRadius: "11px", padding: "13px 14px", fontSize: "14px", fontWeight: "700", lineHeight: "1.5", marginBottom: "16px" }}>{error}</div>}
      <button type="submit" disabled={loading} style={{ width: "100%", background: "#2563eb", color: "#ffffff", border: "none", borderRadius: "11px", padding: "15px 18px", fontSize: "16px", fontWeight: "800", cursor: loading ? "not-allowed" : "pointer", opacity: loading ? 0.7 : 1 }}>{loading ? "Reserving..." : "Reserve This Gift"}</button>
    </form>
  );
}
