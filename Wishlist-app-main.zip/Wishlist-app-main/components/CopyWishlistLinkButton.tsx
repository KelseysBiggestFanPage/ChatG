"use client";

import { useState } from "react";

export default function CopyWishlistLinkButton({ url }: { url: string }) {
  const [message, setMessage] = useState("");
  const [copied, setCopied] = useState(false);

  async function copyLink() {
    setMessage("");
    setCopied(false);
    try {
      if (!navigator.clipboard?.writeText) {
        throw new Error("Clipboard access is unavailable.");
      }
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setMessage("Wishlist link copied!");
    } catch {
      setMessage("Could not copy automatically. Select the link above and copy it manually.");
    }
  }

  return (
    <div>
      <button
        type="button"
        onClick={() => void copyLink()}
        style={{
          background: "#eff6ff",
          color: "#1d4ed8",
          border: "1px solid #bfdbfe",
          borderRadius: "9px",
          padding: "9px 12px",
          fontSize: "12px",
          fontWeight: "800",
          cursor: "pointer",
        }}
      >
        {copied ? "Copied!" : "Copy Wishlist Link"}
      </button>
      {message && (
        <div role="status" aria-live="polite" style={{ marginTop: "6px", color: copied ? "#166534" : "#b91c1c", fontSize: "12px", lineHeight: "1.5" }}>
          {message}
        </div>
      )}
    </div>
  );
}
