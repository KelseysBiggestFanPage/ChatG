"use client";

import { useEffect, useState } from "react";

type ContactWishlistOwnerProps = {
  email?: string;
  phone?: string;
};

function phoneHref(phone: string) {
  return `tel:${phone.replace(/[^0-9+]/g, "")}`;
}

export default function ContactWishlistOwner({
  email = "",
  phone = "",
}: ContactWishlistOwnerProps) {
  const [phoneDialogOpen, setPhoneDialogOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!phoneDialogOpen) return;

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setPhoneDialogOpen(false);
    };

    document.addEventListener("keydown", closeOnEscape);

    return () => {
      document.body.style.overflow = previousOverflow;
      document.removeEventListener("keydown", closeOnEscape);
    };
  }, [phoneDialogOpen]);

  async function copyPhoneNumber() {
    try {
      await navigator.clipboard.writeText(phone);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      setCopied(false);
    }
  }

  if (!email && !phone) {
    return (
      <p style={{ margin: 0, color: "#6b7280", fontSize: "13px", lineHeight: 1.6 }}>
        The wishlist owner has not added contact details yet.
      </p>
    );
  }

  return (
    <>
      <div style={{ display: "flex", flexWrap: "wrap", gap: "10px" }}>
        {email && (
          <a
            href={`mailto:${email}`}
            style={{
              display: "inline-flex",
              alignItems: "center",
              justifyContent: "center",
              boxSizing: "border-box",
              minHeight: "44px",
              maxWidth: "100%",
              padding: "11px 15px",
              border: "1px solid #2563eb",
              borderRadius: "10px",
              color: "#2563eb",
              background: "#ffffff",
              fontSize: "14px",
              fontWeight: 800,
              textDecoration: "none",
              overflowWrap: "anywhere",
            }}
          >
            Email the Owner
          </a>
        )}
        {phone && (
          <button
            type="button"
            onClick={() => setPhoneDialogOpen(true)}
            style={{
              display: "inline-flex",
              alignItems: "center",
              justifyContent: "center",
              boxSizing: "border-box",
              minHeight: "44px",
              padding: "11px 15px",
              border: "1px solid #2563eb",
              borderRadius: "10px",
              color: "#ffffff",
              background: "#2563eb",
              fontSize: "14px",
              fontWeight: 800,
              cursor: "pointer",
            }}
          >
            Call the Owner
          </button>
        )}
      </div>

      {phoneDialogOpen && phone && (
        <div
          onClick={(event) => {
            if (event.target === event.currentTarget) {
              setPhoneDialogOpen(false);
            }
          }}
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 2147483000,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: "20px",
            background: "rgba(15, 23, 42, 0.55)",
            backdropFilter: "blur(3px)",
          }}
        >
          <section
            role="dialog"
            aria-modal="true"
            aria-labelledby="owner-phone-dialog-title"
            style={{
              position: "relative",
              boxSizing: "border-box",
              width: "100%",
              maxWidth: "420px",
              padding: "28px 24px 24px",
              border: "1px solid #e5e7eb",
              borderRadius: "20px",
              background: "#ffffff",
              boxShadow: "0 24px 80px rgba(15,23,42,0.25)",
              textAlign: "center",
            }}
          >
            <button
              type="button"
              onClick={() => setPhoneDialogOpen(false)}
              aria-label="Close phone number dialog"
              title="Close"
              style={{
                position: "absolute",
                top: "10px",
                right: "10px",
                width: "34px",
                height: "34px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                border: "none",
                borderRadius: "9px",
                background: "transparent",
                color: "#111827",
                fontSize: "27px",
                lineHeight: 1,
                fontWeight: 600,
                cursor: "pointer",
              }}
            >
              ×
            </button>

            <div
              aria-hidden="true"
              style={{
                width: "52px",
                height: "52px",
                margin: "0 auto 14px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                borderRadius: "16px",
                background: "#eff6ff",
                color: "#2563eb",
                fontSize: "24px",
              }}
            >
              ☎
            </div>

            <h3
              id="owner-phone-dialog-title"
              style={{
                margin: "0 30px 8px",
                color: "#111827",
                fontSize: "21px",
                lineHeight: 1.25,
                fontWeight: 850,
              }}
            >
              Call the Wishlist Owner
            </h3>
            <p style={{ margin: "0 0 8px", color: "#6b7280", fontSize: "13px" }}>
              You can reach the owner at:
            </p>
            <a
              href={phoneHref(phone)}
              style={{
                display: "inline-block",
                maxWidth: "100%",
                color: "#2563eb",
                fontSize: "clamp(19px, 5vw, 24px)",
                lineHeight: 1.35,
                fontWeight: 850,
                textDecoration: "none",
                overflowWrap: "anywhere",
                marginBottom: "20px",
              }}
            >
              {phone}
            </a>

            <div style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: "10px" }}>
              <a
                href={phoneHref(phone)}
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  minHeight: "44px",
                  boxSizing: "border-box",
                  padding: "10px 12px",
                  border: "1px solid #2563eb",
                  borderRadius: "10px",
                  background: "#2563eb",
                  color: "#ffffff",
                  fontSize: "14px",
                  fontWeight: 800,
                  textDecoration: "none",
                }}
              >
                Call Now
              </a>
              <button
                type="button"
                onClick={() => void copyPhoneNumber()}
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  minHeight: "44px",
                  boxSizing: "border-box",
                  padding: "10px 12px",
                  border: "1px solid #bfdbfe",
                  borderRadius: "10px",
                  background: "#eff6ff",
                  color: "#1d4ed8",
                  fontSize: "14px",
                  fontWeight: 800,
                  cursor: "pointer",
                }}
              >
                {copied ? "Copied!" : "Copy Number"}
              </button>
            </div>
          </section>
        </div>
      )}
    </>
  );
}
