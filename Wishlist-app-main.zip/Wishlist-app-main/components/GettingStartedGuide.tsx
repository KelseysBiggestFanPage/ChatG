"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useState, type CSSProperties } from "react";

type GuideMode = "closed" | "welcome" | "tour" | "example";
type Spotlight = { x: number; y: number; width: number; height: number; viewportWidth: number; viewportHeight: number };

type Step = {
  title: string;
  body: string;
  target?: string;
  label: string;
};

const STEPS: Step[] = [
  {
    label: "STEP 1 OF 4",
    title: "Create a wishlist",
    body: "This is where you will start after the tour. Use + New Wishlist to make a list for a birthday, holiday, celebration, or anything else. You can make more than one wishlist.",
    target: "create-wishlist",
  },
  {
    label: "STEP 2 OF 4",
    title: "Your wishlists live here",
    body: "After the tour, your lists will show in this area. Choose Manage Wishlist on a card to add gifts, edit details, and decide when the list is ready to share.",
    target: "wishlist-area",
  },
  {
    label: "STEP 3 OF 4",
    title: "Set up how people reach you",
    body: "After the tour, open Settings to manage your account and contact details. Guests can contact the owner if they have a question or need a reservation changed.",
    target: "settings",
  },
  {
    label: "STEP 4 OF 4",
    title: "Add gifts, then share your link",
    body: "Once the tour is closed, inside Manage Wishlist you can add gifts and their delivery instructions, then publish the wishlist and copy its link. Guests can view and reserve gifts without creating a GoWishlist account.",
  },
];

function storageKey(userId: string) {
  return `gowishlist:getting-started:v1:${userId}`;
}

function roundedRectPath(x: number, y: number, width: number, height: number, radius: number) {
  const r = Math.min(radius, width / 2, height / 2);
  return [
    `M ${x + r} ${y}`,
    `H ${x + width - r}`,
    `Q ${x + width} ${y} ${x + width} ${y + r}`,
    `V ${y + height - r}`,
    `Q ${x + width} ${y + height} ${x + width - r} ${y + height}`,
    `H ${x + r}`,
    `Q ${x} ${y + height} ${x} ${y + height - r}`,
    `V ${y + r}`,
    `Q ${x} ${y} ${x + r} ${y}`,
    "Z",
  ].join(" ");
}

export default function GettingStartedGuide({
  userId,
}: {
  userId: string;
}) {
  const [mode, setMode] = useState<GuideMode>("closed");
  const [stepIndex, setStepIndex] = useState(0);
  const [spotlight, setSpotlight] = useState<Spotlight | null>(null);
  const key = useMemo(() => storageKey(userId), [userId]);

  useEffect(() => {
    try {
      if (window.localStorage.getItem(key) !== "done") {
        setMode("welcome");
      }
    } catch {
      // If browser storage is unavailable, still show the guide for this visit.
      setMode("welcome");
    }
  }, [key]);

  const finishGuide = useCallback(() => {
    try {
      window.localStorage.setItem(key, "done");
    } catch {
      // The guide can still close if localStorage is blocked.
    }
    setMode("closed");
    setSpotlight(null);
  }, [key]);

  const currentStep = STEPS[stepIndex];

  useEffect(() => {
    if (mode !== "tour" || !currentStep?.target) {
      setSpotlight(null);
      return;
    }

    const target = document.querySelector<HTMLElement>(`[data-tour="${currentStep.target}"]`);
    if (!target) {
      setSpotlight(null);
      return;
    }

    target.scrollIntoView({ behavior: "smooth", block: "center", inline: "nearest" });

    const updateSpotlight = () => {
      const rect = target.getBoundingClientRect();
      const padding = 7;
      const viewportWidth = document.documentElement.clientWidth || window.innerWidth;
      const viewportHeight = window.innerHeight;
      const x = Math.max(4, rect.left - padding);
      const y = Math.max(4, rect.top - padding);
      const right = Math.min(viewportWidth - 4, rect.right + padding);
      const bottom = Math.min(viewportHeight - 4, rect.bottom + padding);

      setSpotlight({
        x,
        y,
        width: Math.max(12, right - x),
        height: Math.max(12, bottom - y),
        viewportWidth,
        viewportHeight,
      });
    };

    const frame = window.requestAnimationFrame(updateSpotlight);
    window.addEventListener("resize", updateSpotlight);
    window.addEventListener("scroll", updateSpotlight, true);

    return () => {
      window.cancelAnimationFrame(frame);
      window.removeEventListener("resize", updateSpotlight);
      window.removeEventListener("scroll", updateSpotlight, true);
    };
  }, [mode, currentStep]);

  useEffect(() => {
    if (mode === "closed") return;

    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        finishGuide();
      }
    };

    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, [mode, finishGuide]);

  function startTour() {
    setStepIndex(0);
    setMode("tour");
  }

  function nextStep() {
    if (stepIndex >= STEPS.length - 1) {
      finishGuide();
      return;
    }
    setStepIndex((current) => current + 1);
  }

  const tutorialCardStyle: CSSProperties = {
    position: "fixed",
    zIndex: 10002,
    boxSizing: "border-box",
    width: "min(440px, calc(100vw - 28px))",
    maxHeight: "calc(100dvh - 28px)",
    overflowY: "auto",
    padding: "25px",
    border: "1px solid #e5e7eb",
    borderRadius: "20px",
    background: "#ffffff",
    color: "#111827",
    boxShadow: "0 25px 80px rgba(0,0,0,0.3)",
  };

  let tourCardPosition: CSSProperties = {
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
  };

  if (mode === "tour" && spotlight) {
    const cardWidth = Math.min(440, spotlight.viewportWidth - 28);
    const left = Math.max(14, Math.min(spotlight.viewportWidth - cardWidth - 14, spotlight.x + spotlight.width / 2 - cardWidth / 2));
    const preferBelow = spotlight.y + spotlight.height + 300 < spotlight.viewportHeight;
    const desiredTop = preferBelow
      ? spotlight.y + spotlight.height + 16
      : spotlight.y - 300;
    const top = Math.max(14, Math.min(spotlight.viewportHeight - 280, desiredTop));
    tourCardPosition = { top, left };
  }

  return (
    <>
      <button
        type="button"
        onClick={() => {
          setStepIndex(0);
          setMode("welcome");
        }}
        style={{
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
          minHeight: "44px",
          padding: "12px 15px",
          border: "1px solid #bfdbfe",
          borderRadius: "11px",
          background: "#eff6ff",
          color: "#1d4ed8",
          fontSize: "14px",
          fontWeight: 800,
          cursor: "pointer",
          whiteSpace: "nowrap",
        }}
      >
        ? Take a tour
      </button>

      {mode !== "closed" && (
        <>
          {mode === "tour" && spotlight ? (
            <>
              <svg
                aria-hidden="true"
                viewBox={`0 0 ${spotlight.viewportWidth} ${spotlight.viewportHeight}`}
                preserveAspectRatio="none"
                style={{ position: "fixed", inset: 0, zIndex: 10000, width: "100vw", height: "100dvh" }}
              >
                <path
                  d={`M 0 0 H ${spotlight.viewportWidth} V ${spotlight.viewportHeight} H 0 Z ${roundedRectPath(spotlight.x, spotlight.y, spotlight.width, spotlight.height, 14)}`}
                  fill="rgba(15, 23, 42, 0.76)"
                  fillRule="evenodd"
                  pointerEvents="all"
                />
                <rect
                  x={spotlight.x}
                  y={spotlight.y}
                  width={spotlight.width}
                  height={spotlight.height}
                  rx="14"
                  fill="rgba(0,0,0,0)"
                  pointerEvents="all"
                />
              </svg>
              <div
                aria-hidden="true"
                style={{
                  position: "fixed",
                  zIndex: 10001,
                  left: spotlight.x,
                  top: spotlight.y,
                  width: spotlight.width,
                  height: spotlight.height,
                  boxSizing: "border-box",
                  border: "2px solid #93c5fd",
                  borderRadius: "14px",
                  boxShadow: "0 0 0 4px rgba(59,130,246,0.25)",
                  pointerEvents: "none",
                }}
              />
            </>
          ) : (
            <div
              style={{ position: "fixed", inset: 0, zIndex: 10000, background: "rgba(15, 23, 42, 0.76)", backdropFilter: "blur(2px)" }}
            />
          )}

          {mode === "welcome" && (
            <section role="dialog" aria-modal="true" aria-labelledby="getting-started-title" style={{ ...tutorialCardStyle, ...tourCardPosition }}>
              <div style={{ color: "#2563eb", fontSize: "12px", fontWeight: 900, letterSpacing: "0.8px", marginBottom: "9px" }}>WELCOME TO GOWISHLIST</div>
              <h2 id="getting-started-title" style={{ margin: "0 0 10px", fontSize: "27px", letterSpacing: "-0.8px", lineHeight: 1.15, fontWeight: 900 }}>
                Your first wishlist is just a few steps away.
              </h2>
              <p style={{ color: "#4b5563", fontSize: "14px", lineHeight: 1.65, margin: "0 0 20px" }}>
                Take a quick guided tour, preview an example wishlist, or jump straight in. You can reopen this guide any time from your dashboard.
              </p>
              <div style={{ display: "grid", gap: "10px" }}>
                <button type="button" onClick={startTour} style={{ minHeight: "46px", border: 0, borderRadius: "11px", background: "#2563eb", color: "#ffffff", fontSize: "14px", fontWeight: 850, cursor: "pointer" }}>
                  Start quick tour
                </button>
                <button type="button" onClick={() => setMode("example")} style={{ minHeight: "46px", border: "1px solid #bfdbfe", borderRadius: "11px", background: "#eff6ff", color: "#1d4ed8", fontSize: "14px", fontWeight: 850, cursor: "pointer" }}>
                  See an example wishlist
                </button>
                <button type="button" onClick={finishGuide} style={{ minHeight: "42px", border: 0, background: "transparent", color: "#6b7280", fontSize: "13px", fontWeight: 750, cursor: "pointer" }}>
                  Skip tutorial for now
                </button>
              </div>
            </section>
          )}

          {mode === "tour" && currentStep && (
            <section role="dialog" aria-modal="true" aria-labelledby="tour-step-title" style={{ ...tutorialCardStyle, ...tourCardPosition }}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: "12px", marginBottom: "12px" }}>
                <span style={{ color: "#2563eb", fontSize: "11px", fontWeight: 900, letterSpacing: "0.7px" }}>{currentStep.label}</span>
                <button type="button" onClick={finishGuide} style={{ border: 0, background: "transparent", color: "#4b5563", fontSize: "12px", fontWeight: 800, cursor: "pointer", padding: "6px" }}>Skip tour</button>
              </div>
              <h2 id="tour-step-title" style={{ margin: "0 0 9px", fontSize: "24px", letterSpacing: "-0.6px", lineHeight: 1.2, fontWeight: 900 }}>{currentStep.title}</h2>
              <p style={{ color: "#4b5563", fontSize: "14px", lineHeight: 1.65, margin: "0 0 22px" }}>{currentStep.body}</p>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: "10px" }}>
                <button type="button" onClick={() => stepIndex === 0 ? setMode("welcome") : setStepIndex((current) => current - 1)} style={{ minHeight: "42px", border: "1px solid #d1d5db", borderRadius: "10px", background: "#ffffff", color: "#374151", padding: "10px 14px", fontSize: "13px", fontWeight: 800, cursor: "pointer" }}>Back</button>
                <button type="button" onClick={nextStep} style={{ minHeight: "42px", border: 0, borderRadius: "10px", background: "#2563eb", color: "#ffffff", padding: "10px 17px", fontSize: "13px", fontWeight: 850, cursor: "pointer" }}>{stepIndex === STEPS.length - 1 ? "Finish tour" : "Next →"}</button>
              </div>
            </section>
          )}

          {mode === "example" && (
            <section role="dialog" aria-modal="true" aria-labelledby="example-wishlist-title" style={{ ...tutorialCardStyle, ...tourCardPosition, width: "min(500px, calc(100vw - 28px))" }}>
              <div style={{ color: "#2563eb", fontSize: "12px", fontWeight: 900, letterSpacing: "0.8px", marginBottom: "8px" }}>EXAMPLE PREVIEW · NOTHING IS SAVED</div>
              <h2 id="example-wishlist-title" style={{ margin: "0 0 7px", fontSize: "27px", letterSpacing: "-0.8px", fontWeight: 900 }}>Birthday Wishlist</h2>
              <p style={{ color: "#6b7280", fontSize: "13px", lineHeight: 1.55, margin: "0 0 17px" }}>This is a pretend list to show how a real wishlist can look to guests.</p>
              <div style={{ display: "grid", gap: "10px", marginBottom: "19px" }}>
                {[
                  { emoji: "🎧", name: "Wireless headphones", price: "$49.99" },
                  { emoji: "📚", name: "Favorite book", price: "$14.00" },
                  { emoji: "🎲", name: "Board game", price: "$24.99" },
                ].map((gift) => (
                  <div key={gift.name} style={{ display: "flex", alignItems: "center", gap: "12px", padding: "12px", border: "1px solid #e5e7eb", borderRadius: "12px", background: "#ffffff" }}>
                    <div aria-hidden="true" style={{ width: "48px", height: "48px", borderRadius: "10px", background: "#eff6ff", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "24px", flexShrink: 0 }}>{gift.emoji}</div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ color: "#111827", fontSize: "14px", fontWeight: 850 }}>{gift.name}</div>
                      <div style={{ color: "#2563eb", fontSize: "13px", fontWeight: 850, marginTop: "3px" }}>{gift.price}</div>
                    </div>
                    <span style={{ flexShrink: 0, padding: "5px 7px", borderRadius: "999px", background: "#dcfce7", color: "#166534", fontSize: "10px", fontWeight: 900 }}>AVAILABLE</span>
                  </div>
                ))}
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: "10px" }}>
                <button type="button" onClick={() => setMode("welcome")} style={{ minHeight: "44px", border: "1px solid #d1d5db", borderRadius: "10px", background: "#ffffff", color: "#374151", fontSize: "13px", fontWeight: 800, cursor: "pointer" }}>Back</button>
                <Link href="/dashboard/new" onClick={finishGuide} style={{ minHeight: "44px", boxSizing: "border-box", display: "flex", alignItems: "center", justifyContent: "center", padding: "10px", borderRadius: "10px", background: "#2563eb", color: "#ffffff", fontSize: "13px", fontWeight: 850, textDecoration: "none", textAlign: "center" }}>Create my wishlist</Link>
              </div>
            </section>
          )}
        </>
      )}
    </>
  );
}
