"use client";

import Link from "next/link";
import {
  FormEvent,
  useEffect,
  useState,
} from "react";

type SupportProfile = {
  loggedIn: boolean;
  name: string;
  email: string;
};

export default function SupportWidgetPanel({
  initialOpen = false,
  onClose,
}: {
  initialOpen?: boolean;
  onClose?: () => void;
}) {
  const [open, setOpen] =
    useState(initialOpen);

  const [profileLoading, setProfileLoading] =
    useState(false);

  const [loggedIn, setLoggedIn] =
    useState(false);

  const [name, setName] =
    useState("");

  const [email, setEmail] =
    useState("");

  const [message, setMessage] =
    useState("");

  const [sending, setSending] =
    useState(false);

  const [error, setError] =
    useState("");

  const [sent, setSent] =
    useState(false);

  const [profileLoaded, setProfileLoaded] =
    useState(false);

  useEffect(() => {
    if (!open || profileLoaded) {
      return;
    }

    async function loadProfile() {
      setProfileLoading(true);

      try {
        const response =
          await fetch(
            "/api/support",
            {
              method: "GET",
              cache: "no-store",
            }
          );

        const data =
          (await response.json()) as SupportProfile;

        setLoggedIn(
          Boolean(
            data.loggedIn
          )
        );

        if (data.name) {
          setName(
            data.name
          );
        }

        if (data.email) {
          setEmail(
            data.email
          );
        }
      } catch {
        setLoggedIn(false);
      } finally {
        setProfileLoading(false);
        setProfileLoaded(true);
      }
    }

    loadProfile();
  }, [
    open,
    profileLoaded,
  ]);

  async function submitSupport(
    event: FormEvent<HTMLFormElement>
  ) {
    event.preventDefault();

    if (sending) {
      return;
    }

    setError("");
    setSent(false);

    const trimmedName =
      name.trim();

    const trimmedEmail =
      email.trim();

    const trimmedMessage =
      message.trim();

    if (!trimmedName) {
      setError(
        "Please enter your name."
      );
      return;
    }

    if (!trimmedEmail) {
      setError(
        "Please enter your email."
      );
      return;
    }

    if (
      trimmedMessage.length <
      5
    ) {
      setError(
        "Please enter a message."
      );
      return;
    }

    setSending(true);

    try {
      const sourcePath =
        typeof window !==
        "undefined"
          ? `${window.location.pathname}${window.location.search}`
          : "";

      const response =
        await fetch(
          "/api/support",
          {
            method: "POST",
            headers: {
              "Content-Type":
                "application/json",
            },
            body: JSON.stringify(
              {
                name:
                  trimmedName,
                email:
                  trimmedEmail,
                message:
                  trimmedMessage,
                sourcePath,
              }
            ),
          }
        );

      const data =
        await response.json();

      if (!response.ok) {
        setError(
          data?.error ||
            "We could not send your message. Please try again."
        );

        return;
      }

      setMessage("");
      setSent(true);
    } catch {
      setError(
        "We could not send your message. Please try again."
      );
    } finally {
      setSending(false);
    }
  }

  function closeWidget() {
    setOpen(false);
    setError("");
    onClose?.();
    setSent(false);
  }

  return (
    <>
      {open && (
        <div
          role="dialog"
          aria-label="GoWishlist Support"
          style={{
            position:
              "fixed",
            right:
              "20px",
            bottom:
              "92px",
            width:
              "min(390px, calc(100vw - 32px))",
            maxHeight:
              "min(650px, calc(100vh - 130px))",
            overflowY:
              "auto",
            background:
              "#ffffff",
            border:
              "1px solid #e5e7eb",
            borderRadius:
              "20px",
            boxShadow:
              "0 24px 70px rgba(17,24,39,0.20)",
            zIndex:
              2147483000,
          }}
        >
          <div
            style={{
              background:
                "#2563eb",
              color:
                "#ffffff",
              padding:
                "24px",
              borderRadius:
                "20px 20px 0 0",
              position:
                "relative",
            }}
          >
            <button
              type="button"
              onClick={
                closeWidget
              }
              aria-label="Close support"
              style={{
                position:
                  "absolute",
                top:
                  "14px",
                right:
                  "14px",
                width:
                  "34px",
                height:
                  "34px",
                borderRadius:
                  "50%",
                border:
                  "none",
                background:
                  "rgba(255,255,255,0.16)",
                color:
                  "#ffffff",
                fontSize:
                  "21px",
                lineHeight:
                  "34px",
                cursor:
                  "pointer",
                display:
                  "flex",
                alignItems:
                  "center",
                justifyContent:
                  "center",
                padding:
                  0,
              }}
            >
              ×
            </button>

            <div
              style={{
                display:
                  "flex",
                alignItems:
                  "center",
                gap:
                  "11px",
                paddingRight:
                  "40px",
                marginBottom:
                  "7px",
              }}
            >
              <div
                style={{
                  width:
                    "39px",
                  height:
                    "39px",
                  borderRadius:
                    "12px",
                  background:
                    "#ffffff",
                  display:
                    "flex",
                  alignItems:
                    "center",
                  justifyContent:
                    "center",
                  flexShrink:
                    0,
                  overflow:
                    "hidden",
                }}
              >
                <img
                  src="/favicon-32x32.png"
                  alt=""
                  aria-hidden="true"
                  width={32}
                  height={32}
                  style={{
                    display:
                      "block",
                    width:
                      "32px",
                    height:
                      "32px",
                    objectFit:
                      "contain",
                  }}
                />
              </div>

              <div>
                <div
                  style={{
                    fontSize:
                      "18px",
                    fontWeight:
                      "800",
                    lineHeight:
                      "1.2",
                  }}
                >
                  GoWishlist Support
                </div>

                <div
                  style={{
                    fontSize:
                      "12px",
                    opacity:
                      0.85,
                    marginTop:
                      "2px",
                  }}
                >
                  We&apos;re here to help
                </div>
              </div>
            </div>

            <h2
              style={{
                margin:
                  "20px 0 5px",
                fontSize:
                  "25px",
                lineHeight:
                  "1.2",
                fontWeight:
                  "800",
                letterSpacing:
                  "-0.7px",
              }}
            >
              Start a conversation
            </h2>

            <p
              style={{
                margin:
                  0,
                fontSize:
                  "14px",
                lineHeight:
                  "1.5",
                opacity:
                  0.9,
              }}
            >
              Send us a message and
              we&apos;ll get back to you
              by email.
            </p>
          </div>

          <div
            style={{
              padding:
                "24px",
            }}
          >
            {sent ? (
              <div
                style={{
                  textAlign:
                    "center",
                  padding:
                    "18px 4px 10px",
                }}
              >
                <div
                  style={{
                    width:
                      "56px",
                    height:
                      "56px",
                    borderRadius:
                      "50%",
                    background:
                      "#eff6ff",
                    color:
                      "#2563eb",
                    display:
                      "flex",
                    alignItems:
                      "center",
                    justifyContent:
                      "center",
                    margin:
                      "0 auto 16px",
                    fontSize:
                      "28px",
                    fontWeight:
                      "900",
                  }}
                >
                  ✓
                </div>

                <div
                  style={{
                    fontSize:
                      "20px",
                    fontWeight:
                      "800",
                    marginBottom:
                      "8px",
                  }}
                >
                  Message sent
                </div>

                <p
                  style={{
                    color:
                      "#6b7280",
                    fontSize:
                      "14px",
                    lineHeight:
                      "1.6",
                    margin:
                      "0 0 20px",
                  }}
                >
                  Your message was sent
                  to GoWishlist Support.
                  We&apos;ll respond using
                  the email address you
                  provided.
                </p>

                <button
                  type="button"
                  onClick={() => {
                    setSent(
                      false
                    );
                  }}
                  style={{
                    width:
                      "100%",
                    background:
                      "#ffffff",
                    color:
                      "#2563eb",
                    border:
                      "1px solid #2563eb",
                    borderRadius:
                      "11px",
                    padding:
                      "13px 16px",
                    fontSize:
                      "14px",
                    fontWeight:
                      "800",
                    cursor:
                      "pointer",
                  }}
                >
                  Send another message
                </button>
              </div>
            ) : (
              <form
                onSubmit={
                  submitSupport
                }
              >
                {profileLoading && (
                  <div
                    style={{
                      background:
                        "#f8fafc",
                      border:
                        "1px solid #e5e7eb",
                      borderRadius:
                        "10px",
                      padding:
                        "11px 12px",
                      color:
                        "#6b7280",
                      fontSize:
                        "12px",
                      marginBottom:
                        "16px",
                    }}
                  >
                    Loading your account
                    information...
                  </div>
                )}

                <label
                  htmlFor="support-name"
                  style={{
                    display:
                      "block",
                    fontSize:
                      "13px",
                    fontWeight:
                      "800",
                    marginBottom:
                      "7px",
                  }}
                >
                  Name
                </label>

                <input
                  id="support-name"
                  value={
                    name
                  }
                  onChange={(
                    event
                  ) =>
                    setName(
                      event
                        .target
                        .value
                    )
                  }
                  maxLength={
                    120
                  }
                  autoComplete="name"
                  placeholder="Your name"
                  style={{
                    width:
                      "100%",
                    boxSizing:
                      "border-box",
                    border:
                      "1px solid #d1d5db",
                    borderRadius:
                      "10px",
                    padding:
                      "12px 13px",
                    fontSize:
                      "14px",
                    outline:
                      "none",
                    marginBottom:
                      "17px",
                    background:
                      "#ffffff",
                    color:
                      "#111827",
                  }}
                />

                <label
                  htmlFor="support-email"
                  style={{
                    display:
                      "block",
                    fontSize:
                      "13px",
                    fontWeight:
                      "800",
                    marginBottom:
                      "7px",
                  }}
                >
                  Email
                </label>

                <input
                  id="support-email"
                  type="email"
                  value={
                    email
                  }
                  onChange={(
                    event
                  ) =>
                    setEmail(
                      event
                        .target
                        .value
                    )
                  }
                  readOnly={
                    loggedIn
                  }
                  maxLength={
                    320
                  }
                  autoComplete="email"
                  placeholder="you@example.com"
                  style={{
                    width:
                      "100%",
                    boxSizing:
                      "border-box",
                    border:
                      "1px solid #d1d5db",
                    borderRadius:
                      "10px",
                    padding:
                      "12px 13px",
                    fontSize:
                      "14px",
                    outline:
                      "none",
                    marginBottom:
                      loggedIn
                        ? "7px"
                        : "17px",
                    background:
                      loggedIn
                        ? "#f8fafc"
                        : "#ffffff",
                    color:
                      loggedIn
                        ? "#6b7280"
                        : "#111827",
                  }}
                />

                {loggedIn && (
                  <div
                    style={{
                      color:
                        "#9ca3af",
                      fontSize:
                        "11px",
                      lineHeight:
                        "1.45",
                      marginBottom:
                        "17px",
                    }}
                  >
                    We use the email from
                    your signed-in
                    GoWishlist account.
                  </div>
                )}

                <label
                  htmlFor="support-message"
                  style={{
                    display:
                      "block",
                    fontSize:
                      "13px",
                    fontWeight:
                      "800",
                    marginBottom:
                      "7px",
                  }}
                >
                  How can we help?
                </label>

                <textarea
                  id="support-message"
                  value={
                    message
                  }
                  onChange={(
                    event
                  ) =>
                    setMessage(
                      event
                        .target
                        .value
                    )
                  }
                  maxLength={
                    5000
                  }
                  rows={5}
                  placeholder="Tell us what you need help with..."
                  style={{
                    width:
                      "100%",
                    boxSizing:
                      "border-box",
                    border:
                      "1px solid #d1d5db",
                    borderRadius:
                      "10px",
                    padding:
                      "12px 13px",
                    fontSize:
                      "14px",
                    fontFamily:
                      "inherit",
                    lineHeight:
                      "1.55",
                    outline:
                      "none",
                    resize:
                      "vertical",
                    minHeight:
                      "120px",
                    color:
                      "#111827",
                  }}
                />

                <div
                  style={{
                    textAlign:
                      "right",
                    color:
                      "#9ca3af",
                    fontSize:
                      "10px",
                    marginTop:
                      "5px",
                  }}
                >
                  {
                    message.length
                  }
                  /5000
                </div>

                {error && (
                  <div
                    style={{
                      background:
                        "#fef2f2",
                      border:
                        "1px solid #fecaca",
                      color:
                        "#b91c1c",
                      borderRadius:
                        "10px",
                      padding:
                        "11px 12px",
                      fontSize:
                        "12px",
                      fontWeight:
                        "700",
                      lineHeight:
                        "1.5",
                      marginTop:
                        "14px",
                    }}
                  >
                    {error}
                  </div>
                )}

                <button
                  type="submit"
                  disabled={
                    sending ||
                    profileLoading
                  }
                  style={{
                    width:
                      "100%",
                    background:
                      sending ||
                      profileLoading
                        ? "#93c5fd"
                        : "#2563eb",
                    color:
                      "#ffffff",
                    border:
                      "none",
                    borderRadius:
                      "11px",
                    padding:
                      "14px 18px",
                    fontSize:
                      "15px",
                    fontWeight:
                      "800",
                    cursor:
                      sending ||
                      profileLoading
                        ? "default"
                        : "pointer",
                    marginTop:
                      "17px",
                  }}
                >
                  {sending
                    ? "Sending..."
                    : "Send Message"}
                </button>

                <div
                  style={{
                    color:
                      "#9ca3af",
                    fontSize:
                      "10px",
                    lineHeight:
                      "1.5",
                    textAlign:
                      "center",
                    marginTop:
                      "15px",
                  }}
                >
                  By contacting support,
                  you agree to our{" "}
                  <Link
                    href="/privacy"
                    style={{
                      color:
                        "#6b7280",
                    }}
                  >
                    Privacy Policy
                  </Link>{" "}
                  and{" "}
                  <Link
                    href="/terms"
                    style={{
                      color:
                        "#6b7280",
                    }}
                  >
                    Terms
                  </Link>
                  .
                </div>
              </form>
            )}
          </div>
       
        </div>
      )}
    </>
  );
}
