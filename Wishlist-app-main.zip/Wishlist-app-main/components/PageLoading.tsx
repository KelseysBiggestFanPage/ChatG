import GoWishlistLogo from "./GoWishlistLogo";

export default function PageLoading() {
  return (
    <main
      aria-busy="true"
      aria-label="Loading GoWishlist"
      style={{
        minHeight: "100vh",
        background: "#f8fafc",
        color: "#111827",
      }}
    >
      <style>{`
        @keyframes gowishlist-loading-pulse {
          0%, 100% { opacity: .52; }
          50% { opacity: 1; }
        }
        .gowishlist-loading-shape {
          background: linear-gradient(90deg, #e5e7eb, #f3f4f6, #e5e7eb);
          background-size: 200% 100%;
          animation: gowishlist-loading-pulse 1.35s ease-in-out infinite;
        }
        @media (prefers-reduced-motion: reduce) {
          .gowishlist-loading-shape { animation: none; }
        }
      `}</style>
      <header style={{ background: "#ffffff", borderBottom: "1px solid #e5e7eb" }}>
        <div style={{ maxWidth: "1100px", margin: "0 auto", padding: "20px 24px" }}>
          <GoWishlistLogo href="/home" size={29} />
        </div>
      </header>
      <section style={{ maxWidth: "1100px", margin: "0 auto", padding: "clamp(28px, 7vw, 64px) 24px" }}>
        <div className="gowishlist-loading-shape" style={{ width: "140px", height: "12px", borderRadius: "999px", marginBottom: "18px" }} />
        <div className="gowishlist-loading-shape" style={{ width: "min(460px, 90%)", height: "35px", borderRadius: "10px", marginBottom: "12px" }} />
        <div className="gowishlist-loading-shape" style={{ width: "min(650px, 100%)", height: "15px", borderRadius: "999px", marginBottom: "8px" }} />
        <div className="gowishlist-loading-shape" style={{ width: "min(500px, 82%)", height: "15px", borderRadius: "999px", marginBottom: "32px" }} />
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 230px), 1fr))", gap: "16px" }}>
          {[0, 1, 2].map((item) => (
            <div key={item} style={{ background: "#ffffff", border: "1px solid #e5e7eb", borderRadius: "17px", padding: "22px" }}>
              <div className="gowishlist-loading-shape" style={{ width: "62%", height: "18px", borderRadius: "8px", marginBottom: "19px" }} />
              <div className="gowishlist-loading-shape" style={{ width: "100%", height: "12px", borderRadius: "999px", marginBottom: "9px" }} />
              <div className="gowishlist-loading-shape" style={{ width: "72%", height: "12px", borderRadius: "999px", marginBottom: "22px" }} />
              <div className="gowishlist-loading-shape" style={{ width: "48%", height: "14px", borderRadius: "999px" }} />
            </div>
          ))}
        </div>
        <p style={{ color: "#6b7280", fontSize: "13px", textAlign: "center", marginTop: "24px" }}>Loading your GoWishlist…</p>
      </section>
    </main>
  );
}
