"use client";

import Image from "next/image";

const stores = [
  { name: "Amazon", src: "/icons/AmazonLogo.webp" },
  { name: "Target", src: "/icons/TargetLogo.png" },
  { name: "Walmart", src: "/icons/Walmart-Logo.jpg" },
  { name: "LEGO", src: "/icons/LegoLogo.png" },
  { name: "Apple", src: "/icons/AppleLogo.png" },
  { name: "Best Buy", src: "/icons/BestBuyLogo.png" },
  { name: "Nike", src: "/icons/NikeLogo.png" },
  { name: "adidas", src: "/icons/AdidasLogo.webp" },
  { name: "Costco Wholesale", src: "/icons/CostcoWholesaleLogo.png" },
  { name: "The Home Depot", src: "/icons/HomeDepotLogo.png" },
  { name: "GameStop", src: "/icons/GameStopLogo.png" },
  { name: "Sephora", src: "/icons/SephoraLogo.png" },
  { name: "Chewy", src: "/icons/ChewyLogo.png" },
  { name: "Barnes & Noble", src: "/icons/BarnesNobleLogo.png" },
  { name: "Crate & Barrel", src: "/icons/CrateBarrelLogo.png" },
  { name: "Dick's Sporting Goods", src: "/icons/DicksSportingGoodsLogo.png" },
  { name: "Bass Pro Shops", src: "/icons/BassProShopsLogo.png" },
  { name: "Build-A-Bear Workshop", src: "/icons/Build-a-BearLogo.png" },
  { name: "Gap", src: "/icons/GapLogo.png" },
  { name: "Kohl's", src: "/icons/KohlsLogo.png" },
  { name: "Nordstrom", src: "/icons/NordstromLogo.png" },
  { name: "OshKosh B'gosh", src: "/icons/OshkoshLogo.jpg" },
] as const;

export default function StoreLogoCarousel() {
  return (
    <section
      aria-labelledby="supported-stores-heading"
      style={{
        background: "#ffffff",
        borderTop: "1px solid #f1f5f9",
        borderBottom: "1px solid #f1f5f9",
        padding: "43px 0 47px",
      }}
    >
      <div
        style={{
          maxWidth: "1100px",
          margin: "0 auto",
          padding: "0 30px",
          boxSizing: "border-box",
        }}
      >
        <div style={{ textAlign: "center", marginBottom: "25px" }}>
          <h2
            id="supported-stores-heading"
            style={{
              color: "#111827",
              fontSize: "clamp(23px, 3vw, 30px)",
              lineHeight: 1.2,
              fontWeight: 850,
              letterSpacing: "-0.9px",
              margin: 0,
            }}
          >
            Stores you love, all in one wishlist
          </h2>
          <p
            style={{
              color: "#6b7280",
              fontSize: "15px",
              lineHeight: 1.6,
              margin: "9px auto 0",
              maxWidth: "600px",
            }}
          >
            Add gifts from these popular stores and more to your GoWishlist.
          </p>
        </div>

        <div className="store-marquee" aria-label="Featured store logos">
          <div className="store-track">
            {[false, true].map((isDuplicate) => (
              <div
                className="store-group"
                key={isDuplicate ? "duplicate-stores" : "featured-stores"}
                aria-hidden={isDuplicate || undefined}
              >
                {stores.map((store) => (
                  <div
                    className="store-card"
                    key={`${isDuplicate ? "duplicate" : "store"}-${store.name}`}
                    aria-label={isDuplicate ? undefined : store.name}
                    role="img"
                  >
                    <div className="store-logo-frame">
                      <Image
                        src={store.src}
                        alt=""
                        width={160}
                        height={72}
                        sizes="160px"
                        draggable={false}
                        style={{
                          width: "100%",
                          height: "100%",
                          objectFit: "contain",
                          display: "block",
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>

      <style jsx>{`
        .store-marquee {
          width: 100%;
          overflow: hidden;
          padding: 2px 0 5px;
        }

        .store-track {
          display: flex;
          width: max-content;
          animation: scroll-store-logos 48s linear infinite;
          will-change: transform;
        }

        .store-group {
          display: flex;
          align-items: center;
          gap: 15px;
          padding-right: 15px;
          flex: 0 0 auto;
        }

        .store-card {
          box-sizing: border-box;
          width: 176px;
          min-width: 176px;
          height: 100px;
          padding: 10px 12px;
          display: flex;
          align-items: center;
          justify-content: center;
          overflow: hidden;
          border: 1px solid #f1f5f9;
          border-radius: 14px;
          background: #ffffff;
        }

        .store-logo-frame {
          width: 148px;
          height: 76px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: #ffffff;
          flex: 0 0 auto;
        }

        .store-marquee:hover .store-track,
        .store-marquee:focus-within .store-track {
          animation-play-state: paused;
        }

        @keyframes scroll-store-logos {
          from { transform: translateX(0); }
          to { transform: translateX(-50%); }
        }

        @media (max-width: 640px) {
          .store-card {
            width: 154px;
            min-width: 154px;
            height: 90px;
            padding: 8px;
          }
          .store-logo-frame {
            width: 132px;
            height: 70px;
          }
        }

        @media (prefers-reduced-motion: reduce) {
          .store-marquee {
            overflow-x: auto;
            overscroll-behavior-x: contain;
          }
          .store-track { animation: none; }
        }
      `}</style>
    </section>
  );
}
