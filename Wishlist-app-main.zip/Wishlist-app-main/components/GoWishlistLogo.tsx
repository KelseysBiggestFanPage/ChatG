import Link from "next/link";

export default function GoWishlistLogo({
  href = "/home",
  size = 28,
}: {
  href?: string;
  size?: number;
}) {
  return (
    <Link
      href={href}
      style={{
        display: "inline-block",
        textDecoration: "none",
        fontSize: `${size}px`,
        fontWeight: "800",
        letterSpacing: "-1.2px",
        lineHeight: 1,
      }}
    >
      <span
        style={{
          color: "#2563eb",
        }}
      >
        Go
      </span>

      <span
        style={{
          color: "#111827",
        }}
      >
        Wishlist
      </span>
    </Link>
  );
}
