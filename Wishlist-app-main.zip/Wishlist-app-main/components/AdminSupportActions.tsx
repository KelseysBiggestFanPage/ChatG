"use client";

import { useState } from "react";

export default function AdminSupportActions({
  email,
}: {
  email: string;
}) {
  const [copied, setCopied] =
    useState(false);

  async function copyEmail() {
    try {
      await navigator.clipboard.writeText(
        email
      );

      setCopied(true);

      window.setTimeout(() => {
        setCopied(false);
      }, 1800);
    } catch {
      setCopied(false);
    }
  }

  const gmailUrl =
    `https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(
      email
    )}&su=${encodeURIComponent(
      "GoWishlist Support"
    )}`;

  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: "8px",
        flexWrap: "wrap",
      }}
    >
      <button
        type="button"
        onClick={copyEmail}
        style={{
          background: "#ffffff",
          color: "#2563eb",
          border:
            "1px solid #2563eb",
          borderRadius: "9px",
          padding: "9px 12px",
          fontSize: "12px",
          fontWeight: "800",
          cursor: "pointer",
        }}
      >
        {copied
          ? "Copied!"
          : "Copy Email"}
      </button>

      <a
        href={gmailUrl}
        target="_blank"
        rel="noreferrer"
        style={{
          display: "inline-block",
          background: "#2563eb",
          color: "#ffffff",
          border:
            "1px solid #2563eb",
          borderRadius: "9px",
          padding: "9px 12px",
          fontSize: "12px",
          fontWeight: "800",
          textDecoration: "none",
        }}
      >
        Reply in Gmail
      </a>
    </div>
  );
}
