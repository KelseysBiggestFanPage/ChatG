"use client";

import { useState } from "react";

export default function AccessCodeSettings({
  hasAccessCode,
}: {
  hasAccessCode: boolean;
}) {
  const [mode, setMode] = useState<
    "keep" | "change" | "off"
  >(hasAccessCode ? "keep" : "off");

  return (
    <div
      style={{
        borderTop: "1px solid #e5e7eb",
        paddingTop: "25px",
      }}
    >
      <div
        style={{
          fontSize: "16px",
          fontWeight: "800",
          marginBottom: "6px",
        }}
      >
        Guest Access Code
      </div>

      <div
        style={{
          color: "#6b7280",
          fontSize: "13px",
          lineHeight: "1.5",
          marginBottom: "18px",
        }}
      >
        Choose whether guests need a code before they can view your wishlist.
      </div>

      {hasAccessCode ? (
        <>
          <label
            style={{
              display: "block",
              border:
                mode === "keep"
                  ? "2px solid #2563eb"
                  : "1px solid #d1d5db",
              background:
                mode === "keep"
                  ? "#eff6ff"
                  : "#ffffff",
              borderRadius: "12px",
              padding: "14px",
              marginBottom: "10px",
              cursor: "pointer",
            }}
          >
            <input
              type="radio"
              name="accessMode"
              value="keep"
              checked={mode === "keep"}
              onChange={() => setMode("keep")}
              style={{
                marginRight: "9px",
              }}
            />

            <strong>
              Keep Current Access Code
            </strong>
          </label>

          <label
            style={{
              display: "block",
              border:
                mode === "change"
                  ? "2px solid #2563eb"
                  : "1px solid #d1d5db",
              background:
                mode === "change"
                  ? "#eff6ff"
                  : "#ffffff",
              borderRadius: "12px",
              padding: "14px",
              marginBottom: "10px",
              cursor: "pointer",
            }}
          >
            <input
              type="radio"
              name="accessMode"
              value="change"
              checked={mode === "change"}
              onChange={() =>
                setMode("change")
              }
              style={{
                marginRight: "9px",
              }}
            />

            <strong>
              Change Access Code
            </strong>
          </label>

          <label
            style={{
              display: "block",
              border:
                mode === "off"
                  ? "2px solid #2563eb"
                  : "1px solid #d1d5db",
              background:
                mode === "off"
                  ? "#eff6ff"
                  : "#ffffff",
              borderRadius: "12px",
              padding: "14px",
              marginBottom: "18px",
              cursor: "pointer",
            }}
          >
            <input
              type="radio"
              name="accessMode"
              value="off"
              checked={mode === "off"}
              onChange={() => setMode("off")}
              style={{
                marginRight: "9px",
              }}
            />

            <strong>
              No Access Code
            </strong>
          </label>
        </>
      ) : (
        <>
          <label
            style={{
              display: "block",
              border:
                mode === "off"
                  ? "2px solid #2563eb"
                  : "1px solid #d1d5db",
              background:
                mode === "off"
                  ? "#eff6ff"
                  : "#ffffff",
              borderRadius: "12px",
              padding: "14px",
              marginBottom: "10px",
              cursor: "pointer",
            }}
          >
            <input
              type="radio"
              name="accessMode"
              value="off"
              checked={mode === "off"}
              onChange={() => setMode("off")}
              style={{
                marginRight: "9px",
              }}
            />

            <strong>
              No Access Code
            </strong>
          </label>

          <label
            style={{
              display: "block",
              border:
                mode === "change"
                  ? "2px solid #2563eb"
                  : "1px solid #d1d5db",
              background:
                mode === "change"
                  ? "#eff6ff"
                  : "#ffffff",
              borderRadius: "12px",
              padding: "14px",
              marginBottom: "18px",
              cursor: "pointer",
            }}
          >
            <input
              type="radio"
              name="accessMode"
              value="change"
              checked={mode === "change"}
              onChange={() =>
                setMode("change")
              }
              style={{
                marginRight: "9px",
              }}
            />

            <strong>
              Add Access Code
            </strong>
          </label>
        </>
      )}

      {mode === "change" && (
        <div
          style={{
            marginTop: "18px",
            marginBottom: "26px",
          }}
        >
          <label
            htmlFor="newAccessCode"
            style={{
              display: "block",
              fontSize: "14px",
              fontWeight: "800",
              marginBottom: "8px",
            }}
          >
            {hasAccessCode
              ? "New Access Code"
              : "Access Code"}
          </label>

          <input
            id="newAccessCode"
            name="newAccessCode"
            type="text"
            inputMode="numeric"
            pattern="[0-9]*"
            minLength={4}
            maxLength={8}
            required
            autoComplete="off"
            placeholder="4–8 digits"
            onInput={(event) => {
              const input =
                event.currentTarget;

              input.value = input.value
                .replace(/\D/g, "")
                .slice(0, 8);
            }}
            style={{
              width: "100%",
              boxSizing: "border-box",
              border: "1px solid #d1d5db",
              borderRadius: "11px",
              padding: "14px 16px",
              fontSize: "18px",
              letterSpacing: "2px",
              outline: "none",
            }}
          />

          <div
            style={{
              color: "#6b7280",
              fontSize: "12px",
              lineHeight: "1.5",
              marginTop: "8px",
            }}
          >
            Use 4–8 numbers only.
          </div>
        </div>
      )}
    </div>
  );
}
