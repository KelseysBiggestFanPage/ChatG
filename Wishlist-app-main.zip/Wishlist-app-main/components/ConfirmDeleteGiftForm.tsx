"use client";

export default function ConfirmDeleteGiftForm({
  action,
  giftId,
  giftName,
}: {
  action: (
    formData: FormData
  ) => void | Promise<void>;
  giftId: string;
  giftName: string;
}) {
  return (
    <form
      action={action}
      onSubmit={(event) => {
        const confirmed =
          window.confirm(
            `Delete "${giftName}"?\n\nThis permanently removes this gift from the wishlist.`
          );

        if (!confirmed) {
          event.preventDefault();
        }
      }}
    >
      <input
        type="hidden"
        name="giftId"
        value={giftId}
      />

      <button
        type="submit"
        style={{
          background: "#ffffff",
          color: "#dc2626",
          border:
            "1px solid #dc2626",
          borderRadius: "9px",
          padding: "10px 14px",
          fontSize: "13px",
          fontWeight: "800",
          cursor: "pointer",
        }}
      >
        Delete Gift
      </button>
    </form>
  );
}
