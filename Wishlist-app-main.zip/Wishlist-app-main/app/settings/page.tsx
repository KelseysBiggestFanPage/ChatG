import Link from "next/link";
import { redirect } from "next/navigation";
import GoWishlistLogo from "../../components/GoWishlistLogo";
import { createAdminClient } from "../../lib/supabase/admin";
import { createClient } from "../../lib/supabase/server";
import { containsBlockedLanguage } from "../../lib/name-filter";

export default async function SettingsPage({
  searchParams,
}: {
  searchParams: Promise<{
    saved?: string;
    error?: string;
  }>;
}) {
  const params =
    await searchParams;

  const supabase =
    await createClient();

  const {
    data: { user },
  } =
    await supabase.auth.getUser();

  if (!user) {
    redirect("/login");
  }

  const { data: profile } =
    await supabase
      .from("profiles")
      .select("display_name")
      .eq("id", user.id)
      .maybeSingle();

  const googleName =
    user.user_metadata
      ?.full_name ||
    user.user_metadata?.name ||
    "";

  const currentName =
    profile?.display_name ||
    googleName ||
    "";

  async function saveSettings(
    formData: FormData
  ) {
    "use server";

    const supabase =
      await createClient();

    const {
      data: { user },
    } =
      await supabase.auth.getUser();

    if (!user) {
      redirect("/login");
    }

    const displayName =
      String(
        formData.get(
          "displayName"
        ) || ""
      )
        .trim()
        .replace(/\s+/g, " ");

    if (
      displayName.length < 2 ||
      displayName.length > 80
    ) {
      redirect(
        "/settings?error=name"
      );
    }

    if (
      containsBlockedLanguage(
        displayName
      )
    ) {
      redirect(
        "/settings?error=language"
      );
    }

    const { error } =
      await supabase
        .from("profiles")
        .upsert(
          {
            id: user.id,
            display_name:
              displayName,
            email:
              user.email || null,
            updated_at:
              new Date().toISOString(),
          },
          {
            onConflict: "id",
          }
        );

    if (error) {
      console.error(
        "Settings save error:",
        error
      );

      redirect(
        "/settings?error=save"
      );
    }

    redirect(
      "/settings?saved=1"
    );
  }

  async function deleteAccount(
    formData: FormData
  ) {
    "use server";

    const supabase =
      await createClient();

    const {
      data: { user },
    } =
      await supabase.auth.getUser();

    if (!user) {
      redirect("/login");
    }

    const confirmation =
      String(
        formData.get(
          "confirmation"
        ) || ""
      ).trim();

    if (
      confirmation !== "DELETE"
    ) {
      redirect(
        "/settings?error=delete-confirm"
      );
    }

    if (!user.email) {
      redirect(
        "/settings?error=delete-account"
      );
    }

    const admin =
      createAdminClient();

    const {
      data: archiveId,
      error: archiveError,
    } = await admin.rpc(
      "archive_account_for_deletion",
      {
        p_user_id:
          user.id,
        p_email:
          user.email,
        p_auth_created_at:
          user.created_at,
        p_deleted_by:
          "self",
      }
    );

    if (
      archiveError ||
      !archiveId
    ) {
      console.error(
        "Archive account error:",
        archiveError
      );

      redirect(
        "/settings?error=archive-account"
      );
    }

    const {
      error: deleteError,
    } =
      await admin.auth.admin.deleteUser(
        user.id
      );

    if (deleteError) {
      console.error(
        "Delete account error:",
        deleteError
      );

      const {
        error:
          cleanupArchiveError,
      } = await admin.rpc(
        "discard_account_deletion_archive",
        {
          p_archive_id:
            archiveId,
          p_user_id:
            user.id,
        }
      );

      if (
        cleanupArchiveError
      ) {
        console.error(
          "Delete archive cleanup error:",
          cleanupArchiveError
        );
      }

      redirect(
        "/settings?error=delete-account"
      );
    }

    await supabase.auth.signOut();

    redirect("/home");
  }

  let errorMessage = "";

  if (
    params.error === "name"
  ) {
    errorMessage =
      "Enter a name between 2 and 80 characters.";
  }

  if (
    params.error === "language"
  ) {
    errorMessage =
      "Please choose an appropriate name.";
  }

  if (
    params.error === "save"
  ) {
    errorMessage =
      "We could not save your settings. Please try again.";
  }

  if (
    params.error ===
    "delete-confirm"
  ) {
    errorMessage =
      'Type DELETE exactly to delete your account.';
  }

  if (
    params.error ===
    "archive-account"
  ) {
    errorMessage =
      "We could not safely prepare your account for deletion. Your account was not deleted. Please try again.";
  }

  if (
    params.error ===
    "delete-account"
  ) {
    errorMessage =
      "We could not delete your account. Your account remains active. Please try again.";
  }

  return (
    <main
      style={{
        minHeight: "100vh",
        background: "#f8fafc",
        color: "#111827",
      }}
    >
      <header
        style={{
          background: "#ffffff",
          borderBottom:
            "1px solid #e5e7eb",
        }}
      >
        <div
          style={{
            maxWidth: "900px",
            margin: "0 auto",
            padding: "20px 30px",
            display: "flex",
            justifyContent:
              "space-between",
            alignItems: "center",
            gap: "20px",
          }}
        >
          <GoWishlistLogo
            href="/dashboard"
            size={29}
          />

          <Link
            href="/dashboard"
            style={{
              color: "#6b7280",
              textDecoration:
                "none",
              fontSize: "14px",
              fontWeight: "700",
            }}
          >
            Back to Dashboard
          </Link>
        </div>
      </header>

      <section
        style={{
          maxWidth: "620px",
          margin: "0 auto",
          padding:
            "60px 30px 90px",
        }}
      >
        <div
          style={{
            marginBottom: "28px",
          }}
        >
          <h1
            style={{
              margin: 0,
              fontSize: "40px",
              fontWeight: "800",
              letterSpacing:
                "-1.7px",
            }}
          >
            Settings
          </h1>

          <p
            style={{
              color: "#6b7280",
              fontSize: "16px",
              lineHeight: "1.6",
              marginTop: "10px",
            }}
          >
            Manage the name
            GoWishlist uses when
            you reserve gifts.
          </p>
        </div>

        <form
          action={saveSettings}
          style={{
            background: "#ffffff",
            border:
              "1px solid #e5e7eb",
            borderRadius: "20px",
            padding: "30px",
            boxShadow:
              "0 15px 40px rgba(0,0,0,0.06)",
          }}
        >
          <label
            htmlFor="displayName"
            style={{
              display: "block",
              fontSize: "14px",
              fontWeight: "800",
              marginBottom: "8px",
            }}
          >
            Your Name
          </label>

          <input
            id="displayName"
            name="displayName"
            defaultValue={
              currentName
            }
            placeholder="First and last name"
            maxLength={80}
            autoComplete="name"
            required
            style={{
              width: "100%",
              boxSizing:
                "border-box",
              border:
                "1px solid #d1d5db",
              borderRadius: "11px",
              padding: "14px 16px",
              fontSize: "16px",
              outline: "none",
            }}
          />

          <div
            style={{
              color: "#6b7280",
              fontSize: "12px",
              lineHeight: "1.5",
              marginTop: "8px",
              marginBottom: "24px",
            }}
          >
            This name will
            automatically fill in
            when you reserve a gift.
            You can still change it
            on the reservation
            screen.
          </div>

          <label
            style={{
              display: "block",
              fontSize: "14px",
              fontWeight: "800",
              marginBottom: "8px",
            }}
          >
            Google Email
          </label>

          <div
            style={{
              background: "#f8fafc",
              border:
                "1px solid #e5e7eb",
              borderRadius: "11px",
              padding: "14px 16px",
              color: "#6b7280",
              fontSize: "15px",
              marginBottom: "24px",
            }}
          >
            {user.email}
          </div>

          {params.saved ===
            "1" && (
            <div
              style={{
                background:
                  "#f0fdf4",
                border:
                  "1px solid #bbf7d0",
                color: "#166534",
                borderRadius:
                  "11px",
                padding:
                  "13px 14px",
                fontSize: "14px",
                fontWeight: "700",
                marginBottom:
                  "18px",
              }}
            >
              Settings saved.
            </div>
          )}

          {errorMessage && (
            <div
              style={{
                background:
                  "#fef2f2",
                border:
                  "1px solid #fecaca",
                color: "#b91c1c",
                borderRadius:
                  "11px",
                padding:
                  "13px 14px",
                fontSize: "14px",
                fontWeight: "700",
                lineHeight: "1.55",
                marginBottom:
                  "18px",
              }}
            >
              {errorMessage}
            </div>
          )}

          <button
            type="submit"
            style={{
              width: "100%",
              background: "#2563eb",
              color: "#ffffff",
              border: "none",
              borderRadius: "11px",
              padding: "15px 18px",
              fontSize: "16px",
              fontWeight: "800",
              cursor: "pointer",
            }}
          >
            Save Settings
          </button>
        </form>

        <div
          style={{
            background: "#ffffff",
            border:
              "1px solid #fecaca",
            borderRadius: "20px",
            padding: "30px",
            marginTop: "35px",
          }}
        >
          <h2
            style={{
              margin: "0 0 8px",
              color: "#991b1b",
              fontSize: "20px",
              fontWeight: "800",
            }}
          >
            Delete Account
          </h2>

          <p
            style={{
              color: "#6b7280",
              fontSize: "14px",
              lineHeight: "1.6",
              margin: "0 0 14px",
            }}
          >
            Deleting your account
            immediately removes your
            GoWishlist login, profile,
            wishlists, gifts, and
            reservation information from
            the active service.
          </p>

          <div
            style={{
              background: "#fef2f2",
              border:
                "1px solid #fecaca",
              borderRadius: "11px",
              padding: "14px",
              color: "#991b1b",
              fontSize: "13px",
              lineHeight: "1.55",
              fontWeight: "700",
              marginBottom: "14px",
            }}
          >
            Your account data may be
            recoverable through GoWishlist
            Support for up to 90 days.
            After 90 days, it cannot be
            restored.
          </div>

          <p
            style={{
              color: "#6b7280",
              fontSize: "13px",
              lineHeight: "1.6",
              margin: "0 0 14px",
            }}
          >
            If you sign in to GoWishlist
            again yourself after deleting
            your account, you will receive
            a fresh account. Your old data
            will not automatically return.
          </p>

          <p
            style={{
              color: "#6b7280",
              fontSize: "13px",
              lineHeight: "1.6",
              margin: "0 0 20px",
            }}
          >
            To recover eligible old data
            during the 90-day recovery
            period, contact GoWishlist
            Support. If an old wishlist
            link has already been claimed
            by another user, a restored
            wishlist will receive a new
            available link.
          </p>

          <form
            action={
              deleteAccount
            }
          >
            <label
              htmlFor="confirmation"
              style={{
                display: "block",
                fontSize: "13px",
                fontWeight: "800",
                marginBottom: "8px",
              }}
            >
              Type DELETE to confirm
            </label>

            <input
              id="confirmation"
              name="confirmation"
              placeholder="DELETE"
              autoComplete="off"
              style={{
                width: "100%",
                boxSizing:
                  "border-box",
                border:
                  "1px solid #fecaca",
                borderRadius: "11px",
                padding: "14px 16px",
                fontSize: "16px",
                outline: "none",
                marginBottom: "12px",
              }}
            />

            <button
              type="submit"
              style={{
                width: "100%",
                background: "#dc2626",
                color: "#ffffff",
                border: "none",
                borderRadius: "11px",
                padding: "14px 18px",
                fontSize: "15px",
                fontWeight: "800",
                cursor: "pointer",
              }}
            >
              Delete Account
            </button>
          </form>
        </div>
      </section>
    </main>
  );
}
