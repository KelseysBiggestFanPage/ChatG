import Link from "next/link";
import { redirect } from "next/navigation";
import GoWishlistLogo from "../../components/GoWishlistLogo";
import GoogleAuthButton from "../../components/GoogleAuthButton";
import { createClient } from "../../lib/supabase/server";

function getSafeNextPath(value?: string) {
  if (!value) {
    return "/dashboard";
  }

  if (
    !value.startsWith("/") ||
    value.startsWith("//") ||
    value.includes("\\")
  ) {
    return "/dashboard";
  }

  return value;
}

export default async function SignupPage({
  searchParams,
}: {
  searchParams: Promise<{
    error?: string;
    next?: string;
  }>;
}) {
  const query = await searchParams;

  const safeNext = getSafeNextPath(
    query.next
  );

  const supabase =
    await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (user) {
    redirect(safeNext);
  }

  const authError =
    query.error === "auth";

  const loginHref =
    safeNext === "/dashboard"
      ? "/login"
      : `/login?next=${encodeURIComponent(
          safeNext
        )}`;

  return (
    <main
      style={{
        minHeight: "100vh",
        background: "#f8fafc",
        color: "#111827",
      }}
    >
      <header
        style={{
          background: "#ffffff",
          borderBottom:
            "1px solid #e5e7eb",
        }}
      >
        <div
          style={{
            maxWidth: "900px",
            margin: "0 auto",
            padding: "20px 30px",
          }}
        >
          <GoWishlistLogo
            href="/home"
            size={29}
          />
        </div>
      </header>

      <section
        style={{
          maxWidth: "460px",
          margin: "0 auto",
          padding: "80px 30px",
        }}
      >
        <div
          style={{
            textAlign: "center",
            marginBottom: "28px",
          }}
        >
          <h1
            style={{
              margin: 0,
              fontSize: "40px",
              lineHeight: "1.1",
              letterSpacing: "-1.7px",
              fontWeight: "800",
            }}
          >
            Create your account
          </h1>

          <p
            style={{
              color: "#6b7280",
              fontSize: "16px",
              lineHeight: "1.6",
              margin: "12px 0 0",
            }}
          >
            Start creating and sharing your
            GoWishlist.
          </p>
        </div>

        <div
          style={{
            background: "#ffffff",
            border:
              "1px solid #e5e7eb",
            borderRadius: "20px",
            padding: "30px",
            boxShadow:
              "0 15px 40px rgba(0,0,0,0.06)",
          }}
        >
          {authError && (
            <div
              role="alert"
              style={{
                background: "#fef2f2",
                border:
                  "1px solid #fecaca",
                color: "#b91c1c",
                borderRadius: "11px",
                padding: "13px 14px",
                fontSize: "13px",
                fontWeight: "700",
                lineHeight: "1.5",
                marginBottom: "18px",
                textAlign: "center",
              }}
            >
              We couldn&apos;t complete your
              Google sign-up. Please try again.
            </div>
          )}

          <GoogleAuthButton
            next={safeNext}
          />

          <div
            style={{
              color: "#6b7280",
              fontSize: "13px",
              lineHeight: "1.55",
              textAlign: "center",
              marginTop: "18px",
            }}
          >
            Continue securely with your Google
            account.
          </div>

          <div
            style={{
              color: "#9ca3af",
              fontSize: "12px",
              lineHeight: "1.55",
              textAlign: "center",
              marginTop: "16px",
            }}
          >
            By signing up, you agree to our{" "}
            <Link
              href="/terms"
              style={{
                color: "#6b7280",
                fontWeight: "700",
                textDecoration:
                  "underline",
                textUnderlineOffset:
                  "2px",
              }}
            >
              Terms
            </Link>{" "}
            and{" "}
            <Link
              href="/privacy"
              style={{
                color: "#6b7280",
                fontWeight: "700",
                textDecoration:
                  "underline",
                textUnderlineOffset:
                  "2px",
              }}
            >
              Privacy Policy
            </Link>
            .
          </div>
        </div>

        <div
          style={{
            textAlign: "center",
            marginTop: "24px",
            color: "#6b7280",
            fontSize: "14px",
          }}
        >
          Already have an account?{" "}
          <Link
            href={loginHref}
            style={{
              color: "#2563eb",
              fontWeight: "800",
              textDecoration: "none",
            }}
          >
            Log In
          </Link>
        </div>
      </section>
    </main>
  );
}
