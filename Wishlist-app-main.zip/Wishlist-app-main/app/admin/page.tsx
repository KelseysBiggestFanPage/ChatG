import type { CSSProperties, ReactNode } from "react";
import Link from "next/link";
import { redirect } from "next/navigation";
import GoWishlistLogo from "../../components/GoWishlistLogo";
import { createAdminClient } from "../../lib/supabase/admin";
import { createClient } from "../../lib/supabase/server";

export const dynamic = "force-dynamic";

async function getTotalAuthUsers(
  admin: ReturnType<typeof createAdminClient>
) {
  const perPage = 100;
  let page = 1;
  let total = 0;

  while (true) {
    const { data, error } =
      await admin.auth.admin.listUsers({
        page,
        perPage,
      });

    if (error) {
      throw error;
    }

    const batch = data.users || [];
    total += batch.length;

    if (batch.length < perPage) {
      break;
    }

    page += 1;

    if (page > 1000) {
      break;
    }
  }

  return total;
}

export default async function AdminPage() {
  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/home");
  }

  const adminEmail =
    process.env.ADMIN_EMAIL?.trim().toLowerCase();

  const currentEmail =
    user.email?.trim().toLowerCase();

  if (
    !adminEmail ||
    !currentEmail ||
    currentEmail !== adminEmail
  ) {
    redirect("/dashboard");
  }

  const admin = createAdminClient();

  const { error: purgeError } =
    await admin.rpc(
      "purge_expired_deleted_data"
    );

  if (purgeError) {
    console.error(
      "Expired archive cleanup error:",
      purgeError
    );
  }

  const now = new Date().toISOString();

  const [
    totalUsers,
    wishlistsResult,
    giftsResult,
    reservationsResult,
    supportResult,
    deletedAccountsResult,
    deletedWishlistsResult,
  ] = await Promise.all([
    getTotalAuthUsers(admin),

    admin
      .from("wishlists")
      .select("*", {
        count: "exact",
        head: true,
      }),

    admin
      .from("gifts")
      .select("*", {
        count: "exact",
        head: true,
      }),

    admin
      .from("reservations")
      .select("*", {
        count: "exact",
        head: true,
      }),

    admin
      .from("support_tickets")
      .select("*", {
        count: "exact",
        head: true,
      })
      .eq("status", "new"),

    admin
      .from("deleted_accounts")
      .select("*", {
        count: "exact",
        head: true,
      })
      .is("restored_at", null)
      .gt("recover_until", now),

    admin
      .from("deleted_wishlists")
      .select("*", {
        count: "exact",
        head: true,
      })
      .is("restored_at", null)
      .gt("recover_until", now),
  ]);

  const totalWishlists =
    wishlistsResult.count || 0;

  const totalGifts =
    giftsResult.count || 0;

  const totalReservations =
    reservationsResult.count || 0;

  const newSupportTickets =
    supportResult.count || 0;

  const deletedAccounts =
    deletedAccountsResult.count || 0;

  const deletedWishlists =
    deletedWishlistsResult.count || 0;

  const { data: recentTickets } =
    await admin
      .from("support_tickets")
      .select(
        "id, name, email, message, status, created_at"
      )
      .order("created_at", {
        ascending: false,
      })
      .limit(5);

  async function logOut() {
    "use server";

    const supabase = await createClient();

    await supabase.auth.signOut();

    redirect("/home");
  }

  const stats = [
    ["Users", totalUsers],
    ["Wishlists", totalWishlists],
    ["Gifts", totalGifts],
    ["Reservations", totalReservations],
    ["New Support", newSupportTickets],
    ["Deleted Accounts", deletedAccounts],
    ["Deleted Wishlists", deletedWishlists],
  ] as const;

  return (
    <main
      style={{
        minHeight: "100vh",
        background: "#f8fafc",
        color: "#111827",
      }}
    >
      <header
        style={{
          background: "#ffffff",
          borderBottom:
            "1px solid #e5e7eb",
        }}
      >
        <div
          style={{
            maxWidth: "1200px",
            margin: "0 auto",
            padding: "20px 30px",
            display: "flex",
            justifyContent:
              "space-between",
            alignItems: "center",
            gap: "20px",
            flexWrap: "wrap",
          }}
        >
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "16px",
            }}
          >
            <GoWishlistLogo
              href="/dashboard"
              size={29}
            />

            <div
              style={{
                background: "#eff6ff",
                color: "#2563eb",
                border:
                  "1px solid #bfdbfe",
                borderRadius: "999px",
                padding: "6px 10px",
                fontSize: "11px",
                fontWeight: "900",
                letterSpacing: "0.6px",
              }}
            >
              ADMIN
            </div>
          </div>

          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "18px",
              flexWrap: "wrap",
            }}
          >
            <Link
              href="/dashboard"
              style={{
                color: "#374151",
                textDecoration: "none",
                fontSize: "14px",
                fontWeight: "700",
              }}
            >
              Dashboard
            </Link>

            <form action={logOut}>
              <button
                type="submit"
                style={{
                  background: "transparent",
                  border: "none",
                  color: "#6b7280",
                  fontSize: "14px",
                  fontWeight: "700",
                  cursor: "pointer",
                  padding: 0,
                }}
              >
                Log out
              </button>
            </form>
          </div>
        </div>
      </header>

      <section
        style={{
          maxWidth: "1200px",
          margin: "0 auto",
          padding: "50px 30px 90px",
        }}
      >
        <div
          style={{
            marginBottom: "34px",
          }}
        >
          <div
            style={{
              color: "#2563eb",
              fontSize: "12px",
              fontWeight: "900",
              letterSpacing: "1px",
              marginBottom: "8px",
            }}
          >
            GOWISHLIST ADMIN
          </div>

          <h1
            style={{
              margin: 0,
              fontSize: "42px",
              lineHeight: "1.1",
              fontWeight: "800",
              letterSpacing: "-1.8px",
            }}
          >
            Admin Dashboard
          </h1>

          <p
            style={{
              color: "#6b7280",
              fontSize: "15px",
              lineHeight: "1.6",
              margin: "12px 0 0",
            }}
          >
            Manage GoWishlist users,
            support requests, deleted
            accounts, and site activity.
          </p>
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns:
              "repeat(auto-fit, minmax(190px, 1fr))",
            gap: "16px",
            marginBottom: "38px",
          }}
        >
          {stats.map(([label, value]) => (
            <div
              key={label}
              style={{
                background: "#ffffff",
                border:
                  "1px solid #e5e7eb",
                borderRadius: "18px",
                padding: "22px",
                boxShadow:
                  "0 8px 25px rgba(0,0,0,0.035)",
              }}
            >
              <div
                style={{
                  color: "#6b7280",
                  fontSize: "12px",
                  fontWeight: "800",
                  letterSpacing: "0.4px",
                  marginBottom: "10px",
                }}
              >
                {label}
              </div>

              <div
                style={{
                  fontSize: "32px",
                  fontWeight: "900",
                  lineHeight: "1",
                  color: "#111827",
                }}
              >
                {value}
              </div>
            </div>
          ))}
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns:
              "repeat(auto-fit, minmax(min(100%, 250px), 1fr))",
            gap: "16px",
            marginBottom: "38px",
          }}
        >
          <Link
            href="/admin/users"
            style={sectionLinkStyle}
          >
            <AdminIcon letter="U" />

            <AdminCardTitle>
              Users
            </AdminCardTitle>

            <AdminCardText>
              View registered accounts,
              signup dates, wishlists,
              public links, and protection
              status.
            </AdminCardText>

            <AdminCardAction>
              Open Users →
            </AdminCardAction>
          </Link>

          <Link
            href="/admin/support"
            style={sectionLinkStyle}
          >
            <AdminIcon letter="S" />

            <AdminCardTitle>
              Support
            </AdminCardTitle>

            <AdminCardText>
              Read customer messages,
              copy email addresses, reply
              in Gmail, and manage ticket
              status.
            </AdminCardText>

            <AdminCardAction>
              Open Support →
            </AdminCardAction>
          </Link>

          <Link
            href="/admin/deleted"
            style={sectionLinkStyle}
          >
            <AdminIcon letter="D" />

            <AdminCardTitle>
              Deleted Data
            </AdminCardTitle>

            <AdminCardText>
              Recover deleted accounts
              and wishlists during the
              90-day recovery period.
            </AdminCardText>

            <AdminCardAction>
              Open Deleted Data →
            </AdminCardAction>
          </Link>

          <Link
            href="/admin/activity"
            style={sectionLinkStyle}
          >
            <AdminIcon letter="A" />

            <AdminCardTitle>
              Activity Log
            </AdminCardTitle>

            <AdminCardText>
              Track sensitive admin
              actions such as deletion,
              restoration, resets, and
              access-code changes.
            </AdminCardText>

            <AdminCardAction>
              Open Activity Log →
            </AdminCardAction>
          </Link>
        </div>

        <div
          style={{
            background: "#ffffff",
            border:
              "1px solid #e5e7eb",
            borderRadius: "20px",
            overflow: "hidden",
          }}
        >
          <div
            style={{
              padding: "22px 24px",
              borderBottom:
                "1px solid #e5e7eb",
              display: "flex",
              justifyContent:
                "space-between",
              alignItems: "center",
              gap: "15px",
              flexWrap: "wrap",
            }}
          >
            <div>
              <div
                style={{
                  fontSize: "19px",
                  fontWeight: "800",
                }}
              >
                Recent Support
              </div>

              <div
                style={{
                  color: "#6b7280",
                  fontSize: "12px",
                  marginTop: "4px",
                }}
              >
                Latest support requests
                submitted to GoWishlist
              </div>
            </div>

            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: "10px",
                flexWrap: "wrap",
              }}
            >
              <div
                style={{
                  background: "#eff6ff",
                  color: "#2563eb",
                  padding: "7px 10px",
                  borderRadius: "999px",
                  fontSize: "11px",
                  fontWeight: "900",
                }}
              >
                {newSupportTickets} NEW
              </div>

              <Link
                href="/admin/support"
                style={{
                  color: "#2563eb",
                  fontSize: "12px",
                  fontWeight: "800",
                  textDecoration: "none",
                }}
              >
                View All Support →
              </Link>
            </div>
          </div>

          {!recentTickets ||
          recentTickets.length === 0 ? (
            <div
              style={{
                padding: "40px 24px",
                textAlign: "center",
                color: "#6b7280",
                fontSize: "14px",
              }}
            >
              No support requests yet.
            </div>
          ) : (
            <div>
              {recentTickets.map((ticket) => (
                <div
                  key={ticket.id}
                  style={{
                    padding: "20px 24px",
                    borderBottom:
                      "1px solid #f1f5f9",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      justifyContent:
                        "space-between",
                      alignItems:
                        "flex-start",
                      gap: "20px",
                      flexWrap: "wrap",
                    }}
                  >
                    <div
                      style={{
                        minWidth: 0,
                      }}
                    >
                      <div
                        style={{
                          fontWeight: "800",
                          fontSize: "14px",
                        }}
                      >
                        {ticket.name}
                      </div>

                      <div
                        style={{
                          color: "#2563eb",
                          fontSize: "12px",
                          marginTop: "3px",
                          wordBreak:
                            "break-all",
                        }}
                      >
                        {ticket.email}
                      </div>
                    </div>

                    <span
                      style={{
                        background:
                          ticket.status ===
                          "new"
                            ? "#eff6ff"
                            : ticket.status ===
                                "handled"
                              ? "#ecfdf5"
                              : "#f3f4f6",
                        color:
                          ticket.status ===
                          "new"
                            ? "#2563eb"
                            : ticket.status ===
                                "handled"
                              ? "#047857"
                              : "#6b7280",
                        borderRadius:
                          "999px",
                        padding: "5px 8px",
                        fontSize: "10px",
                        fontWeight: "900",
                        textTransform:
                          "uppercase",
                      }}
                    >
                      {ticket.status}
                    </span>
                  </div>

                  <div
                    style={{
                      color: "#4b5563",
                      fontSize: "13px",
                      lineHeight: "1.55",
                      marginTop: "12px",
                      whiteSpace:
                        "pre-wrap",
                      overflowWrap:
                        "anywhere",
                    }}
                  >
                    {ticket.message.length > 240
                      ? `${ticket.message.slice(
                          0,
                          240
                        )}...`
                      : ticket.message}
                  </div>

                  <div
                    style={{
                      color: "#9ca3af",
                      fontSize: "11px",
                      marginTop: "10px",
                    }}
                  >
                    {new Date(
                      ticket.created_at
                    ).toLocaleString(
                      "en-US",
                      {
                        dateStyle: "medium",
                        timeStyle: "short",
                      }
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div
          style={{
            marginTop: "24px",
            padding: "16px 18px",
            background: "#eff6ff",
            border:
              "1px solid #bfdbfe",
            borderRadius: "14px",
            color: "#1e40af",
            fontSize: "13px",
            lineHeight: "1.55",
          }}
        >
          Admin access is verified on
          the server using your signed-in
          Supabase account and the
          server-only ADMIN_EMAIL
          environment variable.
        </div>
      </section>
    </main>
  );
}

function AdminIcon({
  letter,
}: {
  letter: string;
}) {
  return (
    <div
      style={{
        width: "42px",
        height: "42px",
        borderRadius: "12px",
        background: "#eff6ff",
        color: "#2563eb",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontWeight: "900",
        marginBottom: "16px",
      }}
    >
      {letter}
    </div>
  );
}

function AdminCardTitle({
  children,
}: {
  children: ReactNode;
}) {
  return (
    <div
      style={{
        fontSize: "19px",
        fontWeight: "800",
        marginBottom: "7px",
      }}
    >
      {children}
    </div>
  );
}

function AdminCardText({
  children,
}: {
  children: ReactNode;
}) {
  return (
    <div
      style={{
        color: "#6b7280",
        fontSize: "13px",
        lineHeight: "1.55",
      }}
    >
      {children}
    </div>
  );
}

function AdminCardAction({
  children,
}: {
  children: ReactNode;
}) {
  return (
    <div
      style={{
        color: "#2563eb",
        fontSize: "13px",
        fontWeight: "800",
        marginTop: "18px",
      }}
    >
      {children}
    </div>
  );
}

const sectionCardStyle: CSSProperties = {
  background: "#ffffff",
  border:
    "1px solid #e5e7eb",
  borderRadius: "18px",
  padding: "24px",
};

const sectionLinkStyle: CSSProperties = {
  ...sectionCardStyle,
  display: "block",
  textDecoration: "none",
  color: "inherit",
};
