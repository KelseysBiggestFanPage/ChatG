import Link from "next/link";
import { redirect } from "next/navigation";
import GoWishlistLogo from "../../../components/GoWishlistLogo";
import { createAdminClient } from "../../../lib/supabase/admin";
import { createClient } from "../../../lib/supabase/server";

export const dynamic = "force-dynamic";

type ActivityDetails = Record<string, unknown>;

type ActivityRow = {
  id: string;
  admin_user_id: string | null;
  admin_email: string;
  action: string;
  target_user_id: string | null;
  target_email: string | null;
  target_wishlist_id: string | null;
  details: ActivityDetails;
  created_at: string;
};

function formatDateTime(value: string) {
  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return "Unknown";
  }

  return new Intl.DateTimeFormat("en-US", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(date);
}

function getActionLabel(action: string) {
  if (action === "support_status_change") {
    return "Support Status Changed";
  }

  if (action === "restore_deleted_account") {
    return "Deleted Account Restored";
  }

  if (action === "restore_deleted_wishlist") {
    return "Deleted Wishlist Restored";
  }

  return action
    .split("_")
    .filter(Boolean)
    .map(
      (part) =>
        part.charAt(0).toUpperCase() +
        part.slice(1)
    )
    .join(" ");
}

function getActionStyle(action: string) {
  if (action === "support_status_change") {
    return {
      background: "#eff6ff",
      color: "#2563eb",
      border: "1px solid #bfdbfe",
    };
  }

  if (action === "restore_deleted_account") {
    return {
      background: "#ecfdf5",
      color: "#047857",
      border: "1px solid #a7f3d0",
    };
  }

  if (action === "restore_deleted_wishlist") {
    return {
      background: "#f0fdf4",
      color: "#166534",
      border: "1px solid #bbf7d0",
    };
  }

  return {
    background: "#f3f4f6",
    color: "#4b5563",
    border: "1px solid #d1d5db",
  };
}

function humanizeDetailKey(key: string) {
  return key
    .split("_")
    .filter(Boolean)
    .map(
      (part) =>
        part.charAt(0).toUpperCase() +
        part.slice(1)
    )
    .join(" ");
}

function formatDetailValue(value: unknown) {
  if (value === null || value === undefined) {
    return "—";
  }

  if (typeof value === "boolean") {
    return value ? "Yes" : "No";
  }

  if (
    typeof value === "string" ||
    typeof value === "number"
  ) {
    return String(value);
  }

  try {
    return JSON.stringify(value);
  } catch {
    return String(value);
  }
}

export default async function AdminActivityPage({
  searchParams,
}: {
  searchParams: Promise<{
    q?: string;
    action?: string;
  }>;
}) {
  const query = await searchParams;

  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/home");
  }

  const adminEmail =
    process.env.ADMIN_EMAIL?.trim().toLowerCase();

  const currentEmail =
    user.email?.trim().toLowerCase();

  if (
    !adminEmail ||
    !currentEmail ||
    currentEmail !== adminEmail
  ) {
    redirect("/dashboard");
  }

  const admin = createAdminClient();

  const allowedActions = [
    "all",
    "support_status_change",
    "restore_deleted_account",
    "restore_deleted_wishlist",
  ];

  const requestedAction = String(
    query.action || "all"
  ).trim();

  const actionFilter = allowedActions.includes(
    requestedAction
  )
    ? requestedAction
    : "all";

  const search = String(query.q || "")
    .trim()
    .toLowerCase();

  const [
    totalResult,
    supportResult,
    accountRestoreResult,
    wishlistRestoreResult,
  ] = await Promise.all([
    admin
      .from("admin_activity_log")
      .select("*", {
        count: "exact",
        head: true,
      }),

    admin
      .from("admin_activity_log")
      .select("*", {
        count: "exact",
        head: true,
      })
      .eq("action", "support_status_change"),

    admin
      .from("admin_activity_log")
      .select("*", {
        count: "exact",
        head: true,
      })
      .eq("action", "restore_deleted_account"),

    admin
      .from("admin_activity_log")
      .select("*", {
        count: "exact",
        head: true,
      })
      .eq("action", "restore_deleted_wishlist"),
  ]);

  let activityQuery = admin
    .from("admin_activity_log")
    .select(
      "id, admin_user_id, admin_email, action, target_user_id, target_email, target_wishlist_id, details, created_at"
    )
    .order("created_at", {
      ascending: false,
    })
    .limit(500);

  if (actionFilter !== "all") {
    activityQuery = activityQuery.eq(
      "action",
      actionFilter
    );
  }

  const {
    data: activityData,
    error: activityError,
  } = await activityQuery;

  if (activityError) {
    console.error(
      "Admin activity log load error:",
      activityError
    );
  }

  const allRows = (activityData || []) as ActivityRow[];

  const rows = search
    ? allRows.filter((row) => {
        const detailsText = (() => {
          try {
            return JSON.stringify(row.details || {});
          } catch {
            return "";
          }
        })().toLowerCase();

        return (
          row.admin_email
            .toLowerCase()
            .includes(search) ||
          row.action
            .toLowerCase()
            .includes(search) ||
          String(row.target_email || "")
            .toLowerCase()
            .includes(search) ||
          String(row.target_user_id || "")
            .toLowerCase()
            .includes(search) ||
          String(row.target_wishlist_id || "")
            .toLowerCase()
            .includes(search) ||
          detailsText.includes(search)
        );
      })
    : allRows;

  const totalCount = totalResult.count || 0;
  const supportCount = supportResult.count || 0;
  const accountRestoreCount =
    accountRestoreResult.count || 0;
  const wishlistRestoreCount =
    wishlistRestoreResult.count || 0;

  const filters = [
    {
      value: "all",
      label: "All Activity",
      count: totalCount,
    },
    {
      value: "support_status_change",
      label: "Support",
      count: supportCount,
    },
    {
      value: "restore_deleted_account",
      label: "Account Restores",
      count: accountRestoreCount,
    },
    {
      value: "restore_deleted_wishlist",
      label: "Wishlist Restores",
      count: wishlistRestoreCount,
    },
  ];

  return (
    <main
      style={{
        minHeight: "100vh",
        background: "#f8fafc",
        color: "#111827",
      }}
    >
      <header
        style={{
          background: "#ffffff",
          borderBottom: "1px solid #e5e7eb",
        }}
      >
        <div
          style={{
            maxWidth: "1200px",
            margin: "0 auto",
            padding: "20px 30px",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            gap: "20px",
            flexWrap: "wrap",
          }}
        >
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "16px",
            }}
          >
            <GoWishlistLogo
              href="/dashboard"
              size={29}
            />

            <div
              style={{
                background: "#eff6ff",
                color: "#2563eb",
                border: "1px solid #bfdbfe",
                borderRadius: "999px",
                padding: "6px 10px",
                fontSize: "11px",
                fontWeight: "900",
                letterSpacing: "0.6px",
              }}
            >
              ADMIN
            </div>
          </div>

          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "16px",
              flexWrap: "wrap",
            }}
          >
            <Link
              href="/admin"
              style={{
                color: "#2563eb",
                textDecoration: "none",
                fontSize: "14px",
                fontWeight: "800",
              }}
            >
              Overview
            </Link>

            <Link
              href="/admin/users"
              style={{
                color: "#374151",
                textDecoration: "none",
                fontSize: "14px",
                fontWeight: "700",
              }}
            >
              Users
            </Link>

            <Link
              href="/admin/support"
              style={{
                color: "#374151",
                textDecoration: "none",
                fontSize: "14px",
                fontWeight: "700",
              }}
            >
              Support
            </Link>

            <Link
              href="/admin/deleted"
              style={{
                color: "#374151",
                textDecoration: "none",
                fontSize: "14px",
                fontWeight: "700",
              }}
            >
              Deleted Data
            </Link>

            <Link
              href="/dashboard"
              style={{
                color: "#6b7280",
                textDecoration: "none",
                fontSize: "14px",
                fontWeight: "700",
              }}
            >
              Dashboard
            </Link>
          </div>
        </div>
      </header>

      <section
        style={{
          maxWidth: "1200px",
          margin: "0 auto",
          padding: "50px 30px 90px",
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "flex-end",
            gap: "20px",
            flexWrap: "wrap",
            marginBottom: "28px",
          }}
        >
          <div>
            <div
              style={{
                color: "#2563eb",
                fontSize: "12px",
                fontWeight: "900",
                letterSpacing: "0.8px",
                marginBottom: "7px",
              }}
            >
              ADMIN SECURITY
            </div>

            <h1
              style={{
                margin: 0,
                fontSize: "40px",
                lineHeight: "1.1",
                fontWeight: "800",
                letterSpacing: "-1.6px",
              }}
            >
              Activity Log
            </h1>

            <p
              style={{
                color: "#6b7280",
                fontSize: "14px",
                lineHeight: "1.6",
                margin: "10px 0 0",
                maxWidth: "680px",
              }}
            >
              Review recorded admin actions such as support status changes and recovery operations.
            </p>
          </div>

          <form
            method="get"
            style={{
              display: "flex",
              gap: "8px",
              flexWrap: "wrap",
            }}
          >
            {actionFilter !== "all" && (
              <input
                type="hidden"
                name="action"
                value={actionFilter}
              />
            )}

            <input
              type="search"
              name="q"
              defaultValue={query.q || ""}
              placeholder="Search email, ID, or details"
              style={{
                width: "280px",
                maxWidth: "100%",
                border: "1px solid #d1d5db",
                borderRadius: "10px",
                padding: "11px 13px",
                fontSize: "14px",
                outline: "none",
              }}
            />

            <button
              type="submit"
              style={{
                background: "#2563eb",
                color: "#ffffff",
                border: "none",
                borderRadius: "10px",
                padding: "11px 16px",
                fontSize: "14px",
                fontWeight: "800",
                cursor: "pointer",
              }}
            >
              Search
            </button>

            {search && (
              <Link
                href={
                  actionFilter === "all"
                    ? "/admin/activity"
                    : `/admin/activity?action=${encodeURIComponent(
                        actionFilter
                      )}`
                }
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  justifyContent: "center",
                  color: "#374151",
                  background: "#ffffff",
                  border: "1px solid #d1d5db",
                  borderRadius: "10px",
                  padding: "11px 16px",
                  fontSize: "14px",
                  fontWeight: "700",
                  textDecoration: "none",
                }}
              >
                Clear
              </Link>
            )}
          </form>
        </div>

        <div
          style={{
            display: "flex",
            gap: "9px",
            flexWrap: "wrap",
            marginBottom: "28px",
          }}
        >
          {filters.map((filter) => {
            const active =
              actionFilter === filter.value;

            const href =
              filter.value === "all"
                ? search
                  ? `/admin/activity?q=${encodeURIComponent(
                      search
                    )}`
                  : "/admin/activity"
                : `/admin/activity?action=${encodeURIComponent(
                    filter.value
                  )}${
                    search
                      ? `&q=${encodeURIComponent(search)}`
                      : ""
                  }`;

            return (
              <Link
                key={filter.value}
                href={href}
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  gap: "7px",
                  background: active
                    ? "#2563eb"
                    : "#ffffff",
                  color: active
                    ? "#ffffff"
                    : "#374151",
                  border: active
                    ? "1px solid #2563eb"
                    : "1px solid #d1d5db",
                  borderRadius: "999px",
                  padding: "9px 13px",
                  fontSize: "13px",
                  fontWeight: "800",
                  textDecoration: "none",
                }}
              >
                {filter.label}

                <span
                  style={{
                    minWidth: "20px",
                    height: "20px",
                    borderRadius: "999px",
                    display: "inline-flex",
                    alignItems: "center",
                    justifyContent: "center",
                    padding: "0 5px",
                    background: active
                      ? "rgba(255,255,255,0.18)"
                      : "#f3f4f6",
                    color: active
                      ? "#ffffff"
                      : "#6b7280",
                    fontSize: "10px",
                    fontWeight: "900",
                  }}
                >
                  {filter.count}
                </span>
              </Link>
            );
          })}
        </div>

        {rows.length === 0 ? (
          <div
            style={{
              background: "#ffffff",
              border: "1px solid #e5e7eb",
              borderRadius: "18px",
              padding: "48px 24px",
              textAlign: "center",
              color: "#6b7280",
            }}
          >
            {search
              ? "No admin activity matches your search."
              : actionFilter === "all"
                ? "No admin activity has been recorded yet."
                : "No activity has been recorded for this category yet."}
          </div>
        ) : (
          <div
            style={{
              display: "grid",
              gap: "16px",
            }}
          >
            {rows.map((row) => {
              const actionStyle =
                getActionStyle(row.action);

              const details = Object.entries(
                row.details || {}
              );

              return (
                <article
                  key={row.id}
                  style={{
                    background: "#ffffff",
                    border: "1px solid #e5e7eb",
                    borderRadius: "18px",
                    padding: "24px",
                    boxShadow:
                      "0 8px 25px rgba(0,0,0,0.035)",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "flex-start",
                      gap: "18px",
                      flexWrap: "wrap",
                    }}
                  >
                    <div
                      style={{
                        minWidth: 0,
                        flex: "1 1 420px",
                      }}
                    >
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: "8px",
                          flexWrap: "wrap",
                          marginBottom: "8px",
                        }}
                      >
                        <span
                          style={{
                            ...actionStyle,
                            borderRadius: "999px",
                            padding: "5px 9px",
                            fontSize: "10px",
                            fontWeight: "900",
                            textTransform: "uppercase",
                          }}
                        >
                          {getActionLabel(row.action)}
                        </span>
                      </div>

                      <div
                        style={{
                          fontSize: "17px",
                          fontWeight: "800",
                          overflowWrap: "anywhere",
                        }}
                      >
                        {row.admin_email}
                      </div>

                      <div
                        style={{
                          color: "#9ca3af",
                          fontSize: "11px",
                          marginTop: "6px",
                        }}
                      >
                        {formatDateTime(row.created_at)}
                      </div>
                    </div>

                    <div
                      style={{
                        background: "#f8fafc",
                        border: "1px solid #e5e7eb",
                        borderRadius: "11px",
                        padding: "10px 12px",
                        color: "#6b7280",
                        fontSize: "11px",
                        lineHeight: "1.5",
                        overflowWrap: "anywhere",
                      }}
                    >
                      Log ID: {row.id}
                    </div>
                  </div>

                  <div
                    style={{
                      display: "grid",
                      gridTemplateColumns:
                        "repeat(auto-fit, minmax(min(100%, 230px), 1fr))",
                      gap: "10px",
                      marginTop: "20px",
                    }}
                  >
                    {row.target_email && (
                      <div
                        style={{
                          background: "#f8fafc",
                          border: "1px solid #e5e7eb",
                          borderRadius: "11px",
                          padding: "12px",
                        }}
                      >
                        <div
                          style={{
                            color: "#9ca3af",
                            fontSize: "10px",
                            fontWeight: "900",
                            marginBottom: "5px",
                          }}
                        >
                          TARGET EMAIL
                        </div>

                        <div
                          style={{
                            color: "#374151",
                            fontSize: "12px",
                            fontWeight: "700",
                            overflowWrap: "anywhere",
                          }}
                        >
                          {row.target_email}
                        </div>
                      </div>
                    )}

                    {row.target_user_id && (
                      <div
                        style={{
                          background: "#f8fafc",
                          border: "1px solid #e5e7eb",
                          borderRadius: "11px",
                          padding: "12px",
                        }}
                      >
                        <div
                          style={{
                            color: "#9ca3af",
                            fontSize: "10px",
                            fontWeight: "900",
                            marginBottom: "5px",
                          }}
                        >
                          TARGET USER ID
                        </div>

                        <div
                          style={{
                            color: "#374151",
                            fontSize: "11px",
                            fontWeight: "700",
                            overflowWrap: "anywhere",
                          }}
                        >
                          {row.target_user_id}
                        </div>
                      </div>
                    )}

                    {row.target_wishlist_id && (
                      <div
                        style={{
                          background: "#f8fafc",
                          border: "1px solid #e5e7eb",
                          borderRadius: "11px",
                          padding: "12px",
                        }}
                      >
                        <div
                          style={{
                            color: "#9ca3af",
                            fontSize: "10px",
                            fontWeight: "900",
                            marginBottom: "5px",
                          }}
                        >
                          TARGET WISHLIST ID
                        </div>

                        <div
                          style={{
                            color: "#374151",
                            fontSize: "11px",
                            fontWeight: "700",
                            overflowWrap: "anywhere",
                          }}
                        >
                          {row.target_wishlist_id}
                        </div>
                      </div>
                    )}
                  </div>

                  {details.length > 0 && (
                    <div
                      style={{
                        borderTop: "1px solid #e5e7eb",
                        marginTop: "20px",
                        paddingTop: "18px",
                      }}
                    >
                      <div
                        style={{
                          color: "#6b7280",
                          fontSize: "11px",
                          fontWeight: "900",
                          marginBottom: "10px",
                        }}
                      >
                        DETAILS
                      </div>

                      <div
                        style={{
                          display: "grid",
                          gridTemplateColumns:
                            "repeat(auto-fit, minmax(min(100%, 220px), 1fr))",
                          gap: "9px",
                        }}
                      >
                        {details.map(([key, value]) => (
                          <div
                            key={key}
                            style={{
                              background: "#f8fafc",
                              border: "1px solid #e5e7eb",
                              borderRadius: "10px",
                              padding: "11px",
                            }}
                          >
                            <div
                              style={{
                                color: "#9ca3af",
                                fontSize: "10px",
                                fontWeight: "900",
                                marginBottom: "4px",
                              }}
                            >
                              {humanizeDetailKey(key)}
                            </div>

                            <div
                              style={{
                                color: "#374151",
                                fontSize: "12px",
                                fontWeight: "700",
                                lineHeight: "1.5",
                                overflowWrap: "anywhere",
                              }}
                            >
                              {formatDetailValue(value)}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </article>
              );
            })}
          </div>
        )}

        <div
          style={{
            marginTop: "28px",
            padding: "15px 17px",
            background: "#eff6ff",
            border: "1px solid #bfdbfe",
            borderRadius: "13px",
            color: "#1e40af",
            fontSize: "12px",
            lineHeight: "1.6",
          }}
        >
          This page is read-only. Admin actions are written by server-side GoWishlist actions using the service role, while normal users cannot read or write the activity log directly.
        </div>
      </section>
    </main>
  );
}
