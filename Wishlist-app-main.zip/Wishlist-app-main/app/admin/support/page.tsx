import Link from "next/link";
import {
  redirect,
} from "next/navigation";
import AdminSupportActions from "../../../components/AdminSupportActions";
import GoWishlistLogo from "../../../components/GoWishlistLogo";
import { createAdminClient } from "../../../lib/supabase/admin";
import { createClient } from "../../../lib/supabase/server";

export const dynamic = "force-dynamic";

type TicketStatus =
  | "new"
  | "handled"
  | "closed";

type SupportTicket = {
  id: string;
  user_id: string | null;
  name: string;
  email: string;
  message: string;
  status: TicketStatus;
  source_path: string | null;
  created_at: string;
  updated_at: string;
  handled_at: string | null;
};

function formatDateTime(
  value: string
) {
  const date =
    new Date(value);

  if (
    Number.isNaN(
      date.getTime()
    )
  ) {
    return "Unknown";
  }

  return new Intl.DateTimeFormat(
    "en-US",
    {
      dateStyle: "medium",
      timeStyle: "short",
    }
  ).format(date);
}

function getStatusStyle(
  status: TicketStatus
) {
  if (status === "new") {
    return {
      background: "#eff6ff",
      color: "#2563eb",
      border:
        "1px solid #bfdbfe",
    };
  }

  if (
    status === "handled"
  ) {
    return {
      background: "#ecfdf5",
      color: "#047857",
      border:
        "1px solid #a7f3d0",
    };
  }

  return {
    background: "#f3f4f6",
    color: "#6b7280",
    border:
      "1px solid #d1d5db",
  };
}

export default async function AdminSupportPage({
  searchParams,
}: {
  searchParams: Promise<{
    status?: string;
    q?: string;
  }>;
}) {
  const query =
    await searchParams;

  const supabase =
    await createClient();

  const {
    data: { user },
  } =
    await supabase.auth.getUser();

  if (!user) {
    redirect("/home");
  }

  const adminEmail =
    process.env.ADMIN_EMAIL
      ?.trim()
      .toLowerCase();

  const currentEmail =
    user.email
      ?.trim()
      .toLowerCase();

  if (
    !adminEmail ||
    !currentEmail ||
    currentEmail !==
      adminEmail
  ) {
    redirect("/dashboard");
  }

  const validStatuses = [
    "all",
    "new",
    "handled",
    "closed",
  ];

  const requestedStatus =
    String(
      query.status || "all"
    ).toLowerCase();

  const statusFilter =
    validStatuses.includes(
      requestedStatus
    )
      ? requestedStatus
      : "all";

  const search =
    String(
      query.q || ""
    )
      .trim()
      .toLowerCase();

  const admin =
    createAdminClient();

  const [
    newCountResult,
    handledCountResult,
    closedCountResult,
  ] = await Promise.all([
    admin
      .from("support_tickets")
      .select("*", {
        count: "exact",
        head: true,
      })
      .eq("status", "new"),

    admin
      .from("support_tickets")
      .select("*", {
        count: "exact",
        head: true,
      })
      .eq(
        "status",
        "handled"
      ),

    admin
      .from("support_tickets")
      .select("*", {
        count: "exact",
        head: true,
      })
      .eq(
        "status",
        "closed"
      ),
  ]);

  let ticketQuery =
    admin
      .from(
        "support_tickets"
      )
      .select(
        "id, user_id, name, email, message, status, source_path, created_at, updated_at, handled_at"
      )
      .order(
        "created_at",
        {
          ascending: false,
        }
      )
      .limit(500);

  if (
    statusFilter !== "all"
  ) {
    ticketQuery =
      ticketQuery.eq(
        "status",
        statusFilter
      );
  }

  const {
    data: ticketData,
    error: ticketsError,
  } = await ticketQuery;

  if (ticketsError) {
    console.error(
      "Admin support load error:",
      ticketsError
    );
  }

  const allTickets =
    (ticketData ||
      []) as SupportTicket[];

  const tickets =
    search
      ? allTickets.filter(
          (ticket) =>
            ticket.name
              .toLowerCase()
              .includes(
                search
              ) ||
            ticket.email
              .toLowerCase()
              .includes(
                search
              ) ||
            ticket.message
              .toLowerCase()
              .includes(
                search
              )
        )
      : allTickets;

  const newCount =
    newCountResult.count ||
    0;

  const handledCount =
    handledCountResult.count ||
    0;

  const closedCount =
    closedCountResult.count ||
    0;

  const totalCount =
    newCount +
    handledCount +
    closedCount;

  async function updateTicketStatus(
    formData: FormData
  ) {
    "use server";

    const supabase =
      await createClient();

    const {
      data: { user },
    } =
      await supabase.auth.getUser();

    if (!user) {
      redirect("/home");
    }

    const adminEmail =
      process.env.ADMIN_EMAIL
        ?.trim()
        .toLowerCase();

    const currentEmail =
      user.email
        ?.trim()
        .toLowerCase();

    if (
      !adminEmail ||
      !currentEmail ||
      currentEmail !==
        adminEmail
    ) {
      redirect(
        "/dashboard"
      );
    }

    const ticketId =
      String(
        formData.get(
          "ticketId"
        ) || ""
      ).trim();

    const newStatus =
      String(
        formData.get(
          "newStatus"
        ) || ""
      ).trim();

    const returnStatus =
      String(
        formData.get(
          "returnStatus"
        ) || "all"
      ).trim();

    const returnSearch =
      String(
        formData.get(
          "returnSearch"
        ) || ""
      ).trim();

    if (
      !ticketId ||
      ![
        "new",
        "handled",
        "closed",
      ].includes(
        newStatus
      )
    ) {
      redirect(
        "/admin/support"
      );
    }

    const admin =
      createAdminClient();

    const {
      data: currentTicket,
      error:
        currentTicketError,
    } = await admin
      .from(
        "support_tickets"
      )
      .select(
        "id, user_id, email, status, handled_at"
      )
      .eq(
        "id",
        ticketId
      )
      .maybeSingle();

    if (
      currentTicketError ||
      !currentTicket
    ) {
      console.error(
        "Support ticket lookup error:",
        currentTicketError
      );

      redirect(
        "/admin/support"
      );
    }

    if (
      currentTicket.status !==
      newStatus
    ) {
      const now =
        new Date()
          .toISOString();

      const handledAt =
        newStatus ===
        "new"
          ? null
          : currentTicket
              .handled_at ||
            now;

      const {
        error: updateError,
      } = await admin
        .from(
          "support_tickets"
        )
        .update({
          status:
            newStatus,
          handled_at:
            handledAt,
          updated_at:
            now,
        })
        .eq(
          "id",
          ticketId
        );

      if (updateError) {
        console.error(
          "Support status update error:",
          updateError
        );
      } else {
        const {
          error: logError,
        } = await admin
          .from(
            "admin_activity_log"
          )
          .insert({
            admin_user_id:
              user.id,
            admin_email:
              currentEmail,
            action:
              "support_status_change",
            target_user_id:
              currentTicket.user_id,
            target_email:
              currentTicket.email,
            details: {
              ticket_id:
                ticketId,
              previous_status:
                currentTicket.status,
              new_status:
                newStatus,
            },
          });

        if (logError) {
          console.error(
            "Support activity log error:",
            logError
          );
        }
      }
    }

    const nextParams =
      new URLSearchParams();

    if (
      [
        "all",
        "new",
        "handled",
        "closed",
      ].includes(
        returnStatus
      ) &&
      returnStatus !==
        "all"
    ) {
      nextParams.set(
        "status",
        returnStatus
      );
    }

    if (returnSearch) {
      nextParams.set(
        "q",
        returnSearch
      );
    }

    const queryString =
      nextParams.toString();

    redirect(
      queryString
        ? `/admin/support?${queryString}`
        : "/admin/support"
    );
  }

  const tabs = [
    {
      label: "All",
      value: "all",
      count: totalCount,
    },
    {
      label: "New",
      value: "new",
      count: newCount,
    },
    {
      label: "Handled",
      value: "handled",
      count:
        handledCount,
    },
    {
      label: "Closed",
      value: "closed",
      count:
        closedCount,
    },
  ];

  return (
    <main
      style={{
        minHeight:
          "100vh",
        background:
          "#f8fafc",
        color:
          "#111827",
      }}
    >
      <header
        style={{
          background:
            "#ffffff",
          borderBottom:
            "1px solid #e5e7eb",
        }}
      >
        <div
          style={{
            maxWidth:
              "1200px",
            margin:
              "0 auto",
            padding:
              "20px 30px",
            display:
              "flex",
            justifyContent:
              "space-between",
            alignItems:
              "center",
            gap:
              "20px",
            flexWrap:
              "wrap",
          }}
        >
          <div
            style={{
              display:
                "flex",
              alignItems:
                "center",
              gap:
                "16px",
            }}
          >
            <GoWishlistLogo
              href="/dashboard"
              size={29}
            />

            <div
              style={{
                background:
                  "#eff6ff",
                color:
                  "#2563eb",
                border:
                  "1px solid #bfdbfe",
                borderRadius:
                  "999px",
                padding:
                  "6px 10px",
                fontSize:
                  "11px",
                fontWeight:
                  "900",
                letterSpacing:
                  "0.6px",
              }}
            >
              ADMIN
            </div>
          </div>

          <div
            style={{
              display:
                "flex",
              alignItems:
                "center",
              gap:
                "16px",
              flexWrap:
                "wrap",
            }}
          >
            <Link
              href="/admin"
              style={{
                color:
                  "#2563eb",
                textDecoration:
                  "none",
                fontSize:
                  "14px",
                fontWeight:
                  "800",
              }}
            >
              Overview
            </Link>

            <Link
              href="/admin/users"
              style={{
                color:
                  "#374151",
                textDecoration:
                  "none",
                fontSize:
                  "14px",
                fontWeight:
                  "700",
              }}
            >
              Users
            </Link>

            <Link
              href="/dashboard"
              style={{
                color:
                  "#6b7280",
                textDecoration:
                  "none",
                fontSize:
                  "14px",
                fontWeight:
                  "700",
              }}
            >
              Dashboard
            </Link>
          </div>
        </div>
      </header>

      <section
        style={{
          maxWidth:
            "1200px",
          margin:
            "0 auto",
          padding:
            "50px 30px 90px",
        }}
      >
        <div
          style={{
            display:
              "flex",
            justifyContent:
              "space-between",
            alignItems:
              "flex-end",
            gap:
              "20px",
            flexWrap:
              "wrap",
            marginBottom:
              "26px",
          }}
        >
          <div>
            <div
              style={{
                color:
                  "#2563eb",
                fontSize:
                  "12px",
                fontWeight:
                  "900",
                letterSpacing:
                  "0.8px",
                marginBottom:
                  "7px",
              }}
            >
              ADMIN SUPPORT
            </div>

            <h1
              style={{
                margin: 0,
                fontSize:
                  "40px",
                lineHeight:
                  "1.1",
                fontWeight:
                  "800",
                letterSpacing:
                  "-1.6px",
              }}
            >
              Support Inbox
            </h1>

            <p
              style={{
                color:
                  "#6b7280",
                fontSize:
                  "14px",
                lineHeight:
                  "1.6",
                margin:
                  "10px 0 0",
              }}
            >
              Review GoWishlist
              support requests and
              reply to customers
              through Gmail.
            </p>
          </div>

          <form
            method="get"
            style={{
              display:
                "flex",
              gap:
                "8px",
              flexWrap:
                "wrap",
            }}
          >
            {statusFilter !==
              "all" && (
              <input
                type="hidden"
                name="status"
                value={
                  statusFilter
                }
              />
            )}

            <input
              type="search"
              name="q"
              defaultValue={
                query.q || ""
              }
              placeholder="Search support"
              style={{
                width:
                  "250px",
                maxWidth:
                  "100%",
                border:
                  "1px solid #d1d5db",
                borderRadius:
                  "10px",
                padding:
                  "11px 13px",
                fontSize:
                  "14px",
                outline:
                  "none",
              }}
            />

            <button
              type="submit"
              style={{
                background:
                  "#2563eb",
                color:
                  "#ffffff",
                border:
                  "none",
                borderRadius:
                  "10px",
                padding:
                  "11px 16px",
                fontSize:
                  "14px",
                fontWeight:
                  "800",
                cursor:
                  "pointer",
              }}
            >
              Search
            </button>

            {search && (
              <Link
                href={
                  statusFilter ===
                  "all"
                    ? "/admin/support"
                    : `/admin/support?status=${statusFilter}`
                }
                style={{
                  display:
                    "inline-flex",
                  alignItems:
                    "center",
                  justifyContent:
                    "center",
                  background:
                    "#ffffff",
                  color:
                    "#374151",
                  border:
                    "1px solid #d1d5db",
                  borderRadius:
                    "10px",
                  padding:
                    "11px 15px",
                  fontSize:
                    "14px",
                  fontWeight:
                    "700",
                  textDecoration:
                    "none",
                }}
              >
                Clear
              </Link>
            )}
          </form>
        </div>

        <div
          style={{
            display:
              "flex",
            gap:
              "9px",
            flexWrap:
              "wrap",
            marginBottom:
              "28px",
          }}
        >
          {tabs.map(
            (tab) => {
              const active =
                statusFilter ===
                tab.value;

              const href =
                tab.value ===
                "all"
                  ? search
                    ? `/admin/support?q=${encodeURIComponent(
                        search
                      )}`
                    : "/admin/support"
                  : `/admin/support?status=${tab.value}${
                      search
                        ? `&q=${encodeURIComponent(
                            search
                          )}`
                        : ""
                    }`;

              return (
                <Link
                  key={
                    tab.value
                  }
                  href={href}
                  style={{
                    display:
                      "inline-flex",
                    alignItems:
                      "center",
                    gap:
                      "7px",
                    background:
                      active
                        ? "#2563eb"
                        : "#ffffff",
                    color:
                      active
                        ? "#ffffff"
                        : "#374151",
                    border:
                      active
                        ? "1px solid #2563eb"
                        : "1px solid #d1d5db",
                    borderRadius:
                      "999px",
                    padding:
                      "9px 13px",
                    fontSize:
                      "13px",
                    fontWeight:
                      "800",
                    textDecoration:
                      "none",
                  }}
                >
                  {tab.label}

                  <span
                    style={{
                      minWidth:
                        "20px",
                      height:
                        "20px",
                      borderRadius:
                        "999px",
                      display:
                        "inline-flex",
                      alignItems:
                        "center",
                      justifyContent:
                        "center",
                      padding:
                        "0 5px",
                      background:
                        active
                          ? "rgba(255,255,255,0.18)"
                          : "#f3f4f6",
                      color:
                        active
                          ? "#ffffff"
                          : "#6b7280",
                      fontSize:
                        "10px",
                      fontWeight:
                        "900",
                    }}
                  >
                    {
                      tab.count
                    }
                  </span>
                </Link>
              );
            }
          )}
        </div>

        {tickets.length ===
        0 ? (
          <div
            style={{
              background:
                "#ffffff",
              border:
                "1px solid #e5e7eb",
              borderRadius:
                "18px",
              padding:
                "48px 24px",
              textAlign:
                "center",
              color:
                "#6b7280",
            }}
          >
            {search
              ? "No support requests match your search."
              : statusFilter ===
                  "all"
                ? "No support requests yet."
                : `No ${statusFilter} support requests.`}
          </div>
        ) : (
          <div
            style={{
              display:
                "grid",
              gap:
                "18px",
            }}
          >
            {tickets.map(
              (ticket) => {
                const statusStyle =
                  getStatusStyle(
                    ticket.status
                  );

                return (
                  <article
                    key={
                      ticket.id
                    }
                    style={{
                      background:
                        "#ffffff",
                      border:
                        "1px solid #e5e7eb",
                      borderRadius:
                        "18px",
                      padding:
                        "24px",
                      boxShadow:
                        "0 8px 25px rgba(0,0,0,0.035)",
                    }}
                  >
                    <div
                      style={{
                        display:
                          "flex",
                        justifyContent:
                          "space-between",
                        alignItems:
                          "flex-start",
                        gap:
                          "18px",
                        flexWrap:
                          "wrap",
                      }}
                    >
                      <div
                        style={{
                          minWidth:
                            0,
                        }}
                      >
                        <div
                          style={{
                            display:
                              "flex",
                            alignItems:
                              "center",
                            gap:
                              "8px",
                            flexWrap:
                              "wrap",
                            marginBottom:
                              "5px",
                          }}
                        >
                          <h2
                            style={{
                              margin:
                                0,
                              fontSize:
                                "20px",
                              fontWeight:
                                "800",
                            }}
                          >
                            {
                              ticket.name
                            }
                          </h2>

                          <span
                            style={{
                              ...statusStyle,
                              borderRadius:
                                "999px",
                              padding:
                                "5px 9px",
                              fontSize:
                                "10px",
                              fontWeight:
                                "900",
                              textTransform:
                                "uppercase",
                            }}
                          >
                            {
                              ticket.status
                            }
                          </span>

                          {ticket.user_id && (
                            <span
                              style={{
                                background:
                                  "#f8fafc",
                                color:
                                  "#6b7280",
                                border:
                                  "1px solid #e5e7eb",
                                borderRadius:
                                  "999px",
                                padding:
                                  "5px 9px",
                                fontSize:
                                  "10px",
                                fontWeight:
                                  "800",
                              }}
                            >
                              SIGNED IN
                            </span>
                          )}
                        </div>

                        <div
                          style={{
                            color:
                              "#4b5563",
                            fontSize:
                              "14px",
                            overflowWrap:
                              "anywhere",
                          }}
                        >
                          {
                            ticket.email
                          }
                        </div>

                        <div
                          style={{
                            color:
                              "#9ca3af",
                            fontSize:
                              "11px",
                            marginTop:
                              "6px",
                          }}
                        >
                          Received{" "}
                          {formatDateTime(
                            ticket.created_at
                          )}
                        </div>
                      </div>

                      <AdminSupportActions
                        email={
                          ticket.email
                        }
                      />
                    </div>

                    <div
                      style={{
                        background:
                          "#f8fafc",
                        border:
                          "1px solid #e5e7eb",
                        borderRadius:
                          "13px",
                        padding:
                          "17px",
                        marginTop:
                          "20px",
                        color:
                          "#374151",
                        fontSize:
                          "14px",
                        lineHeight:
                          "1.65",
                        whiteSpace:
                          "pre-wrap",
                        overflowWrap:
                          "anywhere",
                      }}
                    >
                      {
                        ticket.message
                      }
                    </div>

                    {ticket.source_path && (
                      <div
                        style={{
                          marginTop:
                            "13px",
                          fontSize:
                            "12px",
                          lineHeight:
                            "1.5",
                          color:
                            "#6b7280",
                          overflowWrap:
                            "anywhere",
                        }}
                      >
                        <strong
                          style={{
                            color:
                              "#374151",
                          }}
                        >
                          Submitted
                          from:
                        </strong>{" "}
                        {
                          ticket.source_path
                        }
                      </div>
                    )}

                    {ticket.handled_at && (
                      <div
                        style={{
                          color:
                            "#9ca3af",
                          fontSize:
                            "11px",
                          marginTop:
                            "7px",
                        }}
                      >
                        First handled{" "}
                        {formatDateTime(
                          ticket.handled_at
                        )}
                      </div>
                    )}

                    <div
                      style={{
                        borderTop:
                          "1px solid #e5e7eb",
                        marginTop:
                          "20px",
                        paddingTop:
                          "17px",
                      }}
                    >
                      <div
                        style={{
                          color:
                            "#6b7280",
                          fontSize:
                            "12px",
                          fontWeight:
                            "800",
                          marginBottom:
                            "9px",
                        }}
                      >
                        STATUS
                      </div>

                      <div
                        style={{
                          display:
                            "flex",
                          gap:
                            "8px",
                          flexWrap:
                            "wrap",
                        }}
                      >
                        {(
                          [
                            "new",
                            "handled",
                            "closed",
                          ] as const
                        ).map(
                          (
                            nextStatus
                          ) => {
                            const selected =
                              ticket.status ===
                              nextStatus;

                            return (
                              <form
                                key={
                                  nextStatus
                                }
                                action={
                                  updateTicketStatus
                                }
                              >
                                <input
                                  type="hidden"
                                  name="ticketId"
                                  value={
                                    ticket.id
                                  }
                                />

                                <input
                                  type="hidden"
                                  name="newStatus"
                                  value={
                                    nextStatus
                                  }
                                />

                                <input
                                  type="hidden"
                                  name="returnStatus"
                                  value={
                                    statusFilter
                                  }
                                />

                                <input
                                  type="hidden"
                                  name="returnSearch"
                                  value={
                                    search
                                  }
                                />

                                <button
                                  type="submit"
                                  disabled={
                                    selected
                                  }
                                  style={{
                                    background:
                                      selected
                                        ? nextStatus ===
                                          "new"
                                          ? "#2563eb"
                                          : nextStatus ===
                                              "handled"
                                            ? "#047857"
                                            : "#6b7280"
                                        : "#ffffff",
                                    color:
                                      selected
                                        ? "#ffffff"
                                        : "#374151",
                                    border:
                                      selected
                                        ? "1px solid transparent"
                                        : "1px solid #d1d5db",
                                    borderRadius:
                                      "9px",
                                    padding:
                                      "9px 12px",
                                    fontSize:
                                      "12px",
                                    fontWeight:
                                      "800",
                                    cursor:
                                      selected
                                        ? "default"
                                        : "pointer",
                                  }}
                                >
                                  {nextStatus ===
                                  "new"
                                    ? "New"
                                    : nextStatus ===
                                        "handled"
                                      ? "Handled"
                                      : "Closed"}
                                </button>
                              </form>
                            );
                          }
                        )}
                      </div>
                    </div>
                  </article>
                );
              }
            )}
          </div>
        )}

        <div
          style={{
            marginTop:
              "26px",
            padding:
              "15px 17px",
            background:
              "#eff6ff",
            border:
              "1px solid #bfdbfe",
            borderRadius:
              "13px",
            color:
              "#1e40af",
            fontSize:
              "12px",
            lineHeight:
              "1.6",
          }}
        >
          GoWishlist does not send
          support replies from this
          inbox. Use Reply in Gmail
          to respond from your own
          email account.
        </div>
      </section>
    </main>
  );
}
