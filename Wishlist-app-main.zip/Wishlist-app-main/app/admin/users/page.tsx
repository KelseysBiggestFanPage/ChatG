import type { User } from "@supabase/supabase-js";
import Link from "next/link";
import { redirect } from "next/navigation";
import GoWishlistLogo from "../../../components/GoWishlistLogo";
import { createAdminClient } from "../../../lib/supabase/admin";
import { createClient } from "../../../lib/supabase/server";
import { getSiteUrl } from "../../../lib/site";

export const dynamic = "force-dynamic";

type ProfileRow = {
  id: string;
  display_name: string | null;
  email: string | null;
};

type WishlistRow = {
  id: string;
  owner_id: string;
  title: string;
  slug: string;
  is_live: boolean;
  access_code_hash: string | null;
  created_at: string;
};

async function getAllAuthUsers(
  admin: ReturnType<typeof createAdminClient>
) {
  const users: User[] = [];
  const perPage = 100;
  let page = 1;

  while (true) {
    const {
      data,
      error,
    } = await admin.auth.admin.listUsers({
      page,
      perPage,
    });

    if (error) {
      throw error;
    }

    const batch =
      data.users || [];

    users.push(...batch);

    if (
      batch.length <
      perPage
    ) {
      break;
    }

    page += 1;

    if (page > 1000) {
      break;
    }
  }

  return users;
}

async function getAllProfiles(
  admin: ReturnType<typeof createAdminClient>
) {
  const rows: ProfileRow[] = [];
  const pageSize = 1000;
  let start = 0;

  while (true) {
    const {
      data,
      error,
    } = await admin
      .from("profiles")
      .select(
        "id, display_name, email"
      )
      .range(
        start,
        start + pageSize - 1
      );

    if (error) {
      throw error;
    }

    const batch =
      (data || []) as ProfileRow[];

    rows.push(...batch);

    if (
      batch.length <
      pageSize
    ) {
      break;
    }

    start += pageSize;
  }

  return rows;
}

async function getAllWishlists(
  admin: ReturnType<typeof createAdminClient>
) {
  const rows: WishlistRow[] = [];
  const pageSize = 1000;
  let start = 0;

  while (true) {
    const {
      data,
      error,
    } = await admin
      .from("wishlists")
      .select(
        "id, owner_id, title, slug, is_live, access_code_hash, created_at"
      )
      .order(
        "created_at",
        {
          ascending: false,
        }
      )
      .range(
        start,
        start + pageSize - 1
      );

    if (error) {
      throw error;
    }

    const batch =
      (data || []) as WishlistRow[];

    rows.push(...batch);

    if (
      batch.length <
      pageSize
    ) {
      break;
    }

    start += pageSize;
  }

  return rows;
}

function formatDate(
  value: string
) {
  const date =
    new Date(value);

  if (
    Number.isNaN(
      date.getTime()
    )
  ) {
    return "Unknown";
  }

  return new Intl.DateTimeFormat(
    "en-US",
    {
      dateStyle: "medium",
    }
  ).format(date);
}

export default async function AdminUsersPage({
  searchParams,
}: {
  searchParams: Promise<{
    q?: string;
  }>;
}) {
  const query =
    await searchParams;

  const supabase =
    await createClient();

  const {
    data: { user },
  } =
    await supabase.auth.getUser();

  if (!user) {
    redirect("/home");
  }

  const adminEmail =
    process.env.ADMIN_EMAIL
      ?.trim()
      .toLowerCase();

  const currentEmail =
    user.email
      ?.trim()
      .toLowerCase();

  if (
    !adminEmail ||
    !currentEmail ||
    currentEmail !==
      adminEmail
  ) {
    redirect("/dashboard");
  }

  const admin =
    createAdminClient();

  let authUsers: User[] = [];
  let profiles: ProfileRow[] = [];
  let wishlists: WishlistRow[] = [];

  try {
    [
      authUsers,
      profiles,
      wishlists,
    ] = await Promise.all([
      getAllAuthUsers(
        admin
      ),
      getAllProfiles(
        admin
      ),
      getAllWishlists(
        admin
      ),
    ]);
  } catch (error) {
    console.error(
      "Admin users load error:",
      error
    );
  }

  const profileByUser =
    new Map(
      profiles.map(
        (profile) => [
          profile.id,
          profile,
        ]
      )
    );

  const wishlistsByUser =
    new Map<
      string,
      WishlistRow[]
    >();

  for (
    const wishlist
    of wishlists
  ) {
    const current =
      wishlistsByUser.get(
        wishlist.owner_id
      ) || [];

    current.push(
      wishlist
    );

    wishlistsByUser.set(
      wishlist.owner_id,
      current
    );
  }

  const search =
    String(
      query.q || ""
    )
      .trim()
      .toLowerCase();

  const users =
    authUsers
      .map(
        (authUser) => {
          const profile =
            profileByUser.get(
              authUser.id
            );

          const displayName =
            profile
              ?.display_name
              ?.trim() ||
            authUser
              .user_metadata
              ?.full_name ||
            authUser
              .user_metadata
              ?.name ||
            "";

          const email =
            authUser.email ||
            profile?.email ||
            "";

          return {
            authUser,
            displayName,
            email,
            wishlists:
              wishlistsByUser.get(
                authUser.id
              ) || [],
          };
        }
      )
      .filter(
        (entry) => {
          if (!search) {
            return true;
          }

          return (
            entry.email
              .toLowerCase()
              .includes(
                search
              ) ||
            entry.displayName
              .toLowerCase()
              .includes(
                search
              )
          );
        }
      )
      .sort(
        (a, b) =>
          new Date(
            b.authUser.created_at
          ).getTime() -
          new Date(
            a.authUser.created_at
          ).getTime()
      );

  const siteUrl = getSiteUrl();

  return (
    <main
      style={{
        minHeight:
          "100vh",
        background:
          "#f8fafc",
        color:
          "#111827",
      }}
    >
      <header
        style={{
          background:
            "#ffffff",
          borderBottom:
            "1px solid #e5e7eb",
        }}
      >
        <div
          style={{
            maxWidth:
              "1200px",
            margin:
              "0 auto",
            padding:
              "20px 30px",
            display:
              "flex",
            justifyContent:
              "space-between",
            alignItems:
              "center",
            gap:
              "20px",
            flexWrap:
              "wrap",
          }}
        >
          <div
            style={{
              display:
                "flex",
              alignItems:
                "center",
              gap:
                "16px",
            }}
          >
            <GoWishlistLogo
              href="/dashboard"
              size={29}
            />

            <div
              style={{
                background:
                  "#eff6ff",
                color:
                  "#2563eb",
                border:
                  "1px solid #bfdbfe",
                borderRadius:
                  "999px",
                padding:
                  "6px 10px",
                fontSize:
                  "11px",
                fontWeight:
                  "900",
                letterSpacing:
                  "0.6px",
              }}
            >
              ADMIN
            </div>
          </div>

          <div
            style={{
              display:
                "flex",
              alignItems:
                "center",
              gap:
                "16px",
              flexWrap:
                "wrap",
            }}
          >
            <Link
              href="/admin"
              style={{
                color:
                  "#2563eb",
                textDecoration:
                  "none",
                fontSize:
                  "14px",
                fontWeight:
                  "800",
              }}
            >
              Overview
            </Link>

            <Link
              href="/dashboard"
              style={{
                color:
                  "#6b7280",
                textDecoration:
                  "none",
                fontSize:
                  "14px",
                fontWeight:
                  "700",
              }}
            >
              Dashboard
            </Link>
          </div>
        </div>
      </header>

      <section
        style={{
          maxWidth:
            "1200px",
          margin:
            "0 auto",
          padding:
            "50px 30px 90px",
        }}
      >
        <div
          style={{
            display:
              "flex",
            justifyContent:
              "space-between",
            alignItems:
              "flex-end",
            gap:
              "20px",
            flexWrap:
              "wrap",
            marginBottom:
              "28px",
          }}
        >
          <div>
            <div
              style={{
                color:
                  "#2563eb",
                fontSize:
                  "12px",
                fontWeight:
                  "900",
                letterSpacing:
                  "0.8px",
                marginBottom:
                  "7px",
              }}
            >
              ADMIN USERS
            </div>

            <h1
              style={{
                margin: 0,
                fontSize:
                  "40px",
                lineHeight:
                  "1.1",
                fontWeight:
                  "800",
                letterSpacing:
                  "-1.6px",
              }}
            >
              Users
            </h1>

            <p
              style={{
                color:
                  "#6b7280",
                fontSize:
                  "14px",
                lineHeight:
                  "1.6",
                margin:
                  "10px 0 0",
              }}
            >
              {authUsers.length} registered{" "}
              {authUsers.length ===
              1
                ? "user"
                : "users"}
            </p>
          </div>

          <form
            method="get"
            style={{
              display:
                "flex",
              gap:
                "8px",
              flexWrap:
                "wrap",
            }}
          >
            <input
              type="search"
              name="q"
              defaultValue={
                query.q || ""
              }
              placeholder="Search name or email"
              style={{
                width:
                  "260px",
                maxWidth:
                  "100%",
                border:
                  "1px solid #d1d5db",
                borderRadius:
                  "10px",
                padding:
                  "11px 13px",
                fontSize:
                  "14px",
                outline:
                  "none",
              }}
            />

            <button
              type="submit"
              style={{
                background:
                  "#2563eb",
                color:
                  "#ffffff",
                border:
                  "none",
                borderRadius:
                  "10px",
                padding:
                  "11px 16px",
                fontSize:
                  "14px",
                fontWeight:
                  "800",
                cursor:
                  "pointer",
              }}
            >
              Search
            </button>

            {search && (
              <Link
                href="/admin/users"
                style={{
                  display:
                    "inline-flex",
                  alignItems:
                    "center",
                  justifyContent:
                    "center",
                  color:
                    "#374151",
                  background:
                    "#ffffff",
                  border:
                    "1px solid #d1d5db",
                  borderRadius:
                    "10px",
                  padding:
                    "11px 16px",
                  fontSize:
                    "14px",
                  fontWeight:
                    "700",
                  textDecoration:
                    "none",
                }}
              >
                Clear
              </Link>
            )}
          </form>
        </div>

        {users.length ===
        0 ? (
          <div
            style={{
              background:
                "#ffffff",
              border:
                "1px solid #e5e7eb",
              borderRadius:
                "18px",
              padding:
                "42px 24px",
              textAlign:
                "center",
              color:
                "#6b7280",
            }}
          >
            {search
              ? "No users match your search."
              : "No users found."}
          </div>
        ) : (
          <div
            style={{
              display:
                "grid",
              gap:
                "18px",
            }}
          >
            {users.map(
              ({
                authUser,
                displayName,
                email,
                wishlists:
                  userWishlists,
              }) => {
                const isAdmin =
                  email
                    .trim()
                    .toLowerCase() ===
                  adminEmail;

                return (
                  <article
                    key={
                      authUser.id
                    }
                    style={{
                      background:
                        "#ffffff",
                      border:
                        "1px solid #e5e7eb",
                      borderRadius:
                        "18px",
                      padding:
                        "24px",
                      boxShadow:
                        "0 8px 25px rgba(0,0,0,0.035)",
                    }}
                  >
                    <div
                      style={{
                        display:
                          "flex",
                        justifyContent:
                          "space-between",
                        alignItems:
                          "flex-start",
                        gap:
                          "18px",
                        flexWrap:
                          "wrap",
                      }}
                    >
                      <div>
                        <div
                          style={{
                            display:
                              "flex",
                            alignItems:
                              "center",
                            gap:
                              "8px",
                            flexWrap:
                              "wrap",
                            marginBottom:
                              "5px",
                          }}
                        >
                          <h2
                            style={{
                              margin:
                                0,
                              fontSize:
                                "20px",
                              fontWeight:
                                "800",
                            }}
                          >
                            {displayName ||
                              "No name set"}
                          </h2>

                          {isAdmin && (
                            <span
                              style={{
                                background:
                                  "#eff6ff",
                                color:
                                  "#2563eb",
                                border:
                                  "1px solid #bfdbfe",
                                borderRadius:
                                  "999px",
                                padding:
                                  "4px 8px",
                                fontSize:
                                  "10px",
                                fontWeight:
                                  "900",
                              }}
                            >
                              ADMIN
                            </span>
                          )}
                        </div>

                        <div
                          style={{
                            color:
                              "#4b5563",
                            fontSize:
                              "14px",
                            overflowWrap:
                              "anywhere",
                          }}
                        >
                          {email ||
                            "No email"}
                        </div>

                        <div
                          style={{
                            color:
                              "#9ca3af",
                            fontSize:
                              "12px",
                            marginTop:
                              "6px",
                          }}
                        >
                          Account created{" "}
                          {formatDate(
                            authUser.created_at
                          )}
                        </div>
                      </div>

                      <div
                        style={{
                          display:
                            "flex",
                          alignItems:
                            "center",
                          gap:
                            "10px",
                          flexWrap:
                            "wrap",
                        }}
                      >
                        <div
                          style={{
                            background:
                              "#f8fafc",
                            border:
                              "1px solid #e5e7eb",
                            borderRadius:
                              "12px",
                            padding:
                              "10px 14px",
                            fontSize:
                              "13px",
                            fontWeight:
                              "800",
                            color:
                              "#374151",
                          }}
                        >
                          {
                            userWishlists.length
                          }{" "}
                          {userWishlists.length ===
                          1
                            ? "wishlist"
                            : "wishlists"}
                        </div>

                        <Link
                          href={`/admin/users/${authUser.id}`}
                          style={{
                            display:
                              "inline-flex",
                            alignItems:
                              "center",
                            justifyContent:
                              "center",
                            background:
                              "#2563eb",
                            color:
                              "#ffffff",
                            border:
                              "1px solid #2563eb",
                            borderRadius:
                              "10px",
                            padding:
                              "10px 13px",
                            fontSize:
                              "12px",
                            fontWeight:
                              "800",
                            textDecoration:
                              "none",
                          }}
                        >
                          Manage User →
                        </Link>
                      </div>
                    </div>

                    <div
                      style={{
                        borderTop:
                          "1px solid #e5e7eb",
                        marginTop:
                          "20px",
                        paddingTop:
                          "20px",
                      }}
                    >
                      {userWishlists.length ===
                      0 ? (
                        <div
                          style={{
                            color:
                              "#9ca3af",
                            fontSize:
                              "13px",
                          }}
                        >
                          This user
                          has no active
                          wishlists.
                        </div>
                      ) : (
                        <div
                          style={{
                            display:
                              "grid",
                            gap:
                              "10px",
                          }}
                        >
                          {userWishlists.map(
                            (
                              wishlist
                            ) => {
                              const publicUrl =
                                `${siteUrl}/wishlist/${wishlist.slug}`;

                              return (
                                <div
                                  key={
                                    wishlist.id
                                  }
                                  style={{
                                    background:
                                      "#f8fafc",
                                    border:
                                      "1px solid #e5e7eb",
                                    borderRadius:
                                      "12px",
                                    padding:
                                      "14px",
                                    display:
                                      "flex",
                                    justifyContent:
                                      "space-between",
                                    alignItems:
                                      "center",
                                    gap:
                                      "14px",
                                    flexWrap:
                                      "wrap",
                                  }}
                                >
                                  <div
                                    style={{
                                      minWidth:
                                        0,
                                      flex:
                                        "1 1 300px",
                                    }}
                                  >
                                    <div
                                      style={{
                                        fontSize:
                                          "14px",
                                        fontWeight:
                                          "800",
                                        marginBottom:
                                          "5px",
                                      }}
                                    >
                                      {
                                        wishlist.title
                                      }
                                    </div>

                                    <div
                                      style={{
                                        color:
                                          "#6b7280",
                                        fontSize:
                                          "12px",
                                        overflowWrap:
                                          "anywhere",
                                      }}
                                    >
                                      {
                                        publicUrl
                                      }
                                    </div>
                                  </div>

                                  <div
                                    style={{
                                      display:
                                        "flex",
                                      alignItems:
                                        "center",
                                      gap:
                                        "7px",
                                      flexWrap:
                                        "wrap",
                                    }}
                                  >
                                    <span
                                      style={{
                                        background:
                                          wishlist.is_live
                                            ? "#ecfdf5"
                                            : "#f3f4f6",
                                        color:
                                          wishlist.is_live
                                            ? "#047857"
                                            : "#6b7280",
                                        border:
                                          wishlist.is_live
                                            ? "1px solid #a7f3d0"
                                            : "1px solid #d1d5db",
                                        borderRadius:
                                          "999px",
                                        padding:
                                          "5px 9px",
                                        fontSize:
                                          "11px",
                                        fontWeight:
                                          "800",
                                      }}
                                    >
                                      {wishlist.is_live
                                        ? "Live"
                                        : "Draft"}
                                    </span>

                                    <span
                                      style={{
                                        background:
                                          wishlist.access_code_hash
                                            ? "#eff6ff"
                                            : "#f8fafc",
                                        color:
                                          wishlist.access_code_hash
                                            ? "#2563eb"
                                            : "#6b7280",
                                        border:
                                          wishlist.access_code_hash
                                            ? "1px solid #bfdbfe"
                                            : "1px solid #e5e7eb",
                                        borderRadius:
                                          "999px",
                                        padding:
                                          "5px 9px",
                                        fontSize:
                                          "11px",
                                        fontWeight:
                                          "800",
                                      }}
                                    >
                                      {wishlist.access_code_hash
                                        ? "Protected"
                                        : "Open"}
                                    </span>

                                    {wishlist.is_live && (
                                      <a
                                        href={
                                          publicUrl
                                        }
                                        target="_blank"
                                        rel="noreferrer"
                                        style={{
                                          color:
                                            "#2563eb",
                                          fontSize:
                                            "12px",
                                          fontWeight:
                                            "800",
                                          textDecoration:
                                            "none",
                                          padding:
                                            "5px 3px",
                                        }}
                                      >
                                        View
                                      </a>
                                    )}
                                  </div>
                                </div>
                              );
                            }
                          )}
                        </div>
                      )}
                    </div>
                  </article>
                );
              }
            )}
          </div>
        )}
      </section>
    </main>
  );
}
