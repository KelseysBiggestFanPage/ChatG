import Link from "next/link";
import {
  notFound,
  redirect,
} from "next/navigation";
import GoWishlistLogo from "../../../../components/GoWishlistLogo";
import { createAdminClient } from "../../../../lib/supabase/admin";
import { createClient } from "../../../../lib/supabase/server";
import { getSiteUrl } from "../../../../lib/site";

export const dynamic = "force-dynamic";

type ProfileRow = {
  id: string;
  display_name: string | null;
  email: string | null;
  created_at: string;
  updated_at: string;
};

type WishlistRow = {
  id: string;
  owner_id: string;
  title: string;
  slug: string;
  is_live: boolean;
  access_code_hash: string | null;
  event_date: string | null;
  owner_contact_email: string | null;
  owner_contact_phone: string | null;
  created_at: string;
  updated_at: string;
};

type GiftRow = {
  id: string;
  wishlist_id: string;
};

type ReservationRow = {
  id: string;
  wishlist_id: string;
};

function formatDate(
  value: string | null | undefined
) {
  if (!value) {
    return "Unknown";
  }

  const date =
    new Date(value);

  if (
    Number.isNaN(
      date.getTime()
    )
  ) {
    return "Unknown";
  }

  return new Intl.DateTimeFormat(
    "en-US",
    {
      dateStyle: "medium",
    }
  ).format(date);
}

function formatDateTime(
  value: string | null | undefined
) {
  if (!value) {
    return "Never";
  }

  const date =
    new Date(value);

  if (
    Number.isNaN(
      date.getTime()
    )
  ) {
    return "Unknown";
  }

  return new Intl.DateTimeFormat(
    "en-US",
    {
      dateStyle: "medium",
      timeStyle: "short",
    }
  ).format(date);
}

function getDisplayName(
  profile: ProfileRow | null,
  metadata:
    | Record<string, unknown>
    | undefined
) {
  const profileName =
    profile?.display_name?.trim();

  if (profileName) {
    return profileName;
  }

  const fullName =
    typeof metadata?.full_name ===
    "string"
      ? metadata.full_name.trim()
      : "";

  if (fullName) {
    return fullName;
  }

  const name =
    typeof metadata?.name ===
    "string"
      ? metadata.name.trim()
      : "";

  return name || "No name set";
}

export default async function AdminUserDetailPage({
  params,
  searchParams,
}: {
  params: Promise<{
    id: string;
  }>;
  searchParams: Promise<{
    success?: string;
    error?: string;
  }>;
}) {
  const { id } =
    await params;

  const query =
    await searchParams;

  const supabase =
    await createClient();

  const {
    data: {
      user: adminUser,
    },
  } =
    await supabase.auth.getUser();

  if (!adminUser) {
    redirect("/home");
  }

  const configuredAdminEmail =
    process.env.ADMIN_EMAIL
      ?.trim()
      .toLowerCase();

  const currentAdminEmail =
    adminUser.email
      ?.trim()
      .toLowerCase();

  if (
    !configuredAdminEmail ||
    !currentAdminEmail ||
    currentAdminEmail !==
      configuredAdminEmail
  ) {
    redirect("/dashboard");
  }

  const admin =
    createAdminClient();

  const {
    data: targetResult,
    error: targetError,
  } =
    await admin.auth.admin.getUserById(
      id
    );

  const targetUser =
    targetResult?.user;

  if (
    targetError ||
    !targetUser
  ) {
    notFound();
  }

  const [
    profileResult,
    wishlistsResult,
    giftsResult,
  ] = await Promise.all([
    admin
      .from("profiles")
      .select(
        "id, display_name, email, created_at, updated_at"
      )
      .eq(
        "id",
        targetUser.id
      )
      .maybeSingle(),

    admin
      .from("wishlists")
      .select(
        "id, owner_id, title, slug, is_live, access_code_hash, event_date, owner_contact_email, owner_contact_phone, created_at, updated_at"
      )
      .eq(
        "owner_id",
        targetUser.id
      )
      .order(
        "created_at",
        {
          ascending: false,
        }
      ),

    admin
      .from("gifts")
      .select(
        "id, wishlist_id"
      )
      .eq(
        "owner_id",
        targetUser.id
      ),
  ]);

  if (
    profileResult.error
  ) {
    console.error(
      "Admin user profile load error:",
      profileResult.error
    );
  }

  if (
    wishlistsResult.error
  ) {
    console.error(
      "Admin user wishlists load error:",
      wishlistsResult.error
    );
  }

  if (
    giftsResult.error
  ) {
    console.error(
      "Admin user gifts load error:",
      giftsResult.error
    );
  }

  const profile =
    (profileResult.data ||
      null) as
      | ProfileRow
      | null;

  const wishlists =
    (wishlistsResult.data ||
      []) as WishlistRow[];

  const gifts =
    (giftsResult.data ||
      []) as GiftRow[];

  const wishlistIds =
    wishlists.map(
      (wishlist) =>
        wishlist.id
    );

  let reservations:
    ReservationRow[] = [];

  if (
    wishlistIds.length > 0
  ) {
    const reservationResult =
      await admin
        .from(
          "reservations"
        )
        .select(
          "id, wishlist_id"
        )
        .in(
          "wishlist_id",
          wishlistIds
        );

    if (
      reservationResult.error
    ) {
      console.error(
        "Admin user reservations load error:",
        reservationResult.error
      );
    } else {
      reservations =
        (reservationResult.data ||
          []) as ReservationRow[];
    }
  }

  const giftCountByWishlist =
    new Map<
      string,
      number
    >();

  for (
    const gift
    of gifts
  ) {
    giftCountByWishlist.set(
      gift.wishlist_id,
      (giftCountByWishlist.get(
        gift.wishlist_id
      ) || 0) + 1
    );
  }

  const reservationCountByWishlist =
    new Map<
      string,
      number
    >();

  for (
    const reservation
    of reservations
  ) {
    reservationCountByWishlist.set(
      reservation.wishlist_id,
      (reservationCountByWishlist.get(
        reservation.wishlist_id
      ) || 0) + 1
    );
  }

  const displayName =
    getDisplayName(
      profile,
      targetUser.user_metadata as
        | Record<
            string,
            unknown
          >
        | undefined
    );

  const targetEmail =
    targetUser.email ||
    profile?.email ||
    "";

  const isAdminAccount =
    targetUser.id ===
      adminUser.id ||
    targetEmail
      .trim()
      .toLowerCase() ===
      configuredAdminEmail;

  const siteUrl = getSiteUrl();

  async function resetAccessCode(
    formData: FormData
  ) {
    "use server";

    const supabase =
      await createClient();

    const {
      data: { user },
    } =
      await supabase.auth.getUser();

    if (!user) {
      redirect("/home");
    }

    const configuredAdminEmail =
      process.env.ADMIN_EMAIL
        ?.trim()
        .toLowerCase();

    const currentAdminEmail =
      user.email
        ?.trim()
        .toLowerCase();

    if (
      !configuredAdminEmail ||
      !currentAdminEmail ||
      currentAdminEmail !==
        configuredAdminEmail
    ) {
      redirect(
        "/dashboard"
      );
    }

    if (
      user.id === id
    ) {
      redirect(
        `/admin/users/${id}?error=admin-protected`
      );
    }

    const wishlistId =
      String(
        formData.get(
          "wishlistId"
        ) || ""
      ).trim();

    const confirmation =
      String(
        formData.get(
          "confirmation"
        ) || ""
      ).trim();

    if (
      !wishlistId ||
      confirmation !==
        "RESET"
    ) {
      redirect(
        `/admin/users/${id}?error=reset-code-confirm`
      );
    }

    const admin =
      createAdminClient();

    const {
      data:
        currentWishlist,
      error:
        lookupError,
    } = await admin
      .from(
        "wishlists"
      )
      .select(
        "id, owner_id, title, slug, access_code_hash"
      )
      .eq(
        "id",
        wishlistId
      )
      .eq(
        "owner_id",
        id
      )
      .maybeSingle();

    if (
      lookupError ||
      !currentWishlist
    ) {
      console.error(
        "Admin reset access code lookup error:",
        lookupError
      );

      redirect(
        `/admin/users/${id}?error=wishlist-missing`
      );
    }

    if (
      !currentWishlist.access_code_hash
    ) {
      redirect(
        `/admin/users/${id}?success=code-already-open`
      );
    }

    const {
      error:
        updateError,
    } = await admin
      .from(
        "wishlists"
      )
      .update({
        access_code_hash:
          null,
        updated_at:
          new Date().toISOString(),
      })
      .eq(
        "id",
        currentWishlist.id
      )
      .eq(
        "owner_id",
        id
      );

    if (updateError) {
      console.error(
        "Admin reset access code error:",
        updateError
      );

      redirect(
        `/admin/users/${id}?error=reset-code`
      );
    }

    const {
      error: logError,
    } = await admin
      .from(
        "admin_activity_log"
      )
      .insert({
        admin_user_id:
          user.id,
        admin_email:
          currentAdminEmail,
        action:
          "reset_wishlist_access_code",
        target_user_id:
          id,
        target_email:
          targetEmail ||
          null,
        target_wishlist_id:
          currentWishlist.id,
        details: {
          title:
            currentWishlist.title,
          slug:
            currentWishlist.slug,
          result:
            "protection_removed",
        },
      });

    if (logError) {
      console.error(
        "Admin reset access code log error:",
        logError
      );
    }

    redirect(
      `/admin/users/${id}?success=code-reset`
    );
  }

  async function deleteWishlist(
    formData: FormData
  ) {
    "use server";

    const supabase =
      await createClient();

    const {
      data: { user },
    } =
      await supabase.auth.getUser();

    if (!user) {
      redirect("/home");
    }

    const configuredAdminEmail =
      process.env.ADMIN_EMAIL
        ?.trim()
        .toLowerCase();

    const currentAdminEmail =
      user.email
        ?.trim()
        .toLowerCase();

    if (
      !configuredAdminEmail ||
      !currentAdminEmail ||
      currentAdminEmail !==
        configuredAdminEmail
    ) {
      redirect(
        "/dashboard"
      );
    }

    if (
      user.id === id
    ) {
      redirect(
        `/admin/users/${id}?error=admin-protected`
      );
    }

    const wishlistId =
      String(
        formData.get(
          "wishlistId"
        ) || ""
      ).trim();

    const confirmation =
      String(
        formData.get(
          "confirmation"
        ) || ""
      ).trim();

    if (
      !wishlistId ||
      confirmation !==
        "DELETE"
    ) {
      redirect(
        `/admin/users/${id}?error=delete-wishlist-confirm`
      );
    }

    const admin =
      createAdminClient();

    const {
      data:
        currentTarget,
      error:
        targetError,
    } =
      await admin.auth.admin.getUserById(
        id
      );

    if (
      targetError ||
      !currentTarget?.user
    ) {
      redirect(
        `/admin/users/${id}?error=user-missing`
      );
    }

    const {
      data:
        currentWishlist,
      error:
        wishlistError,
    } = await admin
      .from(
        "wishlists"
      )
      .select(
        "id, owner_id, title, slug"
      )
      .eq(
        "id",
        wishlistId
      )
      .eq(
        "owner_id",
        id
      )
      .maybeSingle();

    if (
      wishlistError ||
      !currentWishlist
    ) {
      console.error(
        "Admin delete wishlist lookup error:",
        wishlistError
      );

      redirect(
        `/admin/users/${id}?error=wishlist-missing`
      );
    }

    const {
      data:
        archiveId,
      error:
        deleteError,
    } = await admin.rpc(
      "archive_and_delete_wishlist",
      {
        p_wishlist_id:
          currentWishlist.id,
        p_owner_id:
          id,
        p_owner_email:
          currentTarget.user
            .email ||
          "",
        p_deleted_by:
          "admin",
      }
    );

    if (
      deleteError
    ) {
      console.error(
        "Admin archive wishlist error:",
        deleteError
      );

      redirect(
        `/admin/users/${id}?error=delete-wishlist`
      );
    }

    const {
      error: logError,
    } = await admin
      .from(
        "admin_activity_log"
      )
      .insert({
        admin_user_id:
          user.id,
        admin_email:
          currentAdminEmail,
        action:
          "admin_delete_wishlist",
        target_user_id:
          id,
        target_email:
          currentTarget.user
            .email ||
          null,
        target_wishlist_id:
          currentWishlist.id,
        details: {
          archive_id:
            archiveId,
          title:
            currentWishlist.title,
          slug:
            currentWishlist.slug,
          recoverable_days:
            90,
        },
      });

    if (logError) {
      console.error(
        "Admin delete wishlist log error:",
        logError
      );
    }

    redirect(
      `/admin/users/${id}?success=wishlist-deleted`
    );
  }

  async function resetUserData(
    formData: FormData
  ) {
    "use server";

    const supabase =
      await createClient();

    const {
      data: { user },
    } =
      await supabase.auth.getUser();

    if (!user) {
      redirect("/home");
    }

    const configuredAdminEmail =
      process.env.ADMIN_EMAIL
        ?.trim()
        .toLowerCase();

    const currentAdminEmail =
      user.email
        ?.trim()
        .toLowerCase();

    if (
      !configuredAdminEmail ||
      !currentAdminEmail ||
      currentAdminEmail !==
        configuredAdminEmail
    ) {
      redirect(
        "/dashboard"
      );
    }

    if (
      user.id === id
    ) {
      redirect(
        `/admin/users/${id}?error=admin-protected`
      );
    }

    const confirmation =
      String(
        formData.get(
          "confirmation"
        ) || ""
      ).trim();

    if (
      confirmation !==
      "RESET USER"
    ) {
      redirect(
        `/admin/users/${id}?error=reset-user-confirm`
      );
    }

    const admin =
      createAdminClient();

    const {
      data:
        targetResult,
      error:
        targetError,
    } =
      await admin.auth.admin.getUserById(
        id
      );

    const target =
      targetResult?.user;

    if (
      targetError ||
      !target
    ) {
      redirect(
        `/admin/users/${id}?error=user-missing`
      );
    }

    const {
      data:
        archivedCount,
      error:
        resetError,
    } = await admin.rpc(
      "archive_and_reset_user_data",
      {
        p_user_id:
          id,
        p_owner_email:
          target.email ||
          "",
      }
    );

    if (
      resetError
    ) {
      console.error(
        "Admin reset user data error:",
        resetError
      );

      redirect(
        `/admin/users/${id}?error=reset-user`
      );
    }

    const {
      error: logError,
    } = await admin
      .from(
        "admin_activity_log"
      )
      .insert({
        admin_user_id:
          user.id,
        admin_email:
          currentAdminEmail,
        action:
          "admin_reset_user_data",
        target_user_id:
          id,
        target_email:
          target.email ||
          null,
        details: {
          archived_wishlists:
            typeof archivedCount ===
            "number"
              ? archivedCount
              : Number(
                  archivedCount ||
                    0
                ),
          recoverable_days:
            90,
          auth_account_preserved:
            true,
          profile_preserved:
            true,
        },
      });

    if (logError) {
      console.error(
        "Admin reset user data log error:",
        logError
      );
    }

    redirect(
      `/admin/users/${id}?success=user-reset`
    );
  }

  async function deleteAccount(
    formData: FormData
  ) {
    "use server";

    const supabase =
      await createClient();

    const {
      data: { user },
    } =
      await supabase.auth.getUser();

    if (!user) {
      redirect("/home");
    }

    const configuredAdminEmail =
      process.env.ADMIN_EMAIL
        ?.trim()
        .toLowerCase();

    const currentAdminEmail =
      user.email
        ?.trim()
        .toLowerCase();

    if (
      !configuredAdminEmail ||
      !currentAdminEmail ||
      currentAdminEmail !==
        configuredAdminEmail
    ) {
      redirect(
        "/dashboard"
      );
    }

    if (
      user.id === id
    ) {
      redirect(
        `/admin/users/${id}?error=admin-protected`
      );
    }

    const confirmation =
      String(
        formData.get(
          "confirmation"
        ) || ""
      ).trim();

    if (
      confirmation !==
      "DELETE ACCOUNT"
    ) {
      redirect(
        `/admin/users/${id}?error=delete-account-confirm`
      );
    }

    const admin =
      createAdminClient();

    const {
      data:
        targetResult,
      error:
        targetError,
    } =
      await admin.auth.admin.getUserById(
        id
      );

    const target =
      targetResult?.user;

    if (
      targetError ||
      !target ||
      !target.email
    ) {
      redirect(
        `/admin/users/${id}?error=user-missing`
      );
    }

    const {
      data:
        archiveId,
      error:
        archiveError,
    } = await admin.rpc(
      "archive_account_for_deletion",
      {
        p_user_id:
          target.id,
        p_email:
          target.email,
        p_auth_created_at:
          target.created_at,
        p_deleted_by:
          "admin",
      }
    );

    if (
      archiveError ||
      !archiveId
    ) {
      console.error(
        "Admin archive account error:",
        archiveError
      );

      redirect(
        `/admin/users/${id}?error=delete-account-archive`
      );
    }

    const {
      error:
        deleteError,
    } =
      await admin.auth.admin.deleteUser(
        target.id
      );

    if (
      deleteError
    ) {
      console.error(
        "Admin delete account error:",
        deleteError
      );

      const {
        error:
          cleanupError,
      } = await admin.rpc(
        "discard_account_deletion_archive",
        {
          p_archive_id:
            archiveId,
          p_user_id:
            target.id,
        }
      );

      if (
        cleanupError
      ) {
        console.error(
          "Admin account archive cleanup error:",
          cleanupError
        );
      }

      redirect(
        `/admin/users/${id}?error=delete-account`
      );
    }

    const {
      error: logError,
    } = await admin
      .from(
        "admin_activity_log"
      )
      .insert({
        admin_user_id:
          user.id,
        admin_email:
          currentAdminEmail,
        action:
          "admin_delete_account",
        target_user_id:
          target.id,
        target_email:
          target.email,
        details: {
          archive_id:
            archiveId,
          recoverable_days:
            90,
          original_auth_created_at:
            target.created_at,
        },
      });

    if (logError) {
      console.error(
        "Admin delete account log error:",
        logError
      );
    }

    redirect(
      "/admin/users"
    );
  }

  let successMessage =
    "";

  if (
    query.success ===
    "code-reset"
  ) {
    successMessage =
      "Wishlist access protection was cleared. The owner can set a new access code from their wishlist settings.";
  }

  if (
    query.success ===
    "code-already-open"
  ) {
    successMessage =
      "That wishlist is already open and does not currently have an access code.";
  }

  if (
    query.success ===
    "wishlist-deleted"
  ) {
    successMessage =
      "Wishlist deleted and archived for up to 90 days.";
  }

  if (
    query.success ===
    "user-reset"
  ) {
    successMessage =
      "User data reset completed. Their login and profile remain active, while their wishlists were archived for up to 90 days.";
  }

  let errorMessage =
    "";

  if (
    query.error ===
    "admin-protected"
  ) {
    errorMessage =
      "Admin destructive actions are disabled for your own admin account. Use the normal Dashboard and Settings pages for your own data.";
  }

  if (
    query.error ===
    "reset-code-confirm"
  ) {
    errorMessage =
      "Type RESET exactly to clear that wishlist access code.";
  }

  if (
    query.error ===
    "reset-code"
  ) {
    errorMessage =
      "The wishlist access code could not be reset. Please try again.";
  }

  if (
    query.error ===
    "wishlist-missing"
  ) {
    errorMessage =
      "That wishlist could not be found for this user.";
  }

  if (
    query.error ===
    "delete-wishlist-confirm"
  ) {
    errorMessage =
      "Type DELETE exactly to delete and archive that wishlist.";
  }

  if (
    query.error ===
    "delete-wishlist"
  ) {
    errorMessage =
      "The wishlist could not be safely archived and deleted.";
  }

  if (
    query.error ===
    "reset-user-confirm"
  ) {
    errorMessage =
      "Type RESET USER exactly to reset this user's GoWishlist data.";
  }

  if (
    query.error ===
    "reset-user"
  ) {
    errorMessage =
      "The user data reset could not be completed. Make sure the admin user reset SQL has been run.";
  }

  if (
    query.error ===
    "delete-account-confirm"
  ) {
    errorMessage =
      "Type DELETE ACCOUNT exactly to delete this account.";
  }

  if (
    query.error ===
    "delete-account-archive"
  ) {
    errorMessage =
      "The account could not be safely archived, so it was not deleted.";
  }

  if (
    query.error ===
    "delete-account"
  ) {
    errorMessage =
      "The account could not be deleted. The active account remains available.";
  }

  if (
    query.error ===
    "user-missing"
  ) {
    errorMessage =
      "This user account is no longer available.";
  }

  return (
    <main
      style={{
        minHeight:
          "100vh",
        background:
          "#f8fafc",
        color:
          "#111827",
      }}
    >
      <header
        style={{
          background:
            "#ffffff",
          borderBottom:
            "1px solid #e5e7eb",
        }}
      >
        <div
          style={{
            maxWidth:
              "1200px",
            margin:
              "0 auto",
            padding:
              "20px 30px",
            display:
              "flex",
            justifyContent:
              "space-between",
            alignItems:
              "center",
            gap:
              "20px",
            flexWrap:
              "wrap",
          }}
        >
          <div
            style={{
              display:
                "flex",
              alignItems:
                "center",
              gap:
                "16px",
            }}
          >
            <GoWishlistLogo
              href="/dashboard"
              size={29}
            />

            <div
              style={{
                background:
                  "#eff6ff",
                color:
                  "#2563eb",
                border:
                  "1px solid #bfdbfe",
                borderRadius:
                  "999px",
                padding:
                  "6px 10px",
                fontSize:
                  "11px",
                fontWeight:
                  "900",
                letterSpacing:
                  "0.6px",
              }}
            >
              ADMIN
            </div>
          </div>

          <div
            style={{
              display:
                "flex",
              alignItems:
                "center",
              gap:
                "16px",
              flexWrap:
                "wrap",
            }}
          >
            <Link
              href="/admin"
              style={{
                color:
                  "#2563eb",
                textDecoration:
                  "none",
                fontSize:
                  "14px",
                fontWeight:
                  "800",
              }}
            >
              Overview
            </Link>

            <Link
              href="/admin/users"
              style={{
                color:
                  "#374151",
                textDecoration:
                  "none",
                fontSize:
                  "14px",
                fontWeight:
                  "700",
              }}
            >
              Users
            </Link>

            <Link
              href="/admin/support"
              style={{
                color:
                  "#374151",
                textDecoration:
                  "none",
                fontSize:
                  "14px",
                fontWeight:
                  "700",
              }}
            >
              Support
            </Link>

            <Link
              href="/admin/deleted"
              style={{
                color:
                  "#374151",
                textDecoration:
                  "none",
                fontSize:
                  "14px",
                fontWeight:
                  "700",
              }}
            >
              Deleted Data
            </Link>

            <Link
              href="/admin/activity"
              style={{
                color:
                  "#374151",
                textDecoration:
                  "none",
                fontSize:
                  "14px",
                fontWeight:
                  "700",
              }}
            >
              Activity
            </Link>
          </div>
        </div>
      </header>

      <section
        style={{
          maxWidth:
            "1100px",
          margin:
            "0 auto",
          padding:
            "50px 30px 90px",
        }}
      >
        <Link
          href="/admin/users"
          style={{
            display:
              "inline-block",
            color:
              "#6b7280",
            textDecoration:
              "none",
            fontSize:
              "13px",
            fontWeight:
              "700",
            marginBottom:
              "20px",
          }}
        >
          ← Back to Users
        </Link>

        <div
          style={{
            display:
              "flex",
            justifyContent:
              "space-between",
            alignItems:
              "flex-start",
            gap:
              "20px",
            flexWrap:
              "wrap",
            marginBottom:
              "28px",
          }}
        >
          <div>
            <div
              style={{
                color:
                  "#2563eb",
                fontSize:
                  "12px",
                fontWeight:
                  "900",
                letterSpacing:
                  "0.8px",
                marginBottom:
                  "7px",
              }}
            >
              ADMIN USER DETAIL
            </div>

            <h1
              style={{
                margin: 0,
                fontSize:
                  "38px",
                lineHeight:
                  "1.1",
                fontWeight:
                  "800",
                letterSpacing:
                  "-1.5px",
              }}
            >
              {displayName}
            </h1>

            <div
              style={{
                color:
                  "#4b5563",
                fontSize:
                  "14px",
                marginTop:
                  "8px",
                overflowWrap:
                  "anywhere",
              }}
            >
              {targetEmail ||
                "No email available"}
            </div>
          </div>

          {isAdminAccount && (
            <div
              style={{
                background:
                  "#eff6ff",
                color:
                  "#2563eb",
                border:
                  "1px solid #bfdbfe",
                borderRadius:
                  "999px",
                padding:
                  "7px 11px",
                fontSize:
                  "11px",
                fontWeight:
                  "900",
              }}
            >
              ADMIN ACCOUNT
            </div>
          )}
        </div>

        {successMessage && (
          <div
            style={{
              background:
                "#f0fdf4",
              border:
                "1px solid #bbf7d0",
              color:
                "#166534",
              borderRadius:
                "13px",
              padding:
                "14px 16px",
              fontSize:
                "14px",
              fontWeight:
                "700",
              lineHeight:
                "1.55",
              marginBottom:
                "20px",
            }}
          >
            {successMessage}
          </div>
        )}

        {errorMessage && (
          <div
            style={{
              background:
                "#fef2f2",
              border:
                "1px solid #fecaca",
              color:
                "#b91c1c",
              borderRadius:
                "13px",
              padding:
                "14px 16px",
              fontSize:
                "14px",
              fontWeight:
                "700",
              lineHeight:
                "1.55",
              marginBottom:
                "20px",
            }}
          >
            {errorMessage}
          </div>
        )}

        <div
          style={{
            display:
              "grid",
            gridTemplateColumns:
              "repeat(auto-fit, minmax(min(100%, 220px), 1fr))",
            gap:
              "14px",
            marginBottom:
              "32px",
          }}
        >
          <InfoCard
            label="Account Created"
            value={formatDate(
              targetUser.created_at
            )}
          />

          <InfoCard
            label="Last Sign In"
            value={formatDateTime(
              targetUser.last_sign_in_at
            )}
          />

          <InfoCard
            label="Active Wishlists"
            value={String(
              wishlists.length
            )}
          />

          <InfoCard
            label="Active Gifts"
            value={String(
              gifts.length
            )}
          />

          <InfoCard
            label="Active Reservations"
            value={String(
              reservations.length
            )}
          />

          <InfoCard
            label="Profile"
            value={
              profile
                ? "Available"
                : "Missing"
            }
          />
        </div>

        <div
          style={{
            background:
              "#ffffff",
            border:
              "1px solid #e5e7eb",
            borderRadius:
              "18px",
            padding:
              "24px",
            marginBottom:
              "32px",
          }}
        >
          <h2
            style={{
              margin:
                "0 0 16px",
              fontSize:
                "20px",
              fontWeight:
                "800",
            }}
          >
            Account Information
          </h2>

          <div
            style={{
              display:
                "grid",
              gridTemplateColumns:
                "repeat(auto-fit, minmax(min(100%, 260px), 1fr))",
              gap:
                "12px",
            }}
          >
            <DetailBox
              label="User ID"
              value={
                targetUser.id
              }
            />

            <DetailBox
              label="Email"
              value={
                targetEmail ||
                "Unknown"
              }
            />

            <DetailBox
              label="Display Name"
              value={
                displayName
              }
            />

            <DetailBox
              label="Profile Updated"
              value={
                profile
                  ? formatDateTime(
                      profile.updated_at
                    )
                  : "No profile row"
              }
            />
          </div>
        </div>

        <div
          style={{
            display:
              "flex",
            justifyContent:
              "space-between",
            alignItems:
              "center",
            gap:
              "16px",
            flexWrap:
              "wrap",
            marginBottom:
              "16px",
          }}
        >
          <div>
            <h2
              style={{
                margin: 0,
                fontSize:
                  "25px",
                fontWeight:
                  "800",
              }}
            >
              Wishlists
            </h2>

            <div
              style={{
                color:
                  "#6b7280",
                fontSize:
                  "13px",
                marginTop:
                  "5px",
              }}
            >
              Access codes are never displayed here.
            </div>
          </div>
        </div>

        {wishlists.length ===
        0 ? (
          <div
            style={{
              background:
                "#ffffff",
              border:
                "1px solid #e5e7eb",
              borderRadius:
                "18px",
              padding:
                "38px 24px",
              textAlign:
                "center",
              color:
                "#6b7280",
              marginBottom:
                "34px",
            }}
          >
            This user has no active wishlists.
          </div>
        ) : (
          <div
            style={{
              display:
                "grid",
              gap:
                "16px",
              marginBottom:
                "34px",
            }}
          >
            {wishlists.map(
              (wishlist) => {
                const giftCount =
                  giftCountByWishlist.get(
                    wishlist.id
                  ) || 0;

                const reservationCount =
                  reservationCountByWishlist.get(
                    wishlist.id
                  ) || 0;

                const publicUrl =
                  `${siteUrl}/wishlist/${wishlist.slug}`;

                return (
                  <article
                    key={
                      wishlist.id
                    }
                    style={{
                      background:
                        "#ffffff",
                      border:
                        "1px solid #e5e7eb",
                      borderRadius:
                        "18px",
                      padding:
                        "24px",
                      boxShadow:
                        "0 8px 25px rgba(0,0,0,0.035)",
                    }}
                  >
                    <div
                      style={{
                        display:
                          "flex",
                        justifyContent:
                          "space-between",
                        alignItems:
                          "flex-start",
                        gap:
                          "18px",
                        flexWrap:
                          "wrap",
                      }}
                    >
                      <div
                        style={{
                          flex:
                            "1 1 360px",
                          minWidth:
                            0,
                        }}
                      >
                        <div
                          style={{
                            display:
                              "flex",
                            alignItems:
                              "center",
                            gap:
                              "8px",
                            flexWrap:
                              "wrap",
                            marginBottom:
                              "7px",
                          }}
                        >
                          <h3
                            style={{
                              margin:
                                0,
                              fontSize:
                                "20px",
                              fontWeight:
                                "800",
                            }}
                          >
                            {
                              wishlist.title
                            }
                          </h3>

                          <StatusPill
                            label={
                              wishlist.is_live
                                ? "Live"
                                : "Draft"
                            }
                            kind={
                              wishlist.is_live
                                ? "green"
                                : "gray"
                            }
                          />

                          <StatusPill
                            label={
                              wishlist.access_code_hash
                                ? "Protected"
                                : "Open"
                            }
                            kind={
                              wishlist.access_code_hash
                                ? "blue"
                                : "gray"
                            }
                          />
                        </div>

                        <div
                          style={{
                            color:
                              "#6b7280",
                            fontSize:
                              "12px",
                            overflowWrap:
                              "anywhere",
                          }}
                        >
                          {
                            publicUrl
                          }
                        </div>

                        <div
                          style={{
                            display:
                              "flex",
                            gap:
                              "8px",
                            flexWrap:
                              "wrap",
                            marginTop:
                              "12px",
                          }}
                        >
                          <SmallStat
                            value={`${giftCount} ${
                              giftCount ===
                              1
                                ? "gift"
                                : "gifts"
                            }`}
                          />

                          <SmallStat
                            value={`${reservationCount} ${
                              reservationCount ===
                              1
                                ? "reservation"
                                : "reservations"
                            }`}
                          />

                          <SmallStat
                            value={`Created ${formatDate(
                              wishlist.created_at
                            )}`}
                          />
                        </div>

                        {wishlist.is_live && (
                          <a
                            href={
                              publicUrl
                            }
                            target="_blank"
                            rel="noreferrer"
                            style={{
                              display:
                                "inline-block",
                              color:
                                "#2563eb",
                              textDecoration:
                                "none",
                              fontSize:
                                "13px",
                              fontWeight:
                                "800",
                              marginTop:
                                "14px",
                            }}
                          >
                            View Public Wishlist →
                          </a>
                        )}
                      </div>
                    </div>

                    {!isAdminAccount && (
                      <div
                        style={{
                          borderTop:
                            "1px solid #e5e7eb",
                          marginTop:
                            "20px",
                          paddingTop:
                            "18px",
                          display:
                            "grid",
                          gridTemplateColumns:
                            "repeat(auto-fit, minmax(min(100%, 280px), 1fr))",
                          gap:
                            "14px",
                        }}
                      >
                        <div
                          style={{
                            background:
                              "#eff6ff",
                            border:
                              "1px solid #bfdbfe",
                            borderRadius:
                              "13px",
                            padding:
                              "16px",
                          }}
                        >
                          <div
                            style={{
                              color:
                                "#1e40af",
                              fontSize:
                                "14px",
                              fontWeight:
                                "800",
                              marginBottom:
                                "6px",
                            }}
                          >
                            Reset Access Code
                          </div>

                          <div
                            style={{
                              color:
                                "#3b5b92",
                              fontSize:
                                "12px",
                              lineHeight:
                                "1.55",
                              marginBottom:
                                "12px",
                            }}
                          >
                            This clears the current protection instead of revealing the existing code. The owner can set a new access code afterward.
                          </div>

                          {wishlist.access_code_hash ? (
                            <form
                              action={
                                resetAccessCode
                              }
                            >
                              <input
                                type="hidden"
                                name="wishlistId"
                                value={
                                  wishlist.id
                                }
                              />

                              <input
                                name="confirmation"
                                placeholder="Type RESET"
                                autoComplete="off"
                                style={{
                                  width:
                                    "100%",
                                  boxSizing:
                                    "border-box",
                                  border:
                                    "1px solid #bfdbfe",
                                  borderRadius:
                                    "9px",
                                  padding:
                                    "10px 11px",
                                  fontSize:
                                    "13px",
                                  outline:
                                    "none",
                                  marginBottom:
                                    "8px",
                                }}
                              />

                              <button
                                type="submit"
                                style={{
                                  width:
                                    "100%",
                                  background:
                                    "#2563eb",
                                  color:
                                    "#ffffff",
                                  border:
                                    "none",
                                  borderRadius:
                                    "9px",
                                  padding:
                                    "10px 12px",
                                  fontSize:
                                    "12px",
                                  fontWeight:
                                    "800",
                                  cursor:
                                    "pointer",
                                }}
                              >
                                Reset Access Code
                              </button>
                            </form>
                          ) : (
                            <div
                              style={{
                                color:
                                  "#1e40af",
                                fontSize:
                                  "12px",
                                fontWeight:
                                  "700",
                              }}
                            >
                              This wishlist is already open.
                            </div>
                          )}
                        </div>

                        <div
                          style={{
                            background:
                              "#fef2f2",
                            border:
                              "1px solid #fecaca",
                            borderRadius:
                              "13px",
                            padding:
                              "16px",
                          }}
                        >
                          <div
                            style={{
                              color:
                                "#991b1b",
                              fontSize:
                                "14px",
                              fontWeight:
                                "800",
                              marginBottom:
                                "6px",
                            }}
                          >
                            Delete Wishlist
                          </div>

                          <div
                            style={{
                              color:
                                "#7f1d1d",
                              fontSize:
                                "12px",
                              lineHeight:
                                "1.55",
                              marginBottom:
                                "12px",
                            }}
                          >
                            Archives the wishlist, gifts, and reservations for up to 90 days before removing the active copy.
                          </div>

                          <form
                            action={
                              deleteWishlist
                            }
                          >
                            <input
                              type="hidden"
                              name="wishlistId"
                              value={
                                wishlist.id
                              }
                            />

                            <input
                              name="confirmation"
                              placeholder="Type DELETE"
                              autoComplete="off"
                              style={{
                                width:
                                  "100%",
                                boxSizing:
                                  "border-box",
                                border:
                                  "1px solid #fecaca",
                                borderRadius:
                                  "9px",
                                padding:
                                  "10px 11px",
                                fontSize:
                                  "13px",
                                outline:
                                  "none",
                                marginBottom:
                                  "8px",
                              }}
                            />

                            <button
                              type="submit"
                              style={{
                                width:
                                  "100%",
                                background:
                                  "#dc2626",
                                color:
                                  "#ffffff",
                                border:
                                  "none",
                                borderRadius:
                                  "9px",
                                padding:
                                  "10px 12px",
                                fontSize:
                                  "12px",
                                fontWeight:
                                  "800",
                                cursor:
                                  "pointer",
                              }}
                            >
                              Delete Wishlist
                            </button>
                          </form>
                        </div>
                      </div>
                    )}
                  </article>
                );
              }
            )}
          </div>
        )}

        <div
          style={{
            background:
              "#ffffff",
            border:
              "1px solid #fecaca",
            borderRadius:
              "18px",
            padding:
              "24px",
          }}
        >
          <h2
            style={{
              margin:
                "0 0 8px",
              color:
                "#991b1b",
              fontSize:
                "22px",
              fontWeight:
                "800",
            }}
          >
            Administrative Actions
          </h2>

          {isAdminAccount ? (
            <div
              style={{
                background:
                  "#eff6ff",
                border:
                  "1px solid #bfdbfe",
                borderRadius:
                  "12px",
                padding:
                  "14px",
                color:
                  "#1e40af",
                fontSize:
                  "13px",
                lineHeight:
                  "1.6",
              }}
            >
              Destructive Admin actions are disabled for your own Admin account. Manage your own wishlists and account through the normal Dashboard and Settings pages.
            </div>
          ) : (
            <div
              style={{
                display:
                  "grid",
                gridTemplateColumns:
                  "repeat(auto-fit, minmax(min(100%, 300px), 1fr))",
                gap:
                  "16px",
                marginTop:
                  "18px",
              }}
            >
              <div
                style={{
                  background:
                    "#fff7ed",
                  border:
                    "1px solid #fed7aa",
                  borderRadius:
                    "13px",
                  padding:
                    "18px",
                }}
              >
                <div
                  style={{
                    color:
                      "#9a3412",
                    fontSize:
                      "16px",
                    fontWeight:
                      "800",
                    marginBottom:
                      "7px",
                  }}
                >
                  Reset User Data
                </div>

                <p
                  style={{
                    color:
                      "#7c2d12",
                    fontSize:
                      "12px",
                    lineHeight:
                      "1.6",
                    margin:
                      "0 0 13px",
                  }}
                >
                  Keeps the login and profile active, but archives and removes all current wishlists, gifts, and reservations. The archived wishlists are recoverable for up to 90 days.
                </p>

                <form
                  action={
                    resetUserData
                  }
                >
                  <input
                    name="confirmation"
                    placeholder="Type RESET USER"
                    autoComplete="off"
                    style={{
                      width:
                        "100%",
                      boxSizing:
                        "border-box",
                      border:
                        "1px solid #fed7aa",
                      borderRadius:
                        "9px",
                      padding:
                        "11px 12px",
                      fontSize:
                        "13px",
                      outline:
                        "none",
                      marginBottom:
                        "9px",
                    }}
                  />

                  <button
                    type="submit"
                    style={{
                      width:
                        "100%",
                      background:
                        "#ea580c",
                      color:
                        "#ffffff",
                      border:
                        "none",
                      borderRadius:
                        "9px",
                      padding:
                        "11px 12px",
                      fontSize:
                        "13px",
                      fontWeight:
                        "800",
                      cursor:
                        "pointer",
                    }}
                  >
                    Reset User Data
                  </button>
                </form>
              </div>

              <div
                style={{
                  background:
                    "#fef2f2",
                  border:
                    "1px solid #fecaca",
                  borderRadius:
                    "13px",
                  padding:
                    "18px",
                }}
              >
                <div
                  style={{
                    color:
                      "#991b1b",
                    fontSize:
                      "16px",
                    fontWeight:
                      "800",
                    marginBottom:
                      "7px",
                  }}
                >
                  Delete Account
                </div>

                <p
                  style={{
                    color:
                      "#7f1d1d",
                    fontSize:
                      "12px",
                    lineHeight:
                      "1.6",
                    margin:
                      "0 0 13px",
                  }}
                >
                  Archives the profile and wishlist data for up to 90 days, then deletes the active Supabase login account. Recovery later requires the customer to sign in again with the same email and contact Support.
                </p>

                <form
                  action={
                    deleteAccount
                  }
                >
                  <input
                    name="confirmation"
                    placeholder="Type DELETE ACCOUNT"
                    autoComplete="off"
                    style={{
                      width:
                        "100%",
                      boxSizing:
                        "border-box",
                      border:
                        "1px solid #fecaca",
                      borderRadius:
                        "9px",
                      padding:
                        "11px 12px",
                      fontSize:
                        "13px",
                      outline:
                        "none",
                      marginBottom:
                        "9px",
                    }}
                  />

                  <button
                    type="submit"
                    style={{
                      width:
                        "100%",
                      background:
                        "#dc2626",
                      color:
                        "#ffffff",
                      border:
                        "none",
                      borderRadius:
                        "9px",
                      padding:
                        "11px 12px",
                      fontSize:
                        "13px",
                      fontWeight:
                        "800",
                      cursor:
                        "pointer",
                    }}
                  >
                    Delete Account
                  </button>
                </form>
              </div>
            </div>
          )}
        </div>

        <div
          style={{
            marginTop:
              "24px",
            padding:
              "15px 17px",
            background:
              "#eff6ff",
            border:
              "1px solid #bfdbfe",
            borderRadius:
              "13px",
            color:
              "#1e40af",
            fontSize:
              "12px",
            lineHeight:
              "1.6",
          }}
        >
          Sensitive actions on this page are re-authorized on the server and recorded in the Admin Activity Log. Existing wishlist access codes are never displayed to Admin.
        </div>
      </section>
    </main>
  );
}

function InfoCard({
  label,
  value,
}: {
  label: string;
  value: string;
}) {
  return (
    <div
      style={{
        background:
          "#ffffff",
        border:
          "1px solid #e5e7eb",
        borderRadius:
          "15px",
        padding:
          "18px",
      }}
    >
      <div
        style={{
          color:
            "#6b7280",
          fontSize:
            "10px",
          fontWeight:
            "900",
          letterSpacing:
            "0.4px",
          marginBottom:
            "7px",
        }}
      >
        {label.toUpperCase()}
      </div>

      <div
        style={{
          color:
            "#111827",
          fontSize:
            "16px",
          fontWeight:
            "800",
          overflowWrap:
            "anywhere",
        }}
      >
        {value}
      </div>
    </div>
  );
}

function DetailBox({
  label,
  value,
}: {
  label: string;
  value: string;
}) {
  return (
    <div
      style={{
        background:
          "#f8fafc",
        border:
          "1px solid #e5e7eb",
        borderRadius:
          "11px",
        padding:
          "13px",
      }}
    >
      <div
        style={{
          color:
            "#9ca3af",
          fontSize:
            "10px",
          fontWeight:
            "900",
          marginBottom:
            "5px",
        }}
      >
        {label.toUpperCase()}
      </div>

      <div
        style={{
          color:
            "#374151",
          fontSize:
            "12px",
          fontWeight:
            "700",
          lineHeight:
            "1.5",
          overflowWrap:
            "anywhere",
        }}
      >
        {value}
      </div>
    </div>
  );
}

function SmallStat({
  value,
}: {
  value: string;
}) {
  return (
    <span
      style={{
        background:
          "#f8fafc",
        border:
          "1px solid #e5e7eb",
        borderRadius:
          "999px",
        padding:
          "5px 9px",
        color:
          "#6b7280",
        fontSize:
          "11px",
        fontWeight:
          "800",
      }}
    >
      {value}
    </span>
  );
}

function StatusPill({
  label,
  kind,
}: {
  label: string;
  kind:
    | "blue"
    | "green"
    | "gray";
}) {
  const styles =
    kind === "blue"
      ? {
          background:
            "#eff6ff",
          color:
            "#2563eb",
          border:
            "1px solid #bfdbfe",
        }
      : kind === "green"
        ? {
            background:
              "#ecfdf5",
            color:
              "#047857",
            border:
              "1px solid #a7f3d0",
          }
        : {
            background:
              "#f3f4f6",
            color:
              "#6b7280",
            border:
              "1px solid #d1d5db",
          };

  return (
    <span
      style={{
        ...styles,
        borderRadius:
          "999px",
        padding:
          "5px 9px",
        fontSize:
          "10px",
        fontWeight:
          "900",
      }}
    >
      {label}
    </span>
  );
}
