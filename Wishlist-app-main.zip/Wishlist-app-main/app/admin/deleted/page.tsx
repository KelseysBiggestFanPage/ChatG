import type { User } from "@supabase/supabase-js";
import Link from "next/link";
import { redirect } from "next/navigation";
import GoWishlistLogo from "../../../components/GoWishlistLogo";
import { createAdminClient } from "../../../lib/supabase/admin";
import { createClient } from "../../../lib/supabase/server";

export const dynamic = "force-dynamic";

type DeletedAccount = {
  id: string;
  original_user_id: string;
  email: string;
  display_name: string | null;
  auth_created_at: string | null;
  deleted_by: "self" | "admin";
  deleted_at: string;
  recover_until: string;
  restored_at: string | null;
};

type DeletedWishlist = {
  id: string;
  original_wishlist_id: string;
  original_owner_id: string;
  owner_email: string | null;
  title: string;
  original_slug: string;
  was_live: boolean;
  gifts_snapshot: unknown;
  reservations_snapshot: unknown;
  deleted_by:
    | "owner"
    | "admin"
    | "account_delete"
    | "account_reset";
  deleted_at: string;
  recover_until: string;
  restored_at: string | null;
  account_archive_id: string | null;
};

async function getAllAuthUsers(
  admin: ReturnType<typeof createAdminClient>
) {
  const users: User[] = [];
  const perPage = 100;
  let page = 1;

  while (true) {
    const {
      data,
      error,
    } = await admin.auth.admin.listUsers({
      page,
      perPage,
    });

    if (error) {
      throw error;
    }

    const batch =
      data.users || [];

    users.push(...batch);

    if (
      batch.length <
      perPage
    ) {
      break;
    }

    page += 1;

    if (page > 1000) {
      break;
    }
  }

  return users;
}

function formatDate(
  value: string | null
) {
  if (!value) {
    return "Unknown";
  }

  const date =
    new Date(value);

  if (
    Number.isNaN(
      date.getTime()
    )
  ) {
    return "Unknown";
  }

  return new Intl.DateTimeFormat(
    "en-US",
    {
      dateStyle: "medium",
    }
  ).format(date);
}

function getDaysRemaining(
  value: string
) {
  const deadline =
    new Date(value)
      .getTime();

  if (
    Number.isNaN(deadline)
  ) {
    return 0;
  }

  return Math.max(
    0,
    Math.ceil(
      (deadline - Date.now()) /
        (1000 * 60 * 60 * 24)
    )
  );
}

function getArrayCount(
  value: unknown
) {
  return Array.isArray(value)
    ? value.length
    : 0;
}

function normalizeEmail(
  value: string | null | undefined
) {
  return String(value || "")
    .trim()
    .toLowerCase();
}

export default async function AdminDeletedPage({
  searchParams,
}: {
  searchParams: Promise<{
    q?: string;
    success?: string;
    error?: string;
  }>;
}) {
  const query =
    await searchParams;

  const supabase =
    await createClient();

  const {
    data: { user },
  } =
    await supabase.auth.getUser();

  if (!user) {
    redirect("/home");
  }

  const adminEmail =
    process.env.ADMIN_EMAIL
      ?.trim()
      .toLowerCase();

  const currentEmail =
    user.email
      ?.trim()
      .toLowerCase();

  if (
    !adminEmail ||
    !currentEmail ||
    currentEmail !==
      adminEmail
  ) {
    redirect("/dashboard");
  }

  const admin =
    createAdminClient();

  const {
    error: purgeError,
  } = await admin.rpc(
    "purge_expired_deleted_data"
  );

  if (purgeError) {
    console.error(
      "Deleted data purge error:",
      purgeError
    );
  }

  const now =
    new Date().toISOString();

  const [
    accountsResult,
    wishlistsResult,
    authUsersResult,
  ] = await Promise.all([
    admin
      .from("deleted_accounts")
      .select(
        "id, original_user_id, email, display_name, auth_created_at, deleted_by, deleted_at, recover_until, restored_at"
      )
      .is("restored_at", null)
      .gt("recover_until", now)
      .order("deleted_at", {
        ascending: false,
      })
      .limit(500),

    admin
      .from("deleted_wishlists")
      .select(
        "id, original_wishlist_id, original_owner_id, owner_email, title, original_slug, was_live, gifts_snapshot, reservations_snapshot, deleted_by, deleted_at, recover_until, restored_at, account_archive_id"
      )
      .is("restored_at", null)
      .gt("recover_until", now)
      .order("deleted_at", {
        ascending: false,
      })
      .limit(1000),

    getAllAuthUsers(admin)
      .then((users) => ({
        users,
        error: null,
      }))
      .catch((error) => ({
        users: [] as User[],
        error,
      })),
  ]);

  if (accountsResult.error) {
    console.error(
      "Deleted accounts load error:",
      accountsResult.error
    );
  }

  if (wishlistsResult.error) {
    console.error(
      "Deleted wishlists load error:",
      wishlistsResult.error
    );
  }

  if (authUsersResult.error) {
    console.error(
      "Deleted data auth users load error:",
      authUsersResult.error
    );
  }

  const deletedAccounts =
    (accountsResult.data ||
      []) as DeletedAccount[];

  const deletedWishlists =
    (wishlistsResult.data ||
      []) as DeletedWishlist[];

  const authUsers =
    authUsersResult.users;

  const authUserById =
    new Map(
      authUsers.map(
        (authUser) => [
          authUser.id,
          authUser,
        ]
      )
    );

  const authUserByEmail =
    new Map<string, User>();

  for (
    const authUser
    of authUsers
  ) {
    const email =
      normalizeEmail(
        authUser.email
      );

    if (email) {
      authUserByEmail.set(
        email,
        authUser
      );
    }
  }

  const linkedWishlistsByAccount =
    new Map<
      string,
      DeletedWishlist[]
    >();

  for (
    const wishlist
    of deletedWishlists
  ) {
    if (
      !wishlist.account_archive_id
    ) {
      continue;
    }

    const current =
      linkedWishlistsByAccount.get(
        wishlist.account_archive_id
      ) || [];

    current.push(wishlist);

    linkedWishlistsByAccount.set(
      wishlist.account_archive_id,
      current
    );
  }

  const search =
    String(query.q || "")
      .trim()
      .toLowerCase();

  const filteredAccounts =
    search
      ? deletedAccounts.filter(
          (account) =>
            account.email
              .toLowerCase()
              .includes(search) ||
            String(
              account.display_name ||
                ""
            )
              .toLowerCase()
              .includes(search)
        )
      : deletedAccounts;

  const filteredWishlists =
    search
      ? deletedWishlists.filter(
          (wishlist) =>
            wishlist.title
              .toLowerCase()
              .includes(search) ||
            wishlist.original_slug
              .toLowerCase()
              .includes(search) ||
            String(
              wishlist.owner_email ||
                ""
            )
              .toLowerCase()
              .includes(search)
        )
      : deletedWishlists;

  async function restoreAccount(
    formData: FormData
  ) {
    "use server";

    const supabase =
      await createClient();

    const {
      data: { user },
    } =
      await supabase.auth.getUser();

    if (!user) {
      redirect("/home");
    }

    const adminEmail =
      process.env.ADMIN_EMAIL
        ?.trim()
        .toLowerCase();

    const currentEmail =
      user.email
        ?.trim()
        .toLowerCase();

    if (
      !adminEmail ||
      !currentEmail ||
      currentEmail !==
        adminEmail
    ) {
      redirect("/dashboard");
    }

    const archiveId =
      String(
        formData.get(
          "archiveId"
        ) || ""
      ).trim();

    const confirmation =
      String(
        formData.get(
          "confirmation"
        ) || ""
      ).trim();

    if (
      !archiveId ||
      confirmation !==
        "RESTORE"
    ) {
      redirect(
        "/admin/deleted?error=confirm"
      );
    }

    const admin =
      createAdminClient();

    const {
      data: archive,
      error: archiveError,
    } = await admin
      .from("deleted_accounts")
      .select(
        "id, original_user_id, email, recover_until, restored_at"
      )
      .eq("id", archiveId)
      .maybeSingle();

    if (
      archiveError ||
      !archive ||
      archive.restored_at ||
      new Date(
        archive.recover_until
      ).getTime() <= Date.now()
    ) {
      console.error(
        "Restore account archive lookup error:",
        archiveError
      );

      redirect(
        "/admin/deleted?error=account-unavailable"
      );
    }

    let authUsers: User[] = [];

    try {
      authUsers =
        await getAllAuthUsers(
          admin
        );
    } catch (error) {
      console.error(
        "Restore account auth lookup error:",
        error
      );

      redirect(
        "/admin/deleted?error=account-restore"
      );
    }

    const targetUser =
      authUsers.find(
        (candidate) =>
          normalizeEmail(
            candidate.email
          ) ===
          normalizeEmail(
            archive.email
          )
      );

    if (!targetUser) {
      redirect(
        "/admin/deleted?error=account-needs-signin"
      );
    }

    const {
      data: restoredUserId,
      error: restoreError,
    } = await admin.rpc(
      "restore_deleted_account",
      {
        p_archive_id:
          archive.id,
        p_target_user_id:
          targetUser.id,
        p_restored_by:
          currentEmail,
      }
    );

    if (restoreError) {
      console.error(
        "Restore deleted account error:",
        restoreError
      );

      redirect(
        "/admin/deleted?error=account-restore"
      );
    }

    const {
      error: logError,
    } = await admin
      .from(
        "admin_activity_log"
      )
      .insert({
        admin_user_id:
          user.id,
        admin_email:
          currentEmail,
        action:
          "restore_deleted_account",
        target_user_id:
          targetUser.id,
        target_email:
          archive.email,
        details: {
          archive_id:
            archive.id,
          original_user_id:
            archive.original_user_id,
          restored_to_user_id:
            restoredUserId ||
            targetUser.id,
        },
      });

    if (logError) {
      console.error(
        "Restore account activity log error:",
        logError
      );
    }

    redirect(
      "/admin/deleted?success=account"
    );
  }

  async function restoreWishlist(
    formData: FormData
  ) {
    "use server";

    const supabase =
      await createClient();

    const {
      data: { user },
    } =
      await supabase.auth.getUser();

    if (!user) {
      redirect("/home");
    }

    const adminEmail =
      process.env.ADMIN_EMAIL
        ?.trim()
        .toLowerCase();

    const currentEmail =
      user.email
        ?.trim()
        .toLowerCase();

    if (
      !adminEmail ||
      !currentEmail ||
      currentEmail !==
        adminEmail
    ) {
      redirect("/dashboard");
    }

    const archiveId =
      String(
        formData.get(
          "archiveId"
        ) || ""
      ).trim();

    const confirmation =
      String(
        formData.get(
          "confirmation"
        ) || ""
      ).trim();

    if (
      !archiveId ||
      confirmation !==
        "RESTORE"
    ) {
      redirect(
        "/admin/deleted?error=confirm"
      );
    }

    const admin =
      createAdminClient();

    const {
      data: archive,
      error: archiveError,
    } = await admin
      .from("deleted_wishlists")
      .select(
        "id, original_wishlist_id, original_owner_id, owner_email, title, original_slug, recover_until, restored_at, account_archive_id"
      )
      .eq("id", archiveId)
      .maybeSingle();

    if (
      archiveError ||
      !archive ||
      archive.restored_at ||
      new Date(
        archive.recover_until
      ).getTime() <= Date.now()
    ) {
      console.error(
        "Restore wishlist archive lookup error:",
        archiveError
      );

      redirect(
        "/admin/deleted?error=wishlist-unavailable"
      );
    }

    if (
      archive.account_archive_id
    ) {
      redirect(
        "/admin/deleted?error=restore-through-account"
      );
    }

    const {
      data: ownerResult,
      error: ownerError,
    } =
      await admin.auth.admin.getUserById(
        archive.original_owner_id
      );

    const ownerUser =
      ownerResult?.user;

    if (
      ownerError ||
      !ownerUser
    ) {
      console.error(
        "Restore wishlist owner lookup error:",
        ownerError
      );

      redirect(
        "/admin/deleted?error=wishlist-owner-missing"
      );
    }

    const {
      data: restoredWishlistId,
      error: restoreError,
    } = await admin.rpc(
      "restore_deleted_wishlist",
      {
        p_archive_id:
          archive.id,
        p_target_owner_id:
          ownerUser.id,
        p_restored_by:
          currentEmail,
      }
    );

    if (restoreError) {
      console.error(
        "Restore deleted wishlist error:",
        restoreError
      );

      redirect(
        "/admin/deleted?error=wishlist-restore"
      );
    }

    const {
      data: restoredArchive,
    } = await admin
      .from("deleted_wishlists")
      .select(
        "restored_wishlist_id, restored_slug"
      )
      .eq("id", archive.id)
      .maybeSingle();

    const {
      error: logError,
    } = await admin
      .from(
        "admin_activity_log"
      )
      .insert({
        admin_user_id:
          user.id,
        admin_email:
          currentEmail,
        action:
          "restore_deleted_wishlist",
        target_user_id:
          ownerUser.id,
        target_email:
          archive.owner_email ||
          ownerUser.email ||
          null,
        target_wishlist_id:
          restoredArchive
            ?.restored_wishlist_id ||
          restoredWishlistId ||
          null,
        details: {
          archive_id:
            archive.id,
          original_wishlist_id:
            archive.original_wishlist_id,
          original_slug:
            archive.original_slug,
          restored_slug:
            restoredArchive
              ?.restored_slug ||
            null,
        },
      });

    if (logError) {
      console.error(
        "Restore wishlist activity log error:",
        logError
      );
    }

    redirect(
      "/admin/deleted?success=wishlist"
    );
  }

  let successMessage = "";

  if (
    query.success ===
    "account"
  ) {
    successMessage =
      "Account data restored successfully.";
  }

  if (
    query.success ===
    "wishlist"
  ) {
    successMessage =
      "Wishlist restored successfully.";
  }

  let errorMessage = "";

  if (
    query.error ===
    "confirm"
  ) {
    errorMessage =
      "Type RESTORE exactly before restoring deleted data.";
  }

  if (
    query.error ===
    "account-needs-signin"
  ) {
    errorMessage =
      "That customer must sign in to GoWishlist again with the same Google email before you can restore the deleted account data.";
  }

  if (
    query.error ===
    "account-unavailable"
  ) {
    errorMessage =
      "That deleted account archive is no longer available for recovery.";
  }

  if (
    query.error ===
    "account-restore"
  ) {
    errorMessage =
      "The deleted account could not be restored. Make sure the restore SQL has been run and try again.";
  }

  if (
    query.error ===
    "wishlist-unavailable"
  ) {
    errorMessage =
      "That deleted wishlist archive is no longer available for recovery.";
  }

  if (
    query.error ===
    "restore-through-account"
  ) {
    errorMessage =
      "That wishlist belongs to a deleted-account archive. Restore the deleted account instead so its wishlists are restored together.";
  }

  if (
    query.error ===
    "wishlist-owner-missing"
  ) {
    errorMessage =
      "The original wishlist owner does not currently have an active GoWishlist account, so this wishlist cannot be restored yet.";
  }

  if (
    query.error ===
    "wishlist-restore"
  ) {
    errorMessage =
      "The deleted wishlist could not be restored. Make sure the restore SQL has been run and try again.";
  }

  return (
    <main
      style={{
        minHeight: "100vh",
        background: "#f8fafc",
        color: "#111827",
      }}
    >
      <header
        style={{
          background: "#ffffff",
          borderBottom:
            "1px solid #e5e7eb",
        }}
      >
        <div
          style={{
            maxWidth: "1200px",
            margin: "0 auto",
            padding: "20px 30px",
            display: "flex",
            justifyContent:
              "space-between",
            alignItems: "center",
            gap: "20px",
            flexWrap: "wrap",
          }}
        >
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "16px",
            }}
          >
            <GoWishlistLogo
              href="/dashboard"
              size={29}
            />

            <div
              style={{
                background: "#eff6ff",
                color: "#2563eb",
                border:
                  "1px solid #bfdbfe",
                borderRadius: "999px",
                padding: "6px 10px",
                fontSize: "11px",
                fontWeight: "900",
                letterSpacing: "0.6px",
              }}
            >
              ADMIN
            </div>
          </div>

          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "16px",
              flexWrap: "wrap",
            }}
          >
            <Link
              href="/admin"
              style={{
                color: "#2563eb",
                textDecoration: "none",
                fontSize: "14px",
                fontWeight: "800",
              }}
            >
              Overview
            </Link>

            <Link
              href="/admin/users"
              style={{
                color: "#374151",
                textDecoration: "none",
                fontSize: "14px",
                fontWeight: "700",
              }}
            >
              Users
            </Link>

            <Link
              href="/admin/support"
              style={{
                color: "#374151",
                textDecoration: "none",
                fontSize: "14px",
                fontWeight: "700",
              }}
            >
              Support
            </Link>

            <Link
              href="/dashboard"
              style={{
                color: "#6b7280",
                textDecoration: "none",
                fontSize: "14px",
                fontWeight: "700",
              }}
            >
              Dashboard
            </Link>
          </div>
        </div>
      </header>

      <section
        style={{
          maxWidth: "1200px",
          margin: "0 auto",
          padding: "50px 30px 90px",
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent:
              "space-between",
            alignItems:
              "flex-end",
            gap: "20px",
            flexWrap: "wrap",
            marginBottom: "28px",
          }}
        >
          <div>
            <div
              style={{
                color: "#2563eb",
                fontSize: "12px",
                fontWeight: "900",
                letterSpacing: "0.8px",
                marginBottom: "7px",
              }}
            >
              ADMIN RECOVERY
            </div>

            <h1
              style={{
                margin: 0,
                fontSize: "40px",
                lineHeight: "1.1",
                fontWeight: "800",
                letterSpacing: "-1.6px",
              }}
            >
              Deleted Data
            </h1>

            <p
              style={{
                color: "#6b7280",
                fontSize: "14px",
                lineHeight: "1.6",
                margin: "10px 0 0",
                maxWidth: "680px",
              }}
            >
              Recover eligible accounts and wishlists during their 90-day recovery window. Expired archives are removed when cleanup runs.
            </p>
          </div>

          <form
            method="get"
            style={{
              display: "flex",
              gap: "8px",
              flexWrap: "wrap",
            }}
          >
            <input
              type="search"
              name="q"
              defaultValue={
                query.q || ""
              }
              placeholder="Search email, name, title, or slug"
              style={{
                width: "300px",
                maxWidth: "100%",
                border:
                  "1px solid #d1d5db",
                borderRadius: "10px",
                padding: "11px 13px",
                fontSize: "14px",
                outline: "none",
              }}
            />

            <button
              type="submit"
              style={{
                background: "#2563eb",
                color: "#ffffff",
                border: "none",
                borderRadius: "10px",
                padding: "11px 16px",
                fontSize: "14px",
                fontWeight: "800",
                cursor: "pointer",
              }}
            >
              Search
            </button>

            {search && (
              <Link
                href="/admin/deleted"
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  justifyContent:
                    "center",
                  color: "#374151",
                  background: "#ffffff",
                  border:
                    "1px solid #d1d5db",
                  borderRadius: "10px",
                  padding: "11px 16px",
                  fontSize: "14px",
                  fontWeight: "700",
                  textDecoration: "none",
                }}
              >
                Clear
              </Link>
            )}
          </form>
        </div>

        {successMessage && (
          <div
            style={{
              background: "#f0fdf4",
              border:
                "1px solid #bbf7d0",
              color: "#166534",
              borderRadius: "13px",
              padding: "14px 16px",
              fontSize: "14px",
              fontWeight: "700",
              lineHeight: "1.55",
              marginBottom: "20px",
            }}
          >
            {successMessage}
          </div>
        )}

        {errorMessage && (
          <div
            style={{
              background: "#fef2f2",
              border:
                "1px solid #fecaca",
              color: "#b91c1c",
              borderRadius: "13px",
              padding: "14px 16px",
              fontSize: "14px",
              fontWeight: "700",
              lineHeight: "1.55",
              marginBottom: "20px",
            }}
          >
            {errorMessage}
          </div>
        )}

        <div
          style={{
            background: "#eff6ff",
            border:
              "1px solid #bfdbfe",
            borderRadius: "14px",
            padding: "16px 18px",
            color: "#1e40af",
            fontSize: "13px",
            lineHeight: "1.6",
            marginBottom: "32px",
          }}
        >
          For deleted accounts, the customer must first sign in to GoWishlist again with the same Google email. That creates a fresh login account. You can then restore the archived GoWishlist profile and wishlists into that account after verifying the support request.
        </div>

        <div
          style={{
            display: "flex",
            justifyContent:
              "space-between",
            alignItems: "center",
            gap: "16px",
            flexWrap: "wrap",
            marginBottom: "16px",
          }}
        >
          <div>
            <h2
              style={{
                margin: 0,
                fontSize: "25px",
                fontWeight: "800",
              }}
            >
              Deleted Accounts
            </h2>

            <div
              style={{
                color: "#6b7280",
                fontSize: "13px",
                marginTop: "5px",
              }}
            >
              {filteredAccounts.length} recoverable {filteredAccounts.length === 1 ? "account" : "accounts"}
            </div>
          </div>
        </div>

        {filteredAccounts.length === 0 ? (
          <div
            style={{
              background: "#ffffff",
              border:
                "1px solid #e5e7eb",
              borderRadius: "18px",
              padding: "38px 24px",
              textAlign: "center",
              color: "#6b7280",
              marginBottom: "42px",
            }}
          >
            {search
              ? "No deleted accounts match your search."
              : "No recoverable deleted accounts."}
          </div>
        ) : (
          <div
            style={{
              display: "grid",
              gap: "16px",
              marginBottom: "42px",
            }}
          >
            {filteredAccounts.map(
              (account) => {
                const targetUser =
                  authUserByEmail.get(
                    normalizeEmail(
                      account.email
                    )
                  );

                const linkedWishlists =
                  linkedWishlistsByAccount.get(
                    account.id
                  ) || [];

                const daysRemaining =
                  getDaysRemaining(
                    account.recover_until
                  );

                return (
                  <article
                    key={account.id}
                    style={{
                      background: "#ffffff",
                      border:
                        "1px solid #e5e7eb",
                      borderRadius: "18px",
                      padding: "24px",
                      boxShadow:
                        "0 8px 25px rgba(0,0,0,0.035)",
                    }}
                  >
                    <div
                      style={{
                        display: "flex",
                        justifyContent:
                          "space-between",
                        alignItems:
                          "flex-start",
                        gap: "18px",
                        flexWrap: "wrap",
                      }}
                    >
                      <div
                        style={{
                          minWidth: 0,
                          flex: "1 1 380px",
                        }}
                      >
                        <div
                          style={{
                            display: "flex",
                            alignItems: "center",
                            gap: "8px",
                            flexWrap: "wrap",
                            marginBottom: "5px",
                          }}
                        >
                          <h3
                            style={{
                              margin: 0,
                              fontSize: "20px",
                              fontWeight: "800",
                            }}
                          >
                            {account.display_name ||
                              "No name saved"}
                          </h3>

                          <span
                            style={{
                              background:
                                targetUser
                                  ? "#ecfdf5"
                                  : "#fff7ed",
                              color:
                                targetUser
                                  ? "#047857"
                                  : "#c2410c",
                              border:
                                targetUser
                                  ? "1px solid #a7f3d0"
                                  : "1px solid #fed7aa",
                              borderRadius: "999px",
                              padding: "5px 9px",
                              fontSize: "10px",
                              fontWeight: "900",
                            }}
                          >
                            {targetUser
                              ? "READY TO RESTORE"
                              : "WAITING FOR SIGN-IN"}
                          </span>
                        </div>

                        <div
                          style={{
                            color: "#4b5563",
                            fontSize: "14px",
                            overflowWrap: "anywhere",
                          }}
                        >
                          {account.email}
                        </div>

                        <div
                          style={{
                            display: "flex",
                            gap: "12px",
                            flexWrap: "wrap",
                            color: "#6b7280",
                            fontSize: "12px",
                            marginTop: "10px",
                          }}
                        >
                          <span>
                            Deleted {formatDate(account.deleted_at)}
                          </span>

                          <span>
                            Recover until {formatDate(account.recover_until)}
                          </span>

                          <span
                            style={{
                              color:
                                daysRemaining <= 14
                                  ? "#b91c1c"
                                  : "#2563eb",
                              fontWeight: "800",
                            }}
                          >
                            {daysRemaining} {daysRemaining === 1 ? "day" : "days"} remaining
                          </span>
                        </div>

                        <div
                          style={{
                            display: "flex",
                            gap: "8px",
                            flexWrap: "wrap",
                            marginTop: "12px",
                          }}
                        >
                          <span
                            style={{
                              background: "#f8fafc",
                              border:
                                "1px solid #e5e7eb",
                              borderRadius: "999px",
                              padding: "5px 9px",
                              color: "#6b7280",
                              fontSize: "11px",
                              fontWeight: "800",
                            }}
                          >
                            {linkedWishlists.length} archived {linkedWishlists.length === 1 ? "wishlist" : "wishlists"}
                          </span>

                          <span
                            style={{
                              background: "#f8fafc",
                              border:
                                "1px solid #e5e7eb",
                              borderRadius: "999px",
                              padding: "5px 9px",
                              color: "#6b7280",
                              fontSize: "11px",
                              fontWeight: "800",
                            }}
                          >
                            Deleted by {account.deleted_by === "self" ? "user" : "admin"}
                          </span>
                        </div>
                      </div>

                      <div
                        style={{
                          flex: "0 1 280px",
                          width: "100%",
                        }}
                      >
                        {targetUser ? (
                          <form
                            action={restoreAccount}
                          >
                            <input
                              type="hidden"
                              name="archiveId"
                              value={account.id}
                            />

                            <label
                              htmlFor={`account-confirm-${account.id}`}
                              style={{
                                display: "block",
                                fontSize: "11px",
                                fontWeight: "800",
                                color: "#6b7280",
                                marginBottom: "6px",
                              }}
                            >
                              Type RESTORE to confirm
                            </label>

                            <input
                              id={`account-confirm-${account.id}`}
                              name="confirmation"
                              placeholder="RESTORE"
                              autoComplete="off"
                              style={{
                                width: "100%",
                                boxSizing: "border-box",
                                border:
                                  "1px solid #bfdbfe",
                                borderRadius: "9px",
                                padding: "10px 11px",
                                fontSize: "13px",
                                outline: "none",
                                marginBottom: "8px",
                              }}
                            />

                            <button
                              type="submit"
                              style={{
                                width: "100%",
                                background: "#2563eb",
                                color: "#ffffff",
                                border: "none",
                                borderRadius: "9px",
                                padding: "11px 12px",
                                fontSize: "13px",
                                fontWeight: "800",
                                cursor: "pointer",
                              }}
                            >
                              Restore Account Data
                            </button>
                          </form>
                        ) : (
                          <div
                            style={{
                              background: "#fff7ed",
                              border:
                                "1px solid #fed7aa",
                              borderRadius: "11px",
                              padding: "12px 13px",
                              color: "#9a3412",
                              fontSize: "12px",
                              lineHeight: "1.55",
                            }}
                          >
                            Ask the customer through Support to sign in again with <strong>{account.email}</strong>. Refresh this page afterward and the restore button will become available.
                          </div>
                        )}
                      </div>
                    </div>
                  </article>
                );
              }
            )}
          </div>
        )}

        <div
          style={{
            display: "flex",
            justifyContent:
              "space-between",
            alignItems: "center",
            gap: "16px",
            flexWrap: "wrap",
            marginBottom: "16px",
          }}
        >
          <div>
            <h2
              style={{
                margin: 0,
                fontSize: "25px",
                fontWeight: "800",
              }}
            >
              Deleted Wishlists
            </h2>

            <div
              style={{
                color: "#6b7280",
                fontSize: "13px",
                marginTop: "5px",
              }}
            >
              {filteredWishlists.length} recoverable {filteredWishlists.length === 1 ? "wishlist" : "wishlists"}
            </div>
          </div>
        </div>

        {filteredWishlists.length === 0 ? (
          <div
            style={{
              background: "#ffffff",
              border:
                "1px solid #e5e7eb",
              borderRadius: "18px",
              padding: "38px 24px",
              textAlign: "center",
              color: "#6b7280",
            }}
          >
            {search
              ? "No deleted wishlists match your search."
              : "No recoverable deleted wishlists."}
          </div>
        ) : (
          <div
            style={{
              display: "grid",
              gap: "16px",
            }}
          >
            {filteredWishlists.map(
              (wishlist) => {
                const ownerUser =
                  authUserById.get(
                    wishlist.original_owner_id
                  );

                const linkedToAccount =
                  Boolean(
                    wishlist.account_archive_id
                  );

                const gifts =
                  getArrayCount(
                    wishlist.gifts_snapshot
                  );

                const reservations =
                  getArrayCount(
                    wishlist.reservations_snapshot
                  );

                const daysRemaining =
                  getDaysRemaining(
                    wishlist.recover_until
                  );

                return (
                  <article
                    key={wishlist.id}
                    style={{
                      background: "#ffffff",
                      border:
                        "1px solid #e5e7eb",
                      borderRadius: "18px",
                      padding: "24px",
                      boxShadow:
                        "0 8px 25px rgba(0,0,0,0.035)",
                    }}
                  >
                    <div
                      style={{
                        display: "flex",
                        justifyContent:
                          "space-between",
                        alignItems:
                          "flex-start",
                        gap: "18px",
                        flexWrap: "wrap",
                      }}
                    >
                      <div
                        style={{
                          minWidth: 0,
                          flex: "1 1 380px",
                        }}
                      >
                        <div
                          style={{
                            display: "flex",
                            alignItems: "center",
                            gap: "8px",
                            flexWrap: "wrap",
                            marginBottom: "6px",
                          }}
                        >
                          <h3
                            style={{
                              margin: 0,
                              fontSize: "20px",
                              fontWeight: "800",
                            }}
                          >
                            {wishlist.title}
                          </h3>

                          <span
                            style={{
                              background:
                                wishlist.was_live
                                  ? "#ecfdf5"
                                  : "#f3f4f6",
                              color:
                                wishlist.was_live
                                  ? "#047857"
                                  : "#6b7280",
                              border:
                                wishlist.was_live
                                  ? "1px solid #a7f3d0"
                                  : "1px solid #d1d5db",
                              borderRadius: "999px",
                              padding: "5px 9px",
                              fontSize: "10px",
                              fontWeight: "900",
                            }}
                          >
                            {wishlist.was_live
                              ? "WAS LIVE"
                              : "WAS DRAFT"}
                          </span>

                          {linkedToAccount && (
                            <span
                              style={{
                                background: "#eff6ff",
                                color: "#2563eb",
                                border:
                                  "1px solid #bfdbfe",
                                borderRadius: "999px",
                                padding: "5px 9px",
                                fontSize: "10px",
                                fontWeight: "900",
                              }}
                            >
                              ACCOUNT ARCHIVE
                            </span>
                          )}
                        </div>

                        <div
                          style={{
                            color: "#4b5563",
                            fontSize: "13px",
                            overflowWrap: "anywhere",
                          }}
                        >
                          Original link: /wishlist/{wishlist.original_slug}
                        </div>

                        <div
                          style={{
                            color: "#6b7280",
                            fontSize: "12px",
                            marginTop: "6px",
                            overflowWrap: "anywhere",
                          }}
                        >
                          Owner: {wishlist.owner_email || "Unknown email"}
                        </div>

                        <div
                          style={{
                            display: "flex",
                            gap: "12px",
                            flexWrap: "wrap",
                            color: "#6b7280",
                            fontSize: "12px",
                            marginTop: "10px",
                          }}
                        >
                          <span>
                            Deleted {formatDate(wishlist.deleted_at)}
                          </span>

                          <span>
                            Recover until {formatDate(wishlist.recover_until)}
                          </span>

                          <span
                            style={{
                              color:
                                daysRemaining <= 14
                                  ? "#b91c1c"
                                  : "#2563eb",
                              fontWeight: "800",
                            }}
                          >
                            {daysRemaining} {daysRemaining === 1 ? "day" : "days"} remaining
                          </span>
                        </div>

                        <div
                          style={{
                            display: "flex",
                            gap: "8px",
                            flexWrap: "wrap",
                            marginTop: "12px",
                          }}
                        >
                          <span
                            style={{
                              background: "#f8fafc",
                              border:
                                "1px solid #e5e7eb",
                              borderRadius: "999px",
                              padding: "5px 9px",
                              color: "#6b7280",
                              fontSize: "11px",
                              fontWeight: "800",
                            }}
                          >
                            {gifts} {gifts === 1 ? "gift" : "gifts"}
                          </span>

                          <span
                            style={{
                              background: "#f8fafc",
                              border:
                                "1px solid #e5e7eb",
                              borderRadius: "999px",
                              padding: "5px 9px",
                              color: "#6b7280",
                              fontSize: "11px",
                              fontWeight: "800",
                            }}
                          >
                            {reservations} {reservations === 1 ? "reservation" : "reservations"}
                          </span>
                        </div>
                      </div>

                      <div
                        style={{
                          flex: "0 1 280px",
                          width: "100%",
                        }}
                      >
                        {linkedToAccount ? (
                          <div
                            style={{
                              background: "#eff6ff",
                              border:
                                "1px solid #bfdbfe",
                              borderRadius: "11px",
                              padding: "12px 13px",
                              color: "#1e40af",
                              fontSize: "12px",
                              lineHeight: "1.55",
                            }}
                          >
                            This wishlist was archived with a deleted account. Restore the account above to restore its eligible wishlists together.
                          </div>
                        ) : ownerUser ? (
                          <form
                            action={restoreWishlist}
                          >
                            <input
                              type="hidden"
                              name="archiveId"
                              value={wishlist.id}
                            />

                            <label
                              htmlFor={`wishlist-confirm-${wishlist.id}`}
                              style={{
                                display: "block",
                                fontSize: "11px",
                                fontWeight: "800",
                                color: "#6b7280",
                                marginBottom: "6px",
                              }}
                            >
                              Type RESTORE to confirm
                            </label>

                            <input
                              id={`wishlist-confirm-${wishlist.id}`}
                              name="confirmation"
                              placeholder="RESTORE"
                              autoComplete="off"
                              style={{
                                width: "100%",
                                boxSizing: "border-box",
                                border:
                                  "1px solid #bfdbfe",
                                borderRadius: "9px",
                                padding: "10px 11px",
                                fontSize: "13px",
                                outline: "none",
                                marginBottom: "8px",
                              }}
                            />

                            <button
                              type="submit"
                              style={{
                                width: "100%",
                                background: "#2563eb",
                                color: "#ffffff",
                                border: "none",
                                borderRadius: "9px",
                                padding: "11px 12px",
                                fontSize: "13px",
                                fontWeight: "800",
                                cursor: "pointer",
                              }}
                            >
                              Restore Wishlist
                            </button>
                          </form>
                        ) : (
                          <div
                            style={{
                              background: "#fff7ed",
                              border:
                                "1px solid #fed7aa",
                              borderRadius: "11px",
                              padding: "12px 13px",
                              color: "#9a3412",
                              fontSize: "12px",
                              lineHeight: "1.55",
                            }}
                          >
                            The original owner account is not active, so this wishlist cannot be restored by itself yet.
                          </div>
                        )}
                      </div>
                    </div>
                  </article>
                );
              }
            )}
          </div>
        )}

        <div
          style={{
            marginTop: "28px",
            padding: "15px 17px",
            background: "#ffffff",
            border:
              "1px solid #e5e7eb",
            borderRadius: "13px",
            color: "#6b7280",
            fontSize: "12px",
            lineHeight: "1.6",
          }}
        >
          Restoring a wishlist tries to reuse its original public slug. If that slug has already been taken, the restore function assigns a new available slug automatically. Restore actions are recorded in the Admin Activity Log.
        </div>
      </section>
    </main>
  );
}
