import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import SiteFooter from "../components/SiteFooter";
import SupportWidget from "../components/SupportWidget";
import { getSiteUrl } from "../lib/site";


export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export const metadata: Metadata = {
  metadataBase: new URL(getSiteUrl()),

  title: {
    default: "GoWishlist",
    template: "%s | GoWishlist",
  },

  description:
    "Create and share wishlists with friends and family using GoWishlist.",

  icons: {
    icon: [
      {
        url: "/favicon.ico",
      },
      {
        url: "/favicon-16x16.png",
        sizes: "16x16",
        type: "image/png",
      },
      {
        url: "/favicon-32x32.png",
        sizes: "32x32",
        type: "image/png",
      },
    ],

    apple: [
      {
        url: "/apple-touch-icon.png",
        sizes: "180x180",
        type: "image/png",
      },
    ],
  },

  manifest: "/site.webmanifest",

  openGraph: {
    type: "website",
    siteName: "GoWishlist",
    title: "GoWishlist",
    description:
      "Create and share wishlists with friends and family using GoWishlist.",
  },

  twitter: {
    card: "summary",
    title: "GoWishlist",
    description:
      "Create and share wishlists with friends and family using GoWishlist.",
  },
};

export default function RootLayout({
  children,
}: {
  children: ReactNode;
}) {
  return (
    <html lang="en">
      <body
        style={{
          margin: 0,
          fontFamily:
            '-apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif',
          background: "#ffffff",
          color: "#111827",
        }}
      >
        <div
          style={{
            minHeight: "100vh",
            display: "flex",
            flexDirection: "column",
          }}
        >
          <div
            style={{
              flex: 1,
            }}
          >
            {children}
          </div>

          <SiteFooter />
        </div>

        <SupportWidget />
      </body>
    </html>
  );
}
