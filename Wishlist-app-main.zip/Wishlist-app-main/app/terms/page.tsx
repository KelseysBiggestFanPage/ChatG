import type { ReactNode } from "react";
import Link from "next/link";
import GoWishlistLogo from "../../components/GoWishlistLogo";

export const metadata = {
  title: "Terms of Service | GoWishlist",
  description:
    "Terms governing your use of GoWishlist.",
};

export default function TermsPage() {
  return (
    <main
      style={{
        minHeight: "100vh",
        background: "#f8fafc",
        color: "#111827",
      }}
    >
      <header
        style={{
          background: "#ffffff",
          borderBottom: "1px solid #e5e7eb",
        }}
      >
        <div
          style={{
            maxWidth: "900px",
            margin: "0 auto",
            padding: "20px 30px",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            gap: "20px",
          }}
        >
          <GoWishlistLogo href="/home" size={29} />

          <Link
            href="/home"
            style={{
              color: "#6b7280",
              textDecoration: "none",
              fontSize: "14px",
              fontWeight: "700",
            }}
          >
            Back to Home
          </Link>
        </div>
      </header>

      <section
        style={{
          maxWidth: "820px",
          margin: "0 auto",
          padding: "60px 30px 90px",
        }}
      >
        <div style={{ marginBottom: "35px" }}>
          <div
            style={{
              color: "#2563eb",
              fontSize: "13px",
              fontWeight: "800",
              letterSpacing: "0.5px",
              marginBottom: "10px",
            }}
          >
            GOWISHLIST
          </div>

          <h1
            style={{
              margin: 0,
              fontSize: "42px",
              lineHeight: "1.1",
              letterSpacing: "-1.7px",
              fontWeight: "800",
            }}
          >
            Terms of Service
          </h1>

          <p
            style={{
              color: "#6b7280",
              fontSize: "14px",
              margin: "12px 0 0",
            }}
          >
            Effective October 5, 2026
          </p>
        </div>

        <div
          style={{
            background: "#ffffff",
            border: "1px solid #e5e7eb",
            borderRadius: "20px",
            padding: "36px",
            boxShadow: "0 15px 40px rgba(0,0,0,0.04)",
          }}
        >
          <Section title="1. Agreement to These Terms">
            <p style={paragraphStyle}>
              These Terms of Service govern your access to and use of
              GoWishlist, including our website, accounts, wishlists,
              reservation features, receipt and tracking features, and related
              services.
            </p>

            <p style={paragraphStyle}>
              By creating an account, signing in, creating or accessing a
              wishlist, reserving a gift, or otherwise using GoWishlist, you
              agree to these Terms of Service and acknowledge our Privacy
              Policy.
            </p>

            <p style={paragraphStyle}>
              If you do not agree to these Terms, you should not use
              GoWishlist.
            </p>
          </Section>

          <Section title="2. Privacy">
            <p style={paragraphStyle}>
              Your use of GoWishlist is also subject to our Privacy Policy,
              which explains how information may be collected, used, shared,
              and protected.
            </p>

            <Link href="/privacy" style={linkStyle}>
              Read the GoWishlist Privacy Policy
            </Link>
          </Section>

          <Section title="3. Eligibility">
            <p style={paragraphStyle}>
              You may use GoWishlist only if you are legally permitted to enter
              into these Terms in your jurisdiction.
            </p>

            <p style={paragraphStyle}>
              GoWishlist is not intended to be used independently by children
              under 13 to create accounts or submit personal information without
              the involvement of a parent or legal guardian.
            </p>

            <p style={paragraphStyle}>
              If you are using GoWishlist on behalf of another person,
              organization, or business, you represent that you have authority
              to do so.
            </p>
          </Section>

          <Section title="4. Accounts">
            <p style={paragraphStyle}>
              Certain GoWishlist features require an account. You are
              responsible for maintaining the accuracy of your account
              information and for protecting access to your account.
            </p>

            <p style={paragraphStyle}>
              You are responsible for activity performed through your account
              unless prohibited by applicable law.
            </p>

            <p style={paragraphStyle}>
              You may not impersonate another person, create an account using
              misleading information, or use another person&apos;s account
              without permission.
            </p>
          </Section>

          <Section title="5. Google Sign-In">
            <p style={paragraphStyle}>
              GoWishlist may offer Google Sign-In as an account authentication
              option.
            </p>

            <p style={paragraphStyle}>
              Your use of Google services is also subject to Google&apos;s
              applicable terms, policies, and account settings.
            </p>

            <p style={paragraphStyle}>
              GoWishlist is not responsible for interruptions, restrictions, or
              changes made by Google to its authentication services.
            </p>
          </Section>

          <Section title="6. Creating and Sharing Wishlists">
            <p style={paragraphStyle}>
              GoWishlist allows users to create, manage, and share wishlists
              with other people.
            </p>

            <p style={paragraphStyle}>
              You are responsible for the information you place on your
              wishlist, including gift names, descriptions, images,
              instructions, store links, shipping information, and other
              content.
            </p>

            <p style={paragraphStyle}>
              A public wishlist may be accessible to anyone who has its link.
            </p>

            <p style={paragraphStyle}>
              GoWishlist may also allow a wishlist owner to protect a wishlist
              using an access code. Access codes are an additional privacy
              feature but are not a guarantee that information will never be
              accessed by an unauthorized person.
            </p>

            <p style={paragraphStyle}>
              You should not place passwords, financial account information,
              government identification numbers, or other highly sensitive
              information in a wishlist.
            </p>
          </Section>

          <Section title="7. Gift Reservations">
            <p style={paragraphStyle}>
              Guests may be able to reserve gifts listed on a wishlist without
              creating a GoWishlist account.
            </p>

            <p style={paragraphStyle}>
              A reservation indicates that a user intends to purchase or
              otherwise handle a gift. It does not guarantee that the gift will
              actually be purchased, delivered, returned, exchanged, or
              received.
            </p>

            <p style={paragraphStyle}>
              GoWishlist is not a party to a gift purchase between a guest and
              a retailer or between a guest and a wishlist owner.
            </p>

            <p style={paragraphStyle}>
              Wishlist owners may remove a reservation, making the gift
              available to other guests again. Guests who want to cancel a
              reservation must contact the wishlist owner; guests cannot
              unreserve gifts themselves.
            </p>
          </Section>

          <Section title="8. Reservation Contact Information">
            <p style={paragraphStyle}>
              When reserving a gift, a guest may be asked to provide a name and
              an email address, phone number, or both.
            </p>

            <p style={paragraphStyle}>
              This information may be made available to the wishlist owner in
              connection with the reservation.
            </p>

            <p style={paragraphStyle}>
              You agree to provide information that is accurate and that you are
              authorized to provide.
            </p>
          </Section>

          <Section title="9. Receipt, Order, and Tracking Information">
            <p style={paragraphStyle}>
              GoWishlist may allow a person who reserved a gift to provide a
              tracking number, retailer or order link, and receipt link.
            </p>

            <p style={paragraphStyle}>
              You are responsible for ensuring that any information or links you
              submit are accurate and that you have permission to provide them.
            </p>

            <p style={paragraphStyle}>
              Do not submit links that contain passwords, payment card
              information, banking credentials, or other information you do not
              intend to make available through the wishlist service.
            </p>
          </Section>

          <Section title="10. Retailers and Third-Party Websites">
            <p style={paragraphStyle}>
              GoWishlist may contain links to Amazon and other retailers,
              merchants, websites, or services operated by third parties.
            </p>

            <p style={paragraphStyle}>
              GoWishlist does not control those third parties and is not
              responsible for their products, services, prices, availability,
              shipping, returns, refunds, security, content, or privacy
              practices.
            </p>

            <p style={paragraphStyle}>
              Clicking a retailer or third-party link may take you away from
              GoWishlist.
            </p>

            <p style={paragraphStyle}>
              Any purchase or transaction you complete with a retailer is
              between you and that retailer.
            </p>
          </Section>

          <Section title="11. Prices and Product Information">
            <p style={paragraphStyle}>
              Prices, product names, images, descriptions, and availability
              displayed through GoWishlist may come from users or third-party
              websites.
            </p>

            <p style={paragraphStyle}>
              Product information may become outdated, incomplete, or
              inaccurate.
            </p>

            <p style={paragraphStyle}>
              GoWishlist does not guarantee that a displayed price, image,
              description, product, or retailer link is accurate or currently
              available.
            </p>
          </Section>

          <Section title="12. Affiliate Links and Commissions">
            <p style={paragraphStyle}>
              Some retailer links on GoWishlist may be affiliate or referral
              links. If you follow a qualifying link and make a purchase or take
              another qualifying action, GoWishlist may receive a commission or
              referral fee at no additional cost to you.
            </p>

            <p style={paragraphStyle}>
              GoWishlist may participate in the Amazon Associates Program and
              other retailer or affiliate-network programs.
            </p>

            <p style={paragraphStyle}>
              As an Amazon Associate I earn from qualifying purchases.
            </p>
          </Section>

          <Section title="13. Affiliate Links Do Not Mean Endorsement">
            <p style={paragraphStyle}>
              The presence of a product, retailer, affiliate link, or service on
              GoWishlist does not mean that GoWishlist endorses, guarantees, or
              recommends that product, retailer, or service.
            </p>

            <p style={paragraphStyle}>
              You are responsible for evaluating any product, retailer, service,
              or offer before purchasing or relying on it.
            </p>
          </Section>

          <Section title="14. Personal Information and Affiliate Referrals">
            <p style={paragraphStyle}>
              GoWishlist does not sell personal information to third parties in
              exchange for money.
            </p>

            <p style={paragraphStyle}>
              When you click an affiliate or referral link, the destination
              retailer or affiliate partner may receive information associated
              with that click as described in our Privacy Policy.
            </p>

            <Link href="/privacy" style={linkStyle}>
              Learn more in our Privacy Policy
            </Link>
          </Section>

          <Section title="15. Your Content">
            <p style={paragraphStyle}>
              You retain any rights you may have in content you submit to
              GoWishlist.
            </p>

            <p style={paragraphStyle}>
              By submitting content, you give GoWishlist a non-exclusive,
              worldwide license to host, store, reproduce, display, process, and
              transmit that content as reasonably necessary to operate, provide,
              secure, and improve the service.
            </p>

            <p style={paragraphStyle}>
              This permission does not transfer ownership of your content to
              GoWishlist.
            </p>
          </Section>

          <Section title="16. Your Responsibilities">
            <p style={paragraphStyle}>
              You are responsible for your use of GoWishlist and for content or
              information you submit.
            </p>

            <p style={paragraphStyle}>
              You agree that you will not use GoWishlist to submit or distribute
              content that you do not have the right to use or that violates
              applicable law or the rights of another person.
            </p>
          </Section>

          <Section title="17. Prohibited Uses">
            <p style={paragraphStyle}>You may not use GoWishlist to:</p>

            <ul style={listStyle}>
              <li>Violate applicable laws or regulations.</li>
              <li>Harass, threaten, defraud, or impersonate another person.</li>
              <li>
                Submit unlawful, abusive, malicious, or intentionally deceptive
                content.
              </li>
              <li>
                Introduce malware, malicious scripts, harmful code, or other
                security threats.
              </li>
              <li>
                Attempt to gain unauthorized access to accounts, wishlists,
                databases, servers, or other systems.
              </li>
              <li>
                Attempt to discover another person&apos;s wishlist access code
                through automated or abusive methods.
              </li>
              <li>
                Scrape, crawl, copy, or extract information from GoWishlist
                using automated systems in a way that interferes with or burdens
                the service.
              </li>
              <li>
                Circumvent security measures, access restrictions, rate limits,
                or authentication controls.
              </li>
              <li>Use GoWishlist to distribute spam, phishing, or fraud.</li>
              <li>Interfere with the operation or availability of GoWishlist.</li>
            </ul>
          </Section>

          <Section title="18. Intellectual Property">
            <p style={paragraphStyle}>
              GoWishlist, including its software, design, branding, logos,
              interfaces, and original content provided by GoWishlist, may be
              protected by copyright, trademark, and other intellectual property
              laws.
            </p>

            <p style={paragraphStyle}>
              These Terms do not grant you ownership of GoWishlist or its
              intellectual property.
            </p>
          </Section>

          <Section title="19. Service Availability">
            <p style={paragraphStyle}>
              We work to keep GoWishlist available, but we do not guarantee
              uninterrupted or error-free operation.
            </p>

            <p style={paragraphStyle}>
              The service may occasionally become unavailable because of
              maintenance, software changes, third-party service interruptions,
              security issues, technical problems, or circumstances outside our
              control.
            </p>
          </Section>

          <Section title="20. Changes to GoWishlist">
            <p style={paragraphStyle}>
              We may add, remove, modify, discontinue, or redesign features of
              GoWishlist from time to time.
            </p>

            <p style={paragraphStyle}>
              Features available today may not remain available permanently,
              and new features may be subject to additional terms or
              requirements.
            </p>
          </Section>

          <Section title="21. Account Suspension or Termination">
            <p style={paragraphStyle}>
              We may restrict, suspend, or terminate access to GoWishlist when
              reasonably necessary to protect the service, other users, or third
              parties; address suspected fraud, abuse, or security concerns;
              comply with legal obligations; or enforce these Terms.
            </p>

            <p style={paragraphStyle}>
              Where appropriate, we may also remove content that violates these
              Terms or applicable law.
            </p>
          </Section>

          <Section title="22. User-Requested Deletion">
            <p style={paragraphStyle}>
              GoWishlist may provide features that allow users to delete
              wishlists, account information, or other content.
            </p>

            <p style={paragraphStyle}>
              Some information may remain for a limited period in backups,
              security records, fraud-prevention systems, or other records where
              retention is reasonably necessary or legally required.
            </p>
          </Section>

          <Section title="23. No Guarantee of Gift Purchases or Delivery">
            <p style={paragraphStyle}>
              GoWishlist does not guarantee that any gift listed on a wishlist
              will be purchased.
            </p>

            <p style={paragraphStyle}>
              We also do not guarantee that a reserved gift will be purchased,
              shipped, delivered, received, or provided in the condition
              expected by the wishlist owner.
            </p>

            <p style={paragraphStyle}>
              GoWishlist is a wishlist and reservation service and is not the
              seller, shipper, purchaser, or recipient of products linked
              through the service.
            </p>
          </Section>

          <Section title="24. Disclaimers">
            <p style={paragraphStyle}>
              To the extent permitted by applicable law, GoWishlist is provided
              on an &quot;as is&quot; and &quot;as available&quot; basis.
            </p>

            <p style={paragraphStyle}>
              We do not guarantee that the service will always be available,
              secure, accurate, complete, or free of errors.
            </p>

            <p style={paragraphStyle}>
              We do not guarantee third-party products, retailers, links,
              affiliate programs, shipping services, or information submitted by
              users.
            </p>
          </Section>

          <Section title="25. Limitation of Liability">
            <p style={paragraphStyle}>
              To the maximum extent permitted by applicable law, GoWishlist and
              those involved in providing the service will not be liable for
              indirect, incidental, special, consequential, exemplary, or
              punitive damages arising from or relating to your use of or
              inability to use the service.
            </p>

            <p style={paragraphStyle}>
              This includes, where permitted by law, losses arising from user
              content, gift reservations, third-party retailers, external or
              affiliate links, lost access codes, delivery problems, or service
              interruptions.
            </p>

            <p style={paragraphStyle}>
              Some jurisdictions do not allow certain limitations of liability,
              so some of these limitations may not apply to you.
            </p>
          </Section>

          <Section title="26. Third-Party Services">
            <p style={paragraphStyle}>
              GoWishlist depends on services provided by third parties, which
              may include hosting, authentication, databases, analytics,
              communications, affiliate programs, and other infrastructure.
            </p>

            <p style={paragraphStyle}>
              We are not responsible for actions, outages, policy changes, or
              failures caused by independent third-party services outside our
              reasonable control.
            </p>
          </Section>

          <Section title="27. Changes to These Terms">
            <p style={paragraphStyle}>
              We may update these Terms from time to time to reflect changes to
              GoWishlist, our business, our technology, or applicable legal
              requirements.
            </p>

            <p style={paragraphStyle}>
              When these Terms are updated, the effective date shown at the top
              of this page may also be updated.
            </p>

            <p style={paragraphStyle}>
              Your continued use of GoWishlist after revised Terms become
              effective constitutes acceptance of the revised Terms to the extent
              permitted by applicable law.
            </p>
          </Section>

          <Section title="28. Entire Agreement">
            <p style={paragraphStyle}>
              These Terms, together with the Privacy Policy and any additional
              terms presented for a specific feature, form the agreement
              governing your use of GoWishlist.
            </p>

            <p style={paragraphStyle}>
              If any provision of these Terms is found unenforceable, the
              remaining provisions will continue in effect to the extent
              permitted by law.
            </p>
          </Section>

          <Section title="29. Contact">
            <p
              style={{
                ...paragraphStyle,
                marginBottom: 0,
              }}
            >
              Questions about these Terms may be submitted through the contact
              or support options made available by GoWishlist.
            </p>
          </Section>
        </div>
      </section>
    </main>
  );
}

function Section({
  title,
  children,
}: {
  title: string;
  children: ReactNode;
}) {
  return (
    <section
      style={{
        marginBottom: "34px",
      }}
    >
      <h2
        style={{
          margin: "0 0 13px",
          fontSize: "20px",
          lineHeight: "1.3",
          fontWeight: "800",
          letterSpacing: "-0.4px",
        }}
      >
        {title}
      </h2>

      {children}
    </section>
  );
}

const paragraphStyle = {
  color: "#4b5563",
  fontSize: "14px",
  lineHeight: "1.75",
  margin: "0 0 14px",
};

const listStyle = {
  color: "#4b5563",
  fontSize: "14px",
  lineHeight: "1.75",
  paddingLeft: "22px",
  margin: "0 0 14px",
};

const linkStyle = {
  display: "inline-block",
  color: "#2563eb",
  fontSize: "14px",
  fontWeight: "800",
  textDecoration: "none",
  marginBottom: "14px",
};
