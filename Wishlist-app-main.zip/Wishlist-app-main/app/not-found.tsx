import Link from "next/link";
import GoWishlistLogo from "../components/GoWishlistLogo";

export default function NotFound() {
  return (
    <main
      style={{
        minHeight: "100vh",
        background: "#ffffff",
        color: "#111827",
        fontFamily:
          '-apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif',
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "30px",
        textAlign: "center",
      }}
    >
      <div
        style={{
          width: "100%",
          maxWidth: "650px",
        }}
      >
        <div
          style={{
            marginBottom: "28px",
          }}
        >
          <GoWishlistLogo
            href="/home"
            size={30}
          />
        </div>

        <div
          style={{
            color: "#2563eb",
            fontSize: "15px",
            fontWeight: "800",
            letterSpacing: "1px",
            marginBottom: "16px",
          }}
        >
          ERROR 101
        </div>

        <h1
          style={{
            margin: 0,
            fontSize: "52px",
            lineHeight: "1.08",
            letterSpacing: "-2.5px",
            fontWeight: "800",
          }}
        >
          This page doesn&apos;t exist.
        </h1>

        <p
          style={{
            color: "#6b7280",
            fontSize: "18px",
            lineHeight: "1.6",
            margin: "20px auto 32px",
            maxWidth: "520px",
          }}
        >
          The link may be incorrect, expired, or the page may have been moved.
        </p>

        <Link
          href="/home"
          style={{
            display: "inline-block",
            background: "#2563eb",
            color: "#ffffff",
            padding: "14px 24px",
            borderRadius: "11px",
            fontSize: "16px",
            fontWeight: "700",
            textDecoration: "none",
            boxShadow: "0 10px 30px rgba(37,99,235,0.18)",
          }}
        >
          Back to GoWishlist
        </Link>
      </div>
    </main>
  );
}
