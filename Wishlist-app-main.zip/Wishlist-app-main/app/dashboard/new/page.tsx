import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "../../../lib/supabase/server";
import NewWishlistForm from "../../../components/NewWishlistForm";
import GoWishlistLogo from "../../../components/GoWishlistLogo";

export default async function NewWishlistPage() {
  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/login");
  }

  return (
    <main
      style={{
        minHeight: "100vh",
        background: "#f8fafc",
        color: "#111827",
      }}
    >
      <header
        style={{
          background: "#ffffff",
          borderBottom: "1px solid #e5e7eb",
        }}
      >
        <div
          style={{
            maxWidth: "1100px",
            margin: "0 auto",
            padding: "20px 30px",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            gap: "20px",
          }}
        >
          <GoWishlistLogo
            href="/dashboard"
            size={29}
          />

          <Link
            href="/dashboard"
            style={{
              color: "#6b7280",
              textDecoration: "none",
              fontWeight: "700",
              fontSize: "14px",
            }}
          >
            Back to Dashboard
          </Link>
        </div>
      </header>

      <section
        style={{
          maxWidth: "650px",
          margin: "0 auto",
          padding: "60px 30px",
        }}
      >
        <div
          style={{
            marginBottom: "30px",
          }}
        >
          <h1
            style={{
              margin: 0,
              fontSize: "38px",
              fontWeight: "800",
              letterSpacing: "-1.5px",
            }}
          >
            Create a wishlist
          </h1>

          <p
            style={{
              color: "#6b7280",
              fontSize: "16px",
              lineHeight: "1.6",
              marginTop: "10px",
              marginBottom: 0,
            }}
          >
            Give your wishlist a name and choose your share link.
          </p>
        </div>

        <NewWishlistForm />
      </section>
    </main>
  );
}
