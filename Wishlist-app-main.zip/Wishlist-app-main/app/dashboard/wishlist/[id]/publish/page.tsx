import { randomBytes, scryptSync } from "crypto";
import Link from "next/link";
import { revalidatePath } from "next/cache";
import { notFound, redirect } from "next/navigation";
import AccessCodeSettings from "../../../../../components/AccessCodeSettings";
import CopyWishlistLinkButton from "../../../../../components/CopyWishlistLinkButton";
import GoWishlistLogo from "../../../../../components/GoWishlistLogo";
import { getWishlistUrl } from "../../../../../lib/site";
import { createAdminClient } from "../../../../../lib/supabase/admin";
import { createClient } from "../../../../../lib/supabase/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function hashAccessCode(code: string) {
  const salt = randomBytes(16);
  const hash = scryptSync(code, salt, 64);

  return `scrypt$${salt.toString("hex")}$${hash.toString("hex")}`;
}

export default async function PublishWishlistPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{
    error?: string;
    saved?: string;
  }>;
}) {
  const { id } = await params;
  const query = await searchParams;

  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/login");
  }

  const { data: wishlist, error } = await supabase
    .from("wishlists")
    .select(
      "id, title, slug, is_live, access_code_hash, owner_contact_email, owner_contact_phone"
    )
    .eq("id", id)
    .eq("owner_id", user.id)
    .single();

  if (error || !wishlist) {
    notFound();
  }

  async function saveSettings(formData: FormData) {
    "use server";

    const supabase = await createClient();

    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      redirect("/login");
    }

    const { data: currentWishlist } = await supabase
      .from("wishlists")
      .select("id, access_code_hash")
      .eq("id", id)
      .eq("owner_id", user.id)
      .single();

    if (!currentWishlist) {
      notFound();
    }

    const email = String(
      formData.get("email") || ""
    ).trim();

    const phone = String(
      formData.get("phone") || ""
    ).trim();

    const accessMode = String(
      formData.get("accessMode") || "off"
    );

    const newAccessCode = String(
      formData.get("newAccessCode") || ""
    )
      .replace(/\D/g, "")
      .slice(0, 8);

    if (!email && !phone) {
      redirect(
        `/dashboard/wishlist/${id}/publish?error=contact`
      );
    }

    if (
      email &&
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
    ) {
      redirect(
        `/dashboard/wishlist/${id}/publish?error=email`
      );
    }

    if (
      phone &&
      !/^[0-9+()\-\s.]{7,25}$/.test(phone)
    ) {
      redirect(
        `/dashboard/wishlist/${id}/publish?error=phone`
      );
    }

    let accessCodeHash =
      currentWishlist.access_code_hash;

    if (accessMode === "off") {
      accessCodeHash = null;
    }

    if (accessMode === "change") {
      if (!/^[0-9]{4,8}$/.test(newAccessCode)) {
        redirect(
          `/dashboard/wishlist/${id}/publish?error=code`
        );
      }

      accessCodeHash =
        hashAccessCode(newAccessCode);
    }

    const { error: updateError } =
      await supabase
        .from("wishlists")
        .update({
          owner_contact_email:
            email || null,
          owner_contact_phone:
            phone || null,
          access_code_hash:
            accessCodeHash,
          is_live: true,
          updated_at:
            new Date().toISOString(),
        })
        .eq("id", id)
        .eq("owner_id", user.id);

    if (updateError) {
      console.error(
        "Wishlist settings error:",
        updateError
      );

      redirect(
        `/dashboard/wishlist/${id}/publish?error=save`
      );
    }

    revalidatePath(
      `/dashboard/wishlist/${id}`
    );

    redirect(
      `/dashboard/wishlist/${id}`
    );
  }

  async function takeWishlistOffline() {
    "use server";

    const supabase = await createClient();

    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      redirect("/login");
    }

    const { data: currentWishlist } =
      await supabase
        .from("wishlists")
        .select("id, slug")
        .eq("id", id)
        .eq("owner_id", user.id)
        .single();

    if (!currentWishlist) {
      notFound();
    }

    const { error: updateError } =
      await supabase
        .from("wishlists")
        .update({
          is_live: false,
          updated_at:
            new Date().toISOString(),
        })
        .eq("id", currentWishlist.id)
        .eq("owner_id", user.id);

    if (updateError) {
      console.error(
        "Take wishlist offline error:",
        updateError
      );

      redirect(
        `/dashboard/wishlist/${id}/publish?error=save`
      );
    }

    revalidatePath(
      `/dashboard/wishlist/${currentWishlist.id}`
    );

    revalidatePath(
      `/dashboard/wishlist/${currentWishlist.id}/publish`
    );

    revalidatePath(
      `/wishlist/${currentWishlist.slug}`
    );

    redirect(
      `/dashboard/wishlist/${currentWishlist.id}`
    );
  }

  async function deleteWishlist(
    formData: FormData
  ) {
    "use server";

    const confirmation = String(
      formData.get("confirmation") || ""
    ).trim();

    if (confirmation !== "DELETE") {
      redirect(
        `/dashboard/wishlist/${id}/publish?error=delete-confirm`
      );
    }

    const supabase = await createClient();

    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      redirect("/login");
    }

    const { data: currentWishlist } =
      await supabase
        .from("wishlists")
        .select("id")
        .eq("id", id)
        .eq("owner_id", user.id)
        .maybeSingle();

    if (!currentWishlist) {
      notFound();
    }

    const admin = createAdminClient();

    const {
      error: archiveError,
    } = await admin.rpc(
      "archive_and_delete_wishlist",
      {
        p_wishlist_id: id,
        p_owner_id: user.id,
        p_owner_email:
          user.email || "",
        p_deleted_by: "owner",
      }
    );

    if (archiveError) {
      console.error(
        "Archive wishlist error:",
        archiveError
      );

      redirect(
        `/dashboard/wishlist/${id}/publish?error=delete`
      );
    }

    redirect("/dashboard");
  }

  let errorMessage = "";

  if (query.error === "contact") {
    errorMessage =
      "Enter an email address, phone number, or both.";
  }

  if (query.error === "email") {
    errorMessage =
      "Enter a valid email address.";
  }

  if (query.error === "phone") {
    errorMessage =
      "Enter a valid phone number.";
  }

  if (query.error === "code") {
    errorMessage =
      "Your access code must be 4–8 numbers.";
  }

  if (query.error === "save") {
    errorMessage =
      "We could not save your wishlist settings.";
  }

  if (
    query.error === "delete-confirm"
  ) {
    errorMessage =
      'Type DELETE exactly to delete this wishlist.';
  }

  if (query.error === "delete") {
    errorMessage =
      "We could not delete this wishlist. Please try again.";
  }

  const defaultEmail =
    wishlist.owner_contact_email ||
    user.email ||
    "";

  const defaultPhone =
    wishlist.owner_contact_phone ||
    "";

  const publicWishlistUrl =
    getWishlistUrl(
      wishlist.slug
    );

  return (
    <main
      style={{
        minHeight: "100vh",
        background: "#f8fafc",
        color: "#111827",
      }}
    >
      <header
        style={{
          background: "#ffffff",
          borderBottom:
            "1px solid #e5e7eb",
        }}
      >
        <div
          style={{
            maxWidth: "900px",
            margin: "0 auto",
            padding: "20px 30px",
            display: "flex",
            justifyContent:
              "space-between",
            alignItems: "center",
            gap: "20px",
          }}
        >
          <GoWishlistLogo
            href="/dashboard"
            size={29}
          />

          <Link
            href={`/dashboard/wishlist/${wishlist.id}`}
            style={{
              color: "#6b7280",
              textDecoration: "none",
              fontWeight: "700",
              fontSize: "14px",
            }}
          >
            Back to Wishlist
          </Link>
        </div>
      </header>

      <section
        style={{
          maxWidth: "650px",
          margin: "0 auto",
          padding: "55px 30px 90px",
        }}
      >
        <div
          style={{
            marginBottom: "28px",
          }}
        >
          <div
            style={{
              color: "#2563eb",
              fontSize: "13px",
              fontWeight: "800",
              marginBottom: "8px",
            }}
          >
            {wishlist.title}
          </div>

          <h1
            style={{
              margin: 0,
              fontSize: "40px",
              lineHeight: "1.1",
              fontWeight: "800",
              letterSpacing: "-1.7px",
            }}
          >
            {wishlist.is_live
              ? "Live Wishlist Settings"
              : "Make Your Wishlist Live"}
          </h1>

          <p
            style={{
              color: "#6b7280",
              fontSize: "15px",
              lineHeight: "1.6",
              marginTop: "12px",
            }}
          >
            Manage the address for this wishlist, guest access, and the contact information guests can use if they need help or want to cancel a reservation.
          </p>
        </div>

        {query.saved === "1" && (
          <div
            style={{
              background: "#f0fdf4",
              border:
                "1px solid #bbf7d0",
              color: "#166534",
              borderRadius: "12px",
              padding: "14px",
              fontSize: "14px",
              fontWeight: "700",
              marginBottom: "20px",
            }}
          >
            Wishlist settings saved.
          </div>
        )}

        {errorMessage && (
          <div
            style={{
              background: "#fef2f2",
              border:
                "1px solid #fecaca",
              color: "#b91c1c",
              borderRadius: "12px",
              padding: "14px",
              fontSize: "14px",
              fontWeight: "700",
              lineHeight: "1.5",
              marginBottom: "20px",
            }}
          >
            {errorMessage}
          </div>
        )}

        <form
          action={saveSettings}
          style={{
            background: "#ffffff",
            border:
              "1px solid #e5e7eb",
            borderRadius: "20px",
            padding: "30px",
            boxShadow:
              "0 15px 40px rgba(0,0,0,0.06)",
          }}
        >
          <div
            style={{
              background: "#eff6ff",
              border:
                "1px solid #bfdbfe",
              borderRadius: "13px",
              padding: "16px",
              marginBottom: "26px",
            }}
          >
            <div
              style={{
                color: "#2563eb",
                fontSize: "12px",
                fontWeight: "800",
                marginBottom: "6px",
              }}
            >
              WISHLIST LINK
            </div>

            <a
              href={publicWishlistUrl}
              target="_blank"
              rel="noreferrer"
              style={{
                color: "#111827",
                fontWeight: "800",
                wordBreak: "break-all",
                textDecoration: "none",
              }}
            >
              {publicWishlistUrl}
            </a>
            <div style={{ marginTop: "12px" }}>
              <CopyWishlistLinkButton url={publicWishlistUrl} />
            </div>
          </div>

          <label
            htmlFor="email"
            style={{
              display: "block",
              fontSize: "14px",
              fontWeight: "800",
              marginBottom: "8px",
            }}
          >
            Contact Email
          </label>

          <input
            id="email"
            name="email"
            type="email"
            defaultValue={defaultEmail}
            placeholder="you@example.com"
            autoComplete="email"
            style={{
              width: "100%",
              boxSizing: "border-box",
              border:
                "1px solid #d1d5db",
              borderRadius: "11px",
              padding: "14px 16px",
              fontSize: "16px",
              outline: "none",
              marginBottom: "22px",
            }}
          />

          <label
            htmlFor="phone"
            style={{
              display: "block",
              fontSize: "14px",
              fontWeight: "800",
              marginBottom: "8px",
            }}
          >
            Contact Phone
          </label>

          <input
            id="phone"
            name="phone"
            type="tel"
            defaultValue={defaultPhone}
            placeholder="(555) 555-5555"
            autoComplete="tel"
            style={{
              width: "100%",
              boxSizing: "border-box",
              border:
                "1px solid #d1d5db",
              borderRadius: "11px",
              padding: "14px 16px",
              fontSize: "16px",
              outline: "none",
              marginBottom: "28px",
            }}
          />

          <AccessCodeSettings
            hasAccessCode={Boolean(
              wishlist.access_code_hash
            )}
          />

          <button
            type="submit"
            style={{
              width: "100%",
              background: "#2563eb",
              color: "#ffffff",
              border: "none",
              borderRadius: "11px",
              padding: "15px 18px",
              fontSize: "16px",
              fontWeight: "800",
              cursor: "pointer",
              marginTop: "22px",
            }}
          >
            {wishlist.is_live
              ? "Save Live Settings"
              : "Make Wishlist Live"}
          </button>
        </form>

        {wishlist.is_live && (
          <>
            <Link
              href={`/wishlist/${wishlist.slug}`}
              style={{
                display: "block",
                width: "100%",
                boxSizing: "border-box",
                textAlign: "center",
                background: "#ffffff",
                color: "#2563eb",
                border:
                  "1px solid #2563eb",
                borderRadius: "11px",
                padding: "14px 18px",
                fontSize: "15px",
                fontWeight: "800",
                textDecoration: "none",
                marginTop: "14px",
              }}
            >
              View Live Wishlist
            </Link>

            <div
              style={{
                background: "#ffffff",
                border:
                  "1px solid #e5e7eb",
                borderRadius: "20px",
                padding: "30px",
                marginTop: "35px",
              }}
            >
              <h2
                style={{
                  margin: "0 0 8px",
                  fontSize: "20px",
                  fontWeight: "800",
                }}
              >
                Take Wishlist Offline
              </h2>

              <p
                style={{
                  color: "#6b7280",
                  fontSize: "14px",
                  lineHeight: "1.6",
                  margin: "0 0 18px",
                }}
              >
                Guests will no longer be able
                to view or reserve gifts from
                this wishlist. Your gifts,
                reservations, access code, and
                settings will stay saved.
              </p>

              <form
                action={
                  takeWishlistOffline
                }
              >
                <button
                  type="submit"
                  style={{
                    width: "100%",
                    background: "#ffffff",
                    color: "#111827",
                    border:
                      "1px solid #d1d5db",
                    borderRadius: "11px",
                    padding: "14px 18px",
                    fontSize: "15px",
                    fontWeight: "800",
                    cursor: "pointer",
                  }}
                >
                  Take Wishlist Offline
                </button>
              </form>
            </div>
          </>
        )}

        <div
          style={{
            background: "#ffffff",
            border:
              "1px solid #fecaca",
            borderRadius: "20px",
            padding: "30px",
            marginTop: "35px",
          }}
        >
          <h2
            style={{
              margin: "0 0 8px",
              color: "#991b1b",
              fontSize: "20px",
              fontWeight: "800",
            }}
          >
            Delete Wishlist
          </h2>

          <p
            style={{
              color: "#6b7280",
              fontSize: "14px",
              lineHeight: "1.6",
              margin: "0 0 12px",
            }}
          >
            Deleting this wishlist removes
            it from GoWishlist immediately,
            including its gifts and
            reservations.
          </p>

          <div
            style={{
              background: "#fef2f2",
              border:
                "1px solid #fecaca",
              borderRadius: "11px",
              padding: "13px 14px",
              color: "#991b1b",
              fontSize: "13px",
              lineHeight: "1.55",
              fontWeight: "700",
              marginBottom: "18px",
            }}
          >
            Your wishlist may be recoverable
            through GoWishlist Support for
            up to 90 days. After 90 days, it
            cannot be restored.
          </div>

          <p
            style={{
              color: "#6b7280",
              fontSize: "13px",
              lineHeight: "1.55",
              margin: "0 0 18px",
            }}
          >
            The current wishlist link becomes
            available for someone else to use
            immediately after deletion. If
            this wishlist is later restored
            and the old link has already been
            taken, GoWishlist will assign a
            new available link.
          </p>

          <form action={deleteWishlist}>
            <label
              htmlFor="confirmation"
              style={{
                display: "block",
                fontSize: "13px",
                fontWeight: "800",
                marginBottom: "8px",
              }}
            >
              Type DELETE to confirm
            </label>

            <input
              id="confirmation"
              name="confirmation"
              placeholder="DELETE"
              autoComplete="off"
              style={{
                width: "100%",
                boxSizing: "border-box",
                border:
                  "1px solid #fecaca",
                borderRadius: "11px",
                padding: "14px 16px",
                fontSize: "16px",
                outline: "none",
                marginBottom: "12px",
              }}
            />

            <button
              type="submit"
              style={{
                width: "100%",
                background: "#dc2626",
                color: "#ffffff",
                border: "none",
                borderRadius: "11px",
                padding: "14px 18px",
                fontSize: "15px",
                fontWeight: "800",
                cursor: "pointer",
              }}
            >
              Delete Wishlist
            </button>
          </form>
        </div>
      </section>
    </main>
  );
}
