import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import AddGiftForm from "../../../../../components/AddGiftForm";
import GoWishlistLogo from "../../../../../components/GoWishlistLogo";
import { createClient } from "../../../../../lib/supabase/server";

export default async function AddGiftPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/login");
  }

  const { data: wishlist, error } = await supabase
    .from("wishlists")
    .select("id, title")
    .eq("id", id)
    .eq("owner_id", user.id)
    .single();

  if (error || !wishlist) {
    notFound();
  }

  return (
    <main
      style={{
        minHeight: "100vh",
        background: "#f8fafc",
        color: "#111827",
      }}
    >
      <header
        style={{
          background: "#ffffff",
          borderBottom: "1px solid #e5e7eb",
        }}
      >
        <div
          style={{
            maxWidth: "1100px",
            margin: "0 auto",
            padding: "20px 30px",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            gap: "20px",
          }}
        >
          <GoWishlistLogo
            href="/dashboard"
            size={29}
          />

          <Link
            href={`/dashboard/wishlist/${wishlist.id}`}
            style={{
              color: "#6b7280",
              textDecoration: "none",
              fontWeight: "700",
              fontSize: "14px",
            }}
          >
            Back to Wishlist
          </Link>
        </div>
      </header>

      <section
        style={{
          maxWidth: "700px",
          margin: "0 auto",
          padding: "60px 30px",
        }}
      >
        <div
          style={{
            marginBottom: "30px",
          }}
        >
          <div
            style={{
              color: "#2563eb",
              fontSize: "13px",
              fontWeight: "800",
              marginBottom: "8px",
            }}
          >
            {wishlist.title}
          </div>

          <h1
            style={{
              margin: 0,
              fontSize: "38px",
              fontWeight: "800",
              letterSpacing: "-1.5px",
            }}
          >
            Add a Gift
          </h1>

          <p
            style={{
              color: "#6b7280",
              fontSize: "16px",
              lineHeight: "1.6",
              marginTop: "10px",
              marginBottom: 0,
            }}
          >
            Paste a product link from the store you want and GoWishlist will
            try to find the product name, price, and photos for you.
          </p>
        </div>

        <AddGiftForm wishlistId={wishlist.id} />
      </section>
    </main>
  );
}
