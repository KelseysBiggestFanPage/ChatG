import Link from "next/link";
import { revalidatePath } from "next/cache";
import {
  notFound,
  redirect,
} from "next/navigation";
import GoWishlistLogo from "../../../../../../../components/GoWishlistLogo";
import { createClient } from "../../../../../../../lib/supabase/server";

export const dynamic = "force-dynamic";

function normalizeHttpUrl(value: string) {
  const trimmed = value.trim();

  if (!trimmed) {
    return "";
  }

  if (/^https?:\/\//i.test(trimmed)) {
    return trimmed;
  }

  return `https://${trimmed}`;
}

function isValidHttpUrl(value: string) {
  try {
    const url = new URL(value);

    return (
      url.protocol === "http:" ||
      url.protocol === "https:"
    );
  } catch {
    return false;
  }
}

function isAllowedLocalImagePath(value: string) {
  return /^\/icons\/[A-Za-z0-9._-]+\.(?:png|jpe?g|webp|svg)$/i.test(value);
}

function normalizeImageUrl(value: string) {
  const trimmed = value.trim();
  if (!trimmed) return "";
  if (isAllowedLocalImagePath(trimmed)) return trimmed;
  return normalizeHttpUrl(trimmed);
}

function isValidImageUrl(value: string) {
  return isAllowedLocalImagePath(value) || isValidHttpUrl(value);
}

export default async function EditGiftPage({
  params,
  searchParams,
}: {
  params: Promise<{
    id: string;
    giftId: string;
  }>;
  searchParams: Promise<{
    error?: string;
  }>;
}) {
  const { id, giftId } = await params;
  const query = await searchParams;

  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/login");
  }

  const { data: wishlist } = await supabase
    .from("wishlists")
    .select("id, title, slug")
    .eq("id", id)
    .eq("owner_id", user.id)
    .single();

  if (!wishlist) {
    notFound();
  }

  const activeWishlist = wishlist;

  const { data: gift } = await supabase
    .from("gifts")
    .select(
      "id, wishlist_id, name, product_url, image_url, price, description, instructions, shipping_address"
    )
    .eq("id", giftId)
    .eq("wishlist_id", activeWishlist.id)
    .eq("owner_id", user.id)
    .single();

  if (!gift) {
    notFound();
  }

  const activeGift = gift;

  async function updateGift(
    formData: FormData
  ) {
    "use server";

    const supabase = await createClient();

    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      redirect("/login");
    }

    const { data: ownedWishlist } =
      await supabase
        .from("wishlists")
        .select("id, slug")
        .eq(
          "id",
          activeWishlist.id
        )
        .eq("owner_id", user.id)
        .single();

    if (!ownedWishlist) {
      notFound();
    }

    const rawProductUrl = String(
      formData.get("productUrl") || ""
    ).trim();

    const productUrl =
      normalizeHttpUrl(rawProductUrl);

    const name = String(
      formData.get("name") || ""
    ).trim();

    const rawImageUrl = String(
      formData.get("imageUrl") || ""
    ).trim();

    const imageUrl = rawImageUrl
      ? normalizeImageUrl(rawImageUrl)
      : "";

    const priceValue = String(
      formData.get("price") || ""
    ).trim();

    const description = String(
      formData.get("description") || ""
    )
      .trim()
      .slice(0, 1000);


    const instructions = String(
      formData.get("instructions") || ""
    )
      .trim()
      .slice(0, 1000);

    const shippingAddress = String(
      formData.get("shippingAddress") || ""
    ).trim();

    const editUrl =
      `/dashboard/wishlist/${activeWishlist.id}/gift/${activeGift.id}/edit`;

    if (
      !productUrl ||
      !isValidHttpUrl(productUrl)
    ) {
      redirect(
        `${editUrl}?error=product`
      );
    }

    if (!name || name.length > 120) {
      redirect(
        `${editUrl}?error=name`
      );
    }

    if (!shippingAddress) {
      redirect(`${editUrl}?error=address`);
    }

    if (shippingAddress.length > 500) {
      redirect(`${editUrl}?error=address`);
    }

    if (
      imageUrl &&
      !isValidImageUrl(imageUrl)
    ) {
      redirect(
        `${editUrl}?error=image`
      );
    }

    let price: number | null = null;

    if (priceValue) {
      const parsedPrice =
        Number(priceValue);

      if (
        !Number.isFinite(
          parsedPrice
        ) ||
        parsedPrice < 0 ||
        parsedPrice > 99999999.99
      ) {
        redirect(
          `${editUrl}?error=price`
        );
      }

      price =
        Math.round(
          parsedPrice * 100
        ) / 100;
    }

    const { error } = await supabase
      .from("gifts")
      .update({
        name,
        product_url: productUrl,
        image_url:
          imageUrl || null,
        price,
        description:
          description || null,
        instructions:
          instructions || null,
        shipping_address: shippingAddress,
      })
      .eq("id", activeGift.id)
      .eq(
        "wishlist_id",
        ownedWishlist.id
      )
      .eq("owner_id", user.id);

    if (error) {
      console.error(
        "Edit gift error:",
        error
      );

      redirect(
        `${editUrl}?error=save`
      );
    }

    revalidatePath(
      `/dashboard/wishlist/${ownedWishlist.id}`
    );

    revalidatePath(
      `/wishlist/${ownedWishlist.slug}`
    );

    redirect(
      `/dashboard/wishlist/${ownedWishlist.id}`
    );
  }

  let errorMessage = "";

  if (query.error === "product") {
    errorMessage =
      "Enter a valid store link.";
  }

  if (query.error === "name") {
    errorMessage =
      "Enter a Gift Name up to 120 characters.";
  }

  if (query.error === "image") {
    errorMessage =
      "Enter a valid image link.";
  }

  if (query.error === "price") {
    errorMessage =
      "Enter a valid price.";
  }

  if (query.error === "address") {
    errorMessage =
      "Shipping address or delivery instructions are required (500 characters or fewer).";
  }

  if (query.error === "save") {
    errorMessage =
      "We could not save this gift. Please try again.";
  }

  return (
    <main
      style={{
        minHeight: "100vh",
        background: "#f8fafc",
        color: "#111827",
      }}
    >
      <header
        style={{
          background: "#ffffff",
          borderBottom:
            "1px solid #e5e7eb",
        }}
      >
        <div
          style={{
            maxWidth: "1100px",
            margin: "0 auto",
            padding: "20px 30px",
            display: "flex",
            alignItems: "center",
            justifyContent:
              "space-between",
            gap: "20px",
          }}
        >
          <GoWishlistLogo
            href="/dashboard"
            size={29}
          />

          <Link
            href={`/dashboard/wishlist/${activeWishlist.id}`}
            style={{
              color: "#6b7280",
              textDecoration: "none",
              fontWeight: "700",
              fontSize: "14px",
            }}
          >
            Back to Wishlist
          </Link>
        </div>
      </header>

      <section
        style={{
          maxWidth: "700px",
          margin: "0 auto",
          padding: "60px 30px 90px",
        }}
      >
        <div
          style={{
            marginBottom: "30px",
          }}
        >
          <div
            style={{
              color: "#2563eb",
              fontSize: "13px",
              fontWeight: "800",
              marginBottom: "8px",
            }}
          >
            {activeWishlist.title}
          </div>

          <h1
            style={{
              margin: 0,
              fontSize: "38px",
              fontWeight: "800",
              letterSpacing:
                "-1.5px",
            }}
          >
            Edit Gift
          </h1>

          <p
            style={{
              color: "#6b7280",
              fontSize: "16px",
              lineHeight: "1.6",
              marginTop: "10px",
              marginBottom: 0,
            }}
          >
            Update the gift information
            below.
          </p>
        </div>

        <form
          action={updateGift}
          style={{
            background: "#ffffff",
            border:
              "1px solid #e5e7eb",
            borderRadius: "20px",
            padding: "30px",
            boxShadow:
              "0 15px 40px rgba(0,0,0,0.06)",
          }}
        >
          <label
            style={{
              display: "block",
              fontSize: "14px",
              fontWeight: "800",
              marginBottom: "8px",
            }}
          >
            Gift Link
          </label>

          <input
            name="productUrl"
            type="text"
            inputMode="url"
            required
            defaultValue={
              activeGift.product_url
            }
            placeholder="Paste a link from Amazon or another store"
            style={{
              width: "100%",
              boxSizing:
                "border-box",
              border:
                "1px solid #d1d5db",
              borderRadius: "11px",
              padding: "14px 16px",
              fontSize: "16px",
              outline: "none",
              marginBottom: "24px",
            }}
          />

          {activeGift.image_url && (
            <div
              style={{
                width: "100%",
                height: "260px",
                background:
                  "#f8fafc",
                border:
                  "1px solid #e5e7eb",
                borderRadius: "16px",
                overflow: "hidden",
                display: "flex",
                alignItems:
                  "center",
                justifyContent:
                  "center",
                marginBottom: "24px",
              }}
            >
              <img
                src={
                  activeGift.image_url
                }
                alt={activeGift.name}
                style={{
                  width: "100%",
                  height: "100%",
                  objectFit:
                    "contain",
                }}
              />
            </div>
          )}

          <label
            style={{
              display: "block",
              fontSize: "14px",
              fontWeight: "800",
              marginBottom: "8px",
            }}
          >
            Image Link
          </label>

          <input
            name="imageUrl"
            type="text"
            inputMode="url"
            defaultValue={
              activeGift.image_url ||
              ""
            }
            placeholder="https://..."
            style={{
              width: "100%",
              boxSizing:
                "border-box",
              border:
                "1px solid #d1d5db",
              borderRadius: "11px",
              padding: "14px 16px",
              fontSize: "16px",
              outline: "none",
              marginBottom: "24px",
            }}
          />

          <label
            style={{
              display: "block",
              fontSize: "14px",
              fontWeight: "800",
              marginBottom: "8px",
            }}
          >
            Gift Name
          </label>

          <input
            name="name"
            required
            maxLength={120}
            defaultValue={
              activeGift.name
            }
            placeholder="Gift name"
            style={{
              width: "100%",
              boxSizing:
                "border-box",
              border:
                "1px solid #d1d5db",
              borderRadius: "11px",
              padding: "14px 16px",
              fontSize: "16px",
              outline: "none",
              marginBottom: "24px",
            }}
          />

          <label
            style={{
              display: "block",
              fontSize: "14px",
              fontWeight: "800",
              marginBottom: "8px",
            }}
          >
            Price
          </label>

          <div
            style={{
              position: "relative",
              marginBottom: "24px",
            }}
          >
            <span
              style={{
                position:
                  "absolute",
                left: "16px",
                top: "50%",
                transform:
                  "translateY(-50%)",
                color: "#6b7280",
                fontWeight: "700",
              }}
            >
              $
            </span>

            <input
              name="price"
              type="number"
              inputMode="decimal"
              min="0"
              step="0.01"
              defaultValue={
                activeGift.price ??
                ""
              }
              placeholder="49.99"
              style={{
                width: "100%",
                boxSizing:
                  "border-box",
                border:
                  "1px solid #d1d5db",
                borderRadius:
                  "11px",
                padding:
                  "14px 16px 14px 34px",
                fontSize: "16px",
                outline: "none",
              }}
            />
          </div>

          <label
            style={{
              display: "block",
              fontSize: "14px",
              fontWeight: "800",
              marginBottom: "8px",
            }}
          >
            Description
          </label>

          <textarea
            name="description"
            maxLength={1000}
            rows={4}
            defaultValue={
              activeGift.description ||
              ""
            }
            placeholder="Tell people a little about this gift."
            style={{
              width: "100%",
              boxSizing:
                "border-box",
              border:
                "1px solid #d1d5db",
              borderRadius: "11px",
              padding: "14px 16px",
              fontSize: "16px",
              fontFamily: "inherit",
              resize: "vertical",
              outline: "none",
              marginBottom: "24px",
            }}
          />

          <label
            style={{
              display: "block",
              fontSize: "14px",
              fontWeight: "800",
              marginBottom: "8px",
            }}
          >
            Instructions
          </label>

          <textarea
            name="instructions"
            maxLength={1000}
            rows={4}
            defaultValue={
              activeGift.instructions ||
              ""
            }
            placeholder="Example: Please choose the large size."
            style={{
              width: "100%",
              boxSizing:
                "border-box",
              border:
                "1px solid #d1d5db",
              borderRadius: "11px",
              padding: "14px 16px",
              fontSize: "16px",
              fontFamily: "inherit",
              resize: "vertical",
              outline: "none",
              marginBottom:
                errorMessage
                  ? "12px"
                  : "24px",
            }}
          />

          <label
            htmlFor="shippingAddress"
            style={{ display: "block", fontSize: "14px", fontWeight: "800", marginBottom: "8px" }}
          >
            Shipping Address or Delivery Instructions <span aria-hidden="true" style={{ color: "#dc2626" }}>*</span>
          </label>
          <textarea
            id="shippingAddress"
            name="shippingAddress"
            required
            maxLength={500}
            rows={3}
            defaultValue={activeGift.shipping_address || ""}
            placeholder={'Enter the mailing address, or for a digital gift card: "Email me this gift card."'}
            autoComplete="street-address"
            style={{
              width: "100%",
              boxSizing: "border-box",
              border: "1px solid #d1d5db",
              borderRadius: "11px",
              padding: "14px 16px",
              fontSize: "16px",
              fontFamily: "inherit",
              resize: "vertical",
              outline: "none",
              marginBottom: errorMessage ? "12px" : "8px",
            }}
          />
          <div style={{ color: "#6b7280", fontSize: "12px", lineHeight: "1.5", marginBottom: "24px" }}>
            Required for each gift. Viewers see these details before reserving, not afterward.
          </div>

          {errorMessage && (
            <div
              style={{
                background:
                  "#fef2f2",
                border:
                  "1px solid #fecaca",
                color: "#b91c1c",
                borderRadius: "11px",
                padding: "13px 14px",
                fontSize: "14px",
                fontWeight: "700",
                marginBottom: "18px",
              }}
            >
              {errorMessage}
            </div>
          )}

          <button
            type="submit"
            style={{
              width: "100%",
              background: "#2563eb",
              color: "#ffffff",
              border: "none",
              borderRadius: "11px",
              padding: "15px 18px",
              fontSize: "16px",
              fontWeight: "800",
              cursor: "pointer",
            }}
          >
            Save Changes
          </button>
        </form>
      </section>
    </main>
  );
}
