import { NextResponse } from "next/server";
import { createClient } from "../../../lib/supabase/server";

function getSafeNextPath(value: string | null) {
  if (!value) {
    return "/dashboard";
  }

  if (
    !value.startsWith("/") ||
    value.startsWith("//") ||
    value.includes("\\")
  ) {
    return "/dashboard";
  }

  return value;
}

function getLoginErrorUrl(
  origin: string,
  next: string
) {
  const url = new URL("/login", origin);

  url.searchParams.set(
    "error",
    "auth"
  );

  if (next !== "/dashboard") {
    url.searchParams.set(
      "next",
      next
    );
  }

  return url;
}

export async function GET(
  request: Request
) {
  const requestUrl =
    new URL(request.url);

  const origin =
    requestUrl.origin;

  const code =
    requestUrl.searchParams.get(
      "code"
    );

  const next =
    getSafeNextPath(
      requestUrl.searchParams.get(
        "next"
      )
    );

  if (!code) {
    return NextResponse.redirect(
      getLoginErrorUrl(
        origin,
        next
      )
    );
  }

  const supabase =
    await createClient();

  const { error } =
    await supabase.auth.exchangeCodeForSession(
      code
    );

  if (error) {
    console.error(
      "Google authentication error:",
      error
    );

    return NextResponse.redirect(
      getLoginErrorUrl(
        origin,
        next
      )
    );
  }

  return NextResponse.redirect(
    new URL(
      next,
      origin
    )
  );
}
