import { NextResponse } from "next/server";
import { createClient } from "../../../lib/supabase/server";

function normalizeHttpUrl(value: string) {
  const trimmed = value.trim();

  if (!trimmed) {
    return "";
  }

  if (/^https?:\/\//i.test(trimmed)) {
    return trimmed;
  }

  return `https://${trimmed}`;
}

function isValidHttpUrl(value: string) {
  try {
    const url = new URL(value);

    return (
      url.protocol === "http:" ||
      url.protocol === "https:"
    );
  } catch {
    return false;
  }
}

function isAllowedLocalImagePath(value: string) {
  // Only allow simple filenames from the app's public /icons folder. This
  // permits local fallbacks without accepting protocol-relative/external paths.
  return /^\/icons\/[A-Za-z0-9._-]+\.(?:png|jpe?g|webp|svg)$/i.test(value);
}

function normalizeImageUrl(value: string) {
  const trimmed = value.trim();
  if (!trimmed) return "";
  if (isAllowedLocalImagePath(trimmed)) return trimmed;
  return normalizeHttpUrl(trimmed);
}

function isValidImageUrl(value: string) {
  return isAllowedLocalImagePath(value) || isValidHttpUrl(value);
}

export async function POST(request: Request) {
  const supabase = await createClient();

  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser();

  if (userError || !user) {
    return NextResponse.json(
      {
        error: "You must be logged in to add a gift.",
      },
      {
        status: 401,
      }
    );
  }

  const body = await request.json().catch(() => null);

  const wishlistId =
    body && typeof body.wishlistId === "string"
      ? body.wishlistId.trim()
      : "";

  const rawProductUrl =
    body && typeof body.productUrl === "string"
      ? body.productUrl.trim()
      : "";

  const productUrl = normalizeHttpUrl(rawProductUrl);

  const name =
    body && typeof body.name === "string"
      ? body.name.trim()
      : "";

  const rawImageUrl =
    body && typeof body.imageUrl === "string"
      ? body.imageUrl.trim()
      : "";

  const imageUrl = rawImageUrl
    ? normalizeImageUrl(rawImageUrl)
    : "";

  const priceValue =
    body && typeof body.price === "string"
      ? body.price.trim()
      : "";

  const description =
    body && typeof body.description === "string"
      ? body.description.trim()
      : "";


  const instructions =
    body && typeof body.instructions === "string"
      ? body.instructions.trim()
      : "";

  const shippingAddress =
    body && typeof body.shippingAddress === "string"
      ? body.shippingAddress.trim()
      : "";

  if (!wishlistId) {
    return NextResponse.json(
      {
        error: "Wishlist is missing.",
      },
      {
        status: 400,
      }
    );
  }

  if (
    !productUrl ||
    !isValidHttpUrl(productUrl)
  ) {
    return NextResponse.json(
      {
        error: "Enter a valid store link.",
      },
      {
        status: 400,
      }
    );
  }

  if (!name) {
    return NextResponse.json(
      {
        error: "Enter a Gift Name.",
      },
      {
        status: 400,
      }
    );
  }

  if (!shippingAddress) {
    return NextResponse.json(
      { error: "Enter a shipping address or delivery instructions for this gift." },
      { status: 400 }
    );
  }

  if (shippingAddress.length > 500) {
    return NextResponse.json(
      { error: "Shipping or delivery details must be 500 characters or fewer." },
      { status: 400 }
    );
  }

  if (name.length > 120) {
    return NextResponse.json(
      {
        error: "Gift Name is too long.",
      },
      {
        status: 400,
      }
    );
  }

  if (
    imageUrl &&
    !isValidImageUrl(imageUrl)
  ) {
    return NextResponse.json(
      {
        error: "Enter a valid Image Link.",
      },
      {
        status: 400,
      }
    );
  }

  let price: number | null = null;

  if (priceValue) {
    const parsedPrice = Number(priceValue);

    if (
      !Number.isFinite(parsedPrice) ||
      parsedPrice < 0 ||
      parsedPrice > 99999999.99
    ) {
      return NextResponse.json(
        {
          error: "Enter a valid price.",
        },
        {
          status: 400,
        }
      );
    }

    price =
      Math.round(parsedPrice * 100) / 100;
  }

  const {
    data: wishlist,
    error: wishlistError,
  } = await supabase
    .from("wishlists")
    .select("id, owner_id")
    .eq("id", wishlistId)
    .eq("owner_id", user.id)
    .single();

  if (
    wishlistError ||
    !wishlist
  ) {
    return NextResponse.json(
      {
        error: "Wishlist could not be found.",
      },
      {
        status: 404,
      }
    );
  }

  const { data: gift, error } =
    await supabase
      .from("gifts")
      .insert({
        wishlist_id: wishlist.id,
        owner_id: user.id,
        name,
        product_url: productUrl,
        image_url: imageUrl || null,
        price,
        description:
          description || null,
        instructions:
          instructions || null,
        shipping_address: shippingAddress,
      })
      .select(
        "id, wishlist_id, name, product_url, image_url, price, description, instructions, shipping_address"
      )
      .single();

  if (error) {
    console.error(
      "Add gift error:",
      error
    );

    return NextResponse.json(
      {
        error:
          "Could not add this gift.",
      },
      {
        status: 500,
      }
    );
  }

  return NextResponse.json({
    success: true,
    gift,
  });
}
