import { NextResponse } from "next/server";
import { createAdminClient } from "../../../../lib/supabase/admin";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(
  request: Request
) {
  const cronSecret =
    process.env.CRON_SECRET;

  const authorization =
    request.headers.get(
      "authorization"
    );

  if (
    !cronSecret ||
    authorization !==
      `Bearer ${cronSecret}`
  ) {
    return NextResponse.json(
      {
        error: "Unauthorized",
      },
      {
        status: 401,
      }
    );
  }

  try {
    const admin =
      createAdminClient();

    const {
      error,
    } = await admin.rpc(
      "purge_expired_deleted_data"
    );

    if (error) {
      console.error(
        "Scheduled deleted data purge error:",
        error
      );

      return NextResponse.json(
        {
          success: false,
          error:
            "Deleted data cleanup failed.",
        },
        {
          status: 500,
        }
      );
    }

    return NextResponse.json({
      success: true,
    });
  } catch (error) {
    console.error(
      "Scheduled deleted data purge error:",
      error
    );

    return NextResponse.json(
      {
        success: false,
        error:
          "Deleted data cleanup failed.",
      },
      {
        status: 500,
      }
    );
  }
}
