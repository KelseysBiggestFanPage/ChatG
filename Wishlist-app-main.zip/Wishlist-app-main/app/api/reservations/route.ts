import {
  createHmac,
  randomInt,
} from "crypto";
import {
  cookies,
  headers,
} from "next/headers";
import { NextResponse } from "next/server";
import { createAdminClient } from "../../../lib/supabase/admin";
import { createClient } from "../../../lib/supabase/server";
import { containsBlockedLanguage } from "../../../lib/name-filter";
import {
  createWishlistAccessToken,
  getWishlistAccessCookieName,
} from "../../../lib/wishlist-access";

export const runtime = "nodejs";

function validEmail(value: string) {
  if (!value) {
    return true;
  }

  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
    value
  );
}

function validPhone(value: string) {
  if (!value) {
    return true;
  }

  const numbers =
    value.replace(/\D/g, "");

  return (
    numbers.length >= 7 &&
    numbers.length <= 15
  );
}


function createVisitorKey(
  ipAddress: string
) {
  const secret =
    process.env.SUPABASE_SECRET_KEY;

  if (!secret) {
    throw new Error(
      "SUPABASE_SECRET_KEY is missing."
    );
  }

  return createHmac(
    "sha256",
    secret
  )
    .update(ipAddress)
    .digest("hex");
}

export async function POST(
  request: Request
) {
  const body =
    await request
      .json()
      .catch(() => null);

  const giftId =
    body &&
    typeof body.giftId ===
      "string"
      ? body.giftId.trim()
      : "";

  const wishlistSlug =
    body &&
    typeof body.wishlistSlug ===
      "string"
      ? body.wishlistSlug.trim()
      : "";

  const reserverName =
    body &&
    typeof body.name ===
      "string"
      ? body.name
          .trim()
          .replace(/\s+/g, " ")
      : "";

  const reserverEmail =
    body &&
    typeof body.email ===
      "string"
      ? body.email
          .trim()
          .toLowerCase()
      : "";

  const reserverPhone =
    body &&
    typeof body.phone ===
      "string"
      ? body.phone.trim()
      : "";

  const contactMethod =
    body && (body.contactMethod === "email" || body.contactMethod === "phone")
      ? body.contactMethod
      : "";

  if (
    !giftId ||
    !wishlistSlug
  ) {
    return NextResponse.json(
      {
        error:
          "Gift information is missing.",
      },
      {
        status: 400,
      }
    );
  }

  if (
    reserverName.length < 2 ||
    reserverName.length > 80
  ) {
    return NextResponse.json(
      {
        error:
          "Enter a valid name.",
      },
      {
        status: 400,
      }
    );
  }

  if (
    containsBlockedLanguage(
      reserverName
    )
  ) {
    return NextResponse.json(
      {
        error:
          "Please enter an appropriate name.",
      },
      {
        status: 400,
      }
    );
  }

  if (contactMethod !== "email" && contactMethod !== "phone") {
    return NextResponse.json(
      { error: "Choose email or phone as your contact method." },
      { status: 400 }
    );
  }

  if (contactMethod === "email" && !reserverEmail) {
    return NextResponse.json(
      { error: "Enter an email address so the owner can contact you." },
      { status: 400 }
    );
  }

  if (contactMethod === "phone" && !reserverPhone) {
    return NextResponse.json(
      { error: "Enter a phone number so the owner can contact you." },
      { status: 400 }
    );
  }

  if (contactMethod === "email" && !validEmail(reserverEmail)) {
    return NextResponse.json(
      { error: "Enter a valid email address." },
      { status: 400 }
    );
  }

  if (contactMethod === "phone" && !validPhone(reserverPhone)) {
    return NextResponse.json(
      { error: "Enter a valid phone number." },
      { status: 400 }
    );
  }

  if (
    reserverEmail.length >
    120
  ) {
    return NextResponse.json(
      {
        error:
          "Email address is too long.",
      },
      {
        status: 400,
      }
    );
  }

  if (
    reserverPhone.length >
    25
  ) {
    return NextResponse.json(
      {
        error:
          "Phone number is too long.",
      },
      {
        status: 400,
      }
    );
  }

  const admin =
    createAdminClient();

  const requestHeaders =
    await headers();

  const forwardedAddresses =
    requestHeaders
      .get("x-forwarded-for")
      ?.split(",")
      .map((value) => value.trim())
      .filter(Boolean) || [];

  // Prefer the hosting proxy's direct client IP. The first value in
  // x-forwarded-for may be supplied by the incoming request, so only use
  // the rightmost forwarded address as a fallback.
  const ipAddress =
    requestHeaders.get("x-real-ip")?.trim() ||
    requestHeaders.get("cf-connecting-ip")?.trim() ||
    forwardedAddresses[forwardedAddresses.length - 1] ||
    "unknown";

  let visitorKey = "";

  try {
    visitorKey =
      createVisitorKey(
        ipAddress
      );
  } catch (error) {
    console.error(
      "Reservation visitor key error:",
      error
    );

    return NextResponse.json(
      {
        error:
          "We could not process this reservation right now. Please try again shortly.",
      },
      {
        status: 503,
      }
    );
  }

  const {
    data: rateLimitAllowed,
    error: rateLimitError,
  } = await admin.rpc(
    "check_reservation_rate_limit",
    {
      p_visitor_key:
        visitorKey,
      p_limit: 30,
      p_window_seconds: 600,
    }
  );

  if (rateLimitError) {
    console.error(
      "Reservation rate limit error:",
      rateLimitError
    );

    return NextResponse.json(
      {
        error:
          "We could not process this reservation right now. Please try again shortly.",
      },
      {
        status: 503,
      }
    );
  }

  if (!rateLimitAllowed) {
    return NextResponse.json(
      {
        error:
          "Too many reservation attempts. Please wait a few minutes and try again.",
      },
      {
        status: 429,
        headers: {
          "Retry-After": "600",
        },
      }
    );
  }

  const supabase =
    await createClient();

  const {
    data: { user },
  } =
    await supabase.auth.getUser();

  const {
    data: wishlist,
    error: wishlistError,
  } = await admin
    .from("wishlists")
    .select(
      "id, owner_id, slug, is_live, access_code_hash"
    )
    .eq(
      "slug",
      wishlistSlug.toLowerCase()
    )
    .eq(
      "is_live",
      true
    )
    .single();

  if (
    wishlistError ||
    !wishlist
  ) {
    return NextResponse.json(
      {
        error:
          "This wishlist is not available.",
      },
      {
        status: 404,
      }
    );
  }

  const isOwner =
    Boolean(user) &&
    user?.id ===
      wishlist.owner_id;

  if (
    wishlist.access_code_hash &&
    !isOwner
  ) {
    const cookieStore =
      await cookies();

    const currentToken =
      cookieStore.get(
        getWishlistAccessCookieName(
          wishlist.id
        )
      )?.value || "";

    const expectedToken =
      createWishlistAccessToken(
        wishlist.id,
        wishlist.access_code_hash
      );

    if (
      currentToken !==
      expectedToken
    ) {
      return NextResponse.json(
        {
          error:
            "Enter the wishlist access code before reserving a gift.",
        },
        {
          status: 403,
        }
      );
    }
  }

  const {
    data: gift,
    error: giftError,
  } = await admin
    .from("gifts")
    .select(
      "id, wishlist_id, shipping_address"
    )
    .eq(
      "id",
      giftId
    )
    .eq(
      "wishlist_id",
      wishlist.id
    )
    .single();

  if (
    giftError ||
    !gift
  ) {
    return NextResponse.json(
      {
        error:
          "This gift could not be found.",
      },
      {
        status: 404,
      }
    );
  }

  if (!gift.shipping_address || !gift.shipping_address.trim()) {
    return NextResponse.json(
      { error: "This gift needs a shipping address or delivery instructions before it can be reserved. Please contact the wishlist owner." },
      { status: 400 }
    );
  }

  const {
    data:
      existingReservation,
  } = await admin
    .from("reservations")
    .select("id")
    .eq(
      "gift_id",
      gift.id
    )
    .maybeSingle();

  if (
    existingReservation
  ) {
    return NextResponse.json(
      {
        error:
          "Someone else already reserved this gift.",
      },
      {
        status: 409,
      }
    );
  }


  const {
    data: reservation,
    error,
  } = await admin
    .from("reservations")
    .insert({
      gift_id:
        gift.id,
      wishlist_id:
        wishlist.id,
      reserver_user_id:
        user?.id || null,
      reserver_name:
        reserverName,
      reserver_email:
        contactMethod === "email" ? reserverEmail : null,
      reserver_phone:
        contactMethod === "phone" ? reserverPhone : null,
    })
    .select("id")
    .single();

  if (error) {
    if (
      error.code ===
      "23505"
    ) {
      return NextResponse.json(
        {
          error:
            "Someone else already reserved this gift.",
        },
        {
          status: 409,
        }
      );
    }

    console.error(
      "Create reservation error:",
      error
    );

    return NextResponse.json(
      {
        error:
          "Could not reserve this gift. Please try again.",
      },
      {
        status: 500,
      }
    );
  }

  return NextResponse.json({
    success: true,
    reservationId:
      reservation.id,
  });
}
