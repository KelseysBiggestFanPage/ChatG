import { randomBytes, scryptSync } from "crypto";
import { NextResponse } from "next/server";
import { createClient } from "../../../lib/supabase/server";

export const runtime = "nodejs";

function cleanSlug(value: string) {
  return value
    .toLowerCase()
    .trim()
    .replace(/['’]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function hashAccessCode(code: string) {
  const salt = randomBytes(16);
  const hash = scryptSync(code, salt, 64);

  return `scrypt$${salt.toString("hex")}$${hash.toString("hex")}`;
}

export async function POST(request: Request) {
  const supabase = await createClient();

  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser();

  if (userError || !user) {
    return NextResponse.json(
      {
        error: "You must be logged in to create a wishlist.",
      },
      {
        status: 401,
      }
    );
  }

  const body = await request.json().catch(() => null);

  const title =
    body && typeof body.title === "string"
      ? body.title.trim()
      : "";

  const rawSlug =
    body && typeof body.slug === "string"
      ? body.slug
      : "";

  const accessCode =
    body && typeof body.accessCode === "string"
      ? body.accessCode.trim()
      : "";

  const slug = cleanSlug(rawSlug);

  if (!title) {
    return NextResponse.json(
      {
        error: "Enter a Wishlist Name.",
      },
      {
        status: 400,
      }
    );
  }

  if (title.length > 80) {
    return NextResponse.json(
      {
        error: "Wishlist Name is too long.",
      },
      {
        status: 400,
      }
    );
  }

  if (!slug) {
    return NextResponse.json(
      {
        error: "Choose a valid Wishlist Link.",
      },
      {
        status: 400,
      }
    );
  }

  if (slug.length > 60) {
    return NextResponse.json(
      {
        error: "Wishlist Link is too long.",
      },
      {
        status: 400,
      }
    );
  }

  if (
    accessCode &&
    (!/^[0-9]{4,8}$/.test(accessCode))
  ) {
    return NextResponse.json(
      {
        error: "Access code must be 4–8 numbers.",
      },
      {
        status: 400,
      }
    );
  }

  const accessCodeHash = accessCode
    ? hashAccessCode(accessCode)
    : null;

  const { data, error } = await supabase
    .from("wishlists")
    .insert({
      owner_id: user.id,
      title,
      slug,
      is_live: false,
      access_code_hash: accessCodeHash,
    })
    .select(
      "id, title, slug, is_live, created_at"
    )
    .single();

  if (error) {
    if (error.code === "23505") {
      return NextResponse.json(
        {
          error:
            "That Wishlist Link is already taken. Choose another one.",
        },
        {
          status: 409,
        }
      );
    }

    console.error("Create wishlist error:", error);

    return NextResponse.json(
      {
        error: "Could not create your wishlist.",
      },
      {
        status: 500,
      }
    );
  }

  return NextResponse.json({
    success: true,
    id: data.id,
    title: data.title,
    slug: data.slug,
    isLive: data.is_live,
  });
}
