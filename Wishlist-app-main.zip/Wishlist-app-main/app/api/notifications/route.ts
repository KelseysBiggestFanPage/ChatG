import { NextResponse } from "next/server";
import { createClient } from "../../../lib/supabase/server";

export const runtime = "nodejs";

export async function GET() {
  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json(
      { notifications: [], unreadCount: 0 },
      { status: 401 }
    );
  }

  const [
    { data, error },
    { count: unreadCount, error: unreadCountError },
  ] = await Promise.all([
    supabase
      .from("notifications")
      .select(
        "id, wishlist_id, gift_id, reservation_id, type, title, message, read_at, created_at"
      )
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(25),
    supabase
      .from("notifications")
      .select("id", { count: "exact", head: true })
      .eq("user_id", user.id)
      .is("read_at", null),
  ]);

  if (error || unreadCountError) {
    console.error("Notifications load error:", error || unreadCountError);

    return NextResponse.json(
      { error: "Could not load notifications." },
      { status: 500 }
    );
  }

  return NextResponse.json({
    notifications: data || [],
    unreadCount: unreadCount || 0,
  });
}

export async function POST(request: Request) {
  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json(
      { error: "You must be signed in." },
      { status: 401 }
    );
  }

  const body = await request.json().catch(() => null);
  const action =
    body && typeof body.action === "string"
      ? body.action
      : "";

  if (action === "read_all") {
    const { error } = await supabase
      .from("notifications")
      .update({ read_at: new Date().toISOString() })
      .eq("user_id", user.id)
      .is("read_at", null);

    if (error) {
      console.error("Notifications mark-all-read error:", error);

      return NextResponse.json(
        { error: "Could not mark notifications as read." },
        { status: 500 }
      );
    }

    return NextResponse.json({ success: true, unreadCount: 0 });
  }

  if (action === "read") {
    const id =
      body && typeof body.id === "string"
        ? body.id.trim()
        : "";

    if (!id) {
      return NextResponse.json(
        { error: "Notification ID is missing." },
        { status: 400 }
      );
    }

    const { error } = await supabase
      .from("notifications")
      .update({ read_at: new Date().toISOString() })
      .eq("id", id)
      .eq("user_id", user.id);

    if (error) {
      console.error("Notification mark-read error:", error);

      return NextResponse.json(
        { error: "Could not mark the notification as read." },
        { status: 500 }
      );
    }

    return NextResponse.json({ success: true });
  }

  return NextResponse.json(
    { error: "Unsupported notification action." },
    { status: 400 }
  );
}
