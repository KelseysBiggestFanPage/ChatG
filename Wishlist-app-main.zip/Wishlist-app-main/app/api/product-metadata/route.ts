import { lookup } from "node:dns/promises";
import { request as httpRequest } from "node:http";
import { request as httpsRequest } from "node:https";
import { isIP } from "node:net";
import { checkServerIdentity } from "node:tls";
import { NextResponse } from "next/server";
import { createAdminClient } from "../../../lib/supabase/admin";
import { createClient } from "../../../lib/supabase/server";

export const runtime = "nodejs";

const MAX_PRODUCT_PAGE_BYTES =
  2 * 1024 * 1024;

function normalizeHttpUrl(value: string) {
  const trimmed = value.trim();

  if (!trimmed) {
    return "";
  }

  if (/^https?:\/\//i.test(trimmed)) {
    return trimmed;
  }

  return `https://${trimmed}`;
}

function decodeHtml(value: string) {
  return value
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&#x27;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&nbsp;/g, " ")
    .replace(/\\u0026/g, "&")
    .replace(/\\\//g, "/")
    .trim();
}

function isPrivateIp(address: string) {
  const normalized = address.toLowerCase().replace(/^\[|\]$/g, "").split("%")[0];
  const version = isIP(normalized);

  if (version === 4) {
    const octets = normalized.split(".").map(Number);
    const [a, b, c] = octets;

    return (
      a === 0 ||
      a === 10 ||
      a === 127 ||
      a >= 224 ||
      (a === 100 && b >= 64 && b <= 127) ||
      (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && (b === 0 || b === 168)) ||
      (a === 192 && b === 88 && c === 99) ||
      (a === 192 && b === 0 && c === 2) ||
      (a === 198 && (b === 18 || b === 19)) ||
      (a === 198 && b === 51 && c === 100) ||
      (a === 203 && b === 0 && c === 113)
    );
  }

  if (version === 6) {
    if (normalized === "::" || normalized === "::1") {
      return true;
    }

    // Only permit globally routable unicast space (2000::/3), excluding
    // documentation, 6to4, and Teredo ranges. This rejects mapped IPv4,
    // link-local, multicast, unique-local, and other special-use addresses.
    const firstHextet = Number.parseInt(normalized.split(":")[0] || "0", 16);
    if (firstHextet < 0x2000 || firstHextet > 0x3fff) {
      return true;
    }

    if (
      normalized.startsWith("2001:db8:") ||
      normalized.startsWith("2001:0:") ||
      normalized.startsWith("2002:")
    ) {
      return true;
    }

    return false;
  }

  return true;
}

type ValidatedPublicUrl = {
  url: URL;
  connectAddress: string;
};

async function validatePublicUrl(value: string): Promise<ValidatedPublicUrl> {
  const normalizedValue = normalizeHttpUrl(value);
  let url: URL;

  try {
    url = new URL(normalizedValue);
  } catch {
    throw new Error("Enter a valid product link.");
  }

  if (
    (url.protocol !== "http:" && url.protocol !== "https:") ||
    url.username ||
    url.password
  ) {
    throw new Error("Enter a valid product link.");
  }

  const allowedPort = url.protocol === "https:" ? "443" : "80";
  if (url.port && url.port !== allowedPort) {
    throw new Error("This product link uses a port that is not allowed.");
  }

  const hostname = url.hostname.toLowerCase().replace(/^\[|\]$/g, "");

  if (
    !hostname ||
    hostname === "localhost" ||
    hostname.endsWith(".localhost") ||
    hostname.endsWith(".local") ||
    hostname.endsWith(".internal")
  ) {
    throw new Error("This product link is not allowed.");
  }

  if (isIP(hostname)) {
    if (isPrivateIp(hostname)) {
      throw new Error("This product link is not allowed.");
    }

    return { url, connectAddress: hostname };
  }

  let addresses: Array<{ address: string; family: number }>;
  try {
    addresses = await lookup(hostname, { all: true, verbatim: true });
  } catch {
    throw new Error("We could not resolve that product link.");
  }

  if (
    !addresses.length ||
    addresses.some((item) => isPrivateIp(item.address))
  ) {
    throw new Error("This product link is not allowed.");
  }

  // Carry the checked address forward and connect to it directly, rather than
  // allowing fetch() to perform a second DNS lookup.
  return { url, connectAddress: addresses[0].address };
}

function getMetaContent(
  html: string,
  attribute: string,
  value: string
) {
  const patterns = [
    new RegExp(
      `<meta[^>]+${attribute}=["']${value}["'][^>]+content=["']([^"']+)["'][^>]*>`,
      "i"
    ),
    new RegExp(
      `<meta[^>]+content=["']([^"']+)["'][^>]+${attribute}=["']${value}["'][^>]*>`,
      "i"
    ),
  ];

  for (const pattern of patterns) {
    const match = html.match(pattern);

    if (match?.[1]) {
      return decodeHtml(match[1]);
    }
  }

  return "";
}

function makeAbsoluteUrl(
  value: string,
  baseUrl: string
) {
  if (!value) {
    return "";
  }

  try {
    const cleaned = decodeHtml(value);

    const url = new URL(
      cleaned,
      baseUrl
    );

    if (
      url.protocol !== "http:" &&
      url.protocol !== "https:"
    ) {
      return "";
    }

    return url.toString();
  } catch {
    return "";
  }
}

function addImage(
  images: string[],
  value: unknown,
  baseUrl: string
) {
  if (typeof value === "string") {
    const image = makeAbsoluteUrl(
      value,
      baseUrl
    );

    if (!image) {
      return;
    }

    const lower =
      image.toLowerCase();

    if (
      lower.includes("sprite") ||
      lower.includes("pixel") ||
      lower.includes("spacer")
    ) {
      return;
    }

    if (!images.includes(image)) {
      images.push(image);
    }

    return;
  }

  if (Array.isArray(value)) {
    value.forEach((item) =>
      addImage(
        images,
        item,
        baseUrl
      )
    );

    return;
  }

  if (
    value &&
    typeof value === "object"
  ) {
    const object =
      value as Record<
        string,
        unknown
      >;

    addImage(
      images,
      object.url,
      baseUrl
    );

    addImage(
      images,
      object.contentUrl,
      baseUrl
    );
  }
}

function inspectJsonLd(
  value: unknown,
  result: {
    title: string;
    price: string;
    images: string[];
  },
  baseUrl: string
) {
  if (Array.isArray(value)) {
    value.forEach((item) =>
      inspectJsonLd(
        item,
        result,
        baseUrl
      )
    );

    return;
  }

  if (
    !value ||
    typeof value !== "object"
  ) {
    return;
  }

  const object =
    value as Record<
      string,
      unknown
    >;

  const type = object["@type"];

  const types = Array.isArray(type)
    ? type.map(String)
    : [String(type || "")];

  const productLike =
    types.some((item) =>
      item
        .toLowerCase()
        .includes("product")
    );

  if (productLike) {
    if (
      !result.title &&
      typeof object.name ===
        "string"
    ) {
      result.title =
        decodeHtml(object.name);
    }

    addImage(
      result.images,
      object.image,
      baseUrl
    );

    const offers =
      object.offers;

    if (
      offers &&
      typeof offers === "object"
    ) {
      if (Array.isArray(offers)) {
        for (const offer of offers) {
          if (
            offer &&
            typeof offer ===
              "object" &&
            !result.price
          ) {
            const offerObject =
              offer as Record<
                string,
                unknown
              >;

            if (
              typeof offerObject.price ===
                "string" ||
              typeof offerObject.price ===
                "number"
            ) {
              result.price =
                String(
                  offerObject.price
                );
            }
          }
        }
      } else {
        const offerObject =
          offers as Record<
            string,
            unknown
          >;

        if (
          typeof offerObject.price ===
            "string" ||
          typeof offerObject.price ===
            "number"
        ) {
          result.price =
            String(
              offerObject.price
            );
        }
      }
    }
  }

  for (
    const nested of
    Object.values(object)
  ) {
    if (
      nested &&
      (Array.isArray(nested) ||
        typeof nested ===
          "object")
    ) {
      inspectJsonLd(
        nested,
        result,
        baseUrl
      );
    }
  }
}

function extractJsonLd(
  html: string,
  result: {
    title: string;
    price: string;
    images: string[];
  },
  baseUrl: string
) {
  const pattern =
    /<script[^>]+type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi;

  let match;

  while (
    (match =
      pattern.exec(html)) !== null
  ) {
    const content =
      match[1]?.trim();

    if (!content) {
      continue;
    }

    try {
      const parsed =
        JSON.parse(content);

      inspectJsonLd(
        parsed,
        result,
        baseUrl
      );
    } catch {}
  }
}

function getHtmlAttribute(tag: string, attributeName: string) {
  const escapedName = attributeName.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const pattern = new RegExp(`\\b${escapedName}\\s*=\\s*([\"'])([\\s\\S]*?)\\1`, "i");
  return tag.match(pattern)?.[2] || "";
}

function extractAmazonImages(
  html: string,
  images: string[],
  baseUrl: string
) {
  // Amazon includes large product photos in JSON embedded in the HTML.
  // Try these common fields first; if Amazon changes its page format, the
  // UI still has the official favicon fallback.
  const patterns = [
    /"hiRes"\s*:\s*"((?:\\.|[^"\\])+)"/gi,
    /"large"\s*:\s*"((?:\\.|[^"\\])+)"/gi,
    /"mainUrl"\s*:\s*"((?:\\.|[^"\\])+)"/gi,
    /"landingImageUrl"\s*:\s*"((?:\\.|[^"\\])+)"/gi,
    /data-old-hires=["']([^"']+)["']/gi,
  ];

  for (const pattern of patterns) {
    let match;
    while ((match = pattern.exec(html)) !== null) {
      if (match[1]) addImage(images, match[1], baseUrl);
    }
  }

  // Read the main product image's src/srcset data, including Amazon's
  // data-a-dynamic-image JSON map which contains image URLs at several sizes.
  const mainImageTags = html.match(
    /<img\b[^>]*(?:id|data-a-image-name)\s*=\s*["'](?:landingImage|main-image|mainImage)["'][^>]*>/gi
  ) || [];

  for (const tag of mainImageTags) {
    for (const attribute of ["data-old-hires", "src", "data-src"]) {
      const value = getHtmlAttribute(tag, attribute);
      if (value) addImage(images, value, baseUrl);
    }

    const dynamicImageValue = getHtmlAttribute(tag, "data-a-dynamic-image");
    if (dynamicImageValue) {
      try {
        const decoded = decodeHtml(dynamicImageValue)
          .replace(/&quot;/gi, '"')
          .replace(/&#34;/gi, '"');
        const imageMap = JSON.parse(decoded) as Record<string, unknown>;
        for (const imageUrl of Object.keys(imageMap)) {
          addImage(images, imageUrl, baseUrl);
        }
      } catch {
        // Malformed or changed Amazon image metadata is handled by fallback.
      }
    }
  }

  // Support embedded JSON image maps even if the landing image tag is missing.
  const dynamicImagePattern = /data-a-dynamic-image=["']([^"']+)["']/gi;
  let dynamicMatch;
  while ((dynamicMatch = dynamicImagePattern.exec(html)) !== null) {
    try {
      const decoded = decodeHtml(dynamicMatch[1])
        .replace(/&quot;/gi, '"')
        .replace(/&#34;/gi, '"');
      const imageMap = JSON.parse(decoded) as Record<string, unknown>;
      for (const imageUrl of Object.keys(imageMap)) {
        addImage(images, imageUrl, baseUrl);
      }
    } catch {
      // Ignore non-JSON values and let the favicon fallback handle the page.
    }
  }
}

function extractFavicon(
  html: string,
  baseUrl: string
) {
  const patterns = [
    /<link[^>]+rel=["'][^"']*apple-touch-icon[^"']*["'][^>]+href=["']([^"']+)["'][^>]*>/i,
    /<link[^>]+href=["']([^"']+)["'][^>]+rel=["'][^"']*apple-touch-icon[^"']*["'][^>]*>/i,
    /<link[^>]+rel=["'][^"']*(?:shortcut\s+icon|icon)[^"']*["'][^>]+href=["']([^"']+)["'][^>]*>/i,
    /<link[^>]+href=["']([^"']+)["'][^>]+rel=["'][^"']*(?:shortcut\s+icon|icon)[^"']*["'][^>]*>/i,
  ];

  for (const pattern of patterns) {
    const match =
      html.match(pattern);

    if (match?.[1]) {
      const favicon =
        makeAbsoluteUrl(
          match[1],
          baseUrl
        );

      if (favicon) {
        return favicon;
      }
    }
  }

  try {
    const url =
      new URL(baseUrl);

    return `${url.origin}/favicon.ico`;
  } catch {
    return "";
  }
}

type PinnedPageResponse = {
  statusCode: number;
  headers: import("node:http").IncomingHttpHeaders;
  body: string;
};

async function requestPinnedProductPage(
  validated: ValidatedPublicUrl
): Promise<PinnedPageResponse> {
  const { url, connectAddress } = validated;
  const originalHostname = url.hostname.replace(/^\[|\]$/g, "");
  const secure = url.protocol === "https:";
  const port = Number(url.port || (secure ? 443 : 80));
  const path = `${url.pathname || "/"}${url.search}`;
  const requestHeaders = {
    Host: url.host,
    "User-Agent":
      "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/140.0 Safari/537.36",
    Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    Connection: "close",
  };

  return new Promise((resolve, reject) => {
    let settled = false;
    const fail = (error: Error) => {
      if (!settled) {
        settled = true;
        reject(error);
      }
    };

    const onResponse = (response: import("node:http").IncomingMessage) => {
      const statusCode = response.statusCode || 0;
      const contentLength = Number(response.headers["content-length"] || 0);
      if (Number.isFinite(contentLength) && contentLength > MAX_PRODUCT_PAGE_BYTES) {
        response.destroy();
        request.destroy(new Error("That product page is too large to read."));
        return;
      }

      const chunks: Buffer[] = [];
      let totalBytes = 0;
      response.on("data", (chunk: Buffer | string) => {
        const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
        totalBytes += buffer.byteLength;
        if (totalBytes > MAX_PRODUCT_PAGE_BYTES) {
          response.destroy();
          request.destroy(new Error("That product page is too large to read."));
          return;
        }
        chunks.push(buffer);
      });
      response.on("end", () => {
        if (settled) return;
        settled = true;
        resolve({
          statusCode,
          headers: response.headers,
          body: Buffer.concat(chunks).toString("utf8"),
        });
      });
      response.on("error", (error: Error) => fail(error));
    };

    const baseOptions = {
      hostname: connectAddress,
      family: isIP(connectAddress),
      port,
      path,
      method: "GET",
      headers: requestHeaders,
      agent: false as const,
    };

    const request = secure
      ? httpsRequest(
          {
            ...baseOptions,
            servername: isIP(originalHostname) ? undefined : originalHostname,
            checkServerIdentity: (_serverName, certificate) =>
              checkServerIdentity(originalHostname, certificate),
          },
          onResponse
        )
      : httpRequest(baseOptions, onResponse);

    request.setTimeout(10_000, () => {
      request.destroy(new Error("The product page took too long to respond."));
    });
    request.on("error", (error: Error) => fail(error));
    request.end();
  });
}

async function fetchProductPage(initialUrl: string) {
  let current = await validatePublicUrl(initialUrl);

  for (let redirectCount = 0; redirectCount < 4; redirectCount++) {
    const response = await requestPinnedProductPage(current);

    if (response.statusCode >= 300 && response.statusCode < 400) {
      const location = response.headers.location;
      if (!location) {
        throw new Error("The store did not return a valid product page.");
      }

      const redirectedUrl = new URL(location, current.url).toString();
      current = await validatePublicUrl(redirectedUrl);
      continue;
    }

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw new Error("We could not read that product page.");
    }

    const contentType = response.headers["content-type"];
    const contentTypeValue = Array.isArray(contentType)
      ? contentType.join(" ")
      : contentType || "";

    if (!contentTypeValue.toLowerCase().includes("text/html")) {
      throw new Error("That link does not appear to be a product page.");
    }

    return {
      html: response.body,
      finalUrl: current.url.toString(),
    };
  }

  throw new Error("The product link redirected too many times.");
}

export async function POST(
  request: Request
) {
  const supabase =
    await createClient();

  const {
    data: { user },
  } =
    await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json(
      {
        error:
          "You must be logged in.",
      },
      {
        status: 401,
      }
    );
  }

  const admin =
    createAdminClient();

  const {
    data: rateLimitAllowed,
    error: rateLimitError,
  } = await admin.rpc(
    "check_product_metadata_rate_limit",
    {
      p_user_id: user.id,
      p_limit: 30,
      p_window_seconds: 60,
    }
  );

  if (rateLimitError) {
    console.error(
      "Product metadata rate limit error:",
      rateLimitError
    );

    return NextResponse.json(
      {
        error:
          "We could not process that product link right now. Please try again shortly.",
      },
      {
        status: 503,
      }
    );
  }

  if (!rateLimitAllowed) {
    return NextResponse.json(
      {
        error:
          "Too many product-link requests. Please wait a minute and try again.",
      },
      {
        status: 429,
        headers: {
          "Retry-After": "60",
        },
      }
    );
  }

  const body =
    await request
      .json()
      .catch(() => null);

  const rawProductUrl =
    body &&
    typeof body.url === "string"
      ? body.url.trim()
      : "";

  if (!rawProductUrl) {
    return NextResponse.json(
      {
        error:
          "Paste a product link first.",
      },
      {
        status: 400,
      }
    );
  }

  const productUrl =
    normalizeHttpUrl(
      rawProductUrl
    );

  try {
    const {
      html,
      finalUrl,
    } =
      await fetchProductPage(
        productUrl
      );

    const result = {
      title: "",
      price: "",
      images: [] as string[],
    };

    result.title =
      getMetaContent(
        html,
        "property",
        "og:title"
      ) ||
      getMetaContent(
        html,
        "name",
        "twitter:title"
      );

    result.price =
      getMetaContent(
        html,
        "property",
        "product:price:amount"
      ) ||
      getMetaContent(
        html,
        "property",
        "og:price:amount"
      );

    addImage(
      result.images,
      getMetaContent(
        html,
        "property",
        "og:image"
      ),
      finalUrl
    );

    addImage(
      result.images,
      getMetaContent(
        html,
        "name",
        "twitter:image"
      ),
      finalUrl
    );

    extractJsonLd(
      html,
      result,
      finalUrl
    );

    extractAmazonImages(
      html,
      result.images,
      finalUrl
    );

    result.images =
      result.images.slice(0, 12);

    const favicon =
      extractFavicon(
        html,
        finalUrl
      );

    const usedFavicon =
      result.images.length === 0;

    if (
      usedFavicon &&
      favicon
    ) {
      result.images = [
        favicon,
      ];
    }

    return NextResponse.json({
      success: true,
      title: result.title,
      price: result.price,
      images: result.images,
      favicon,
      usedFavicon,
      productUrl: finalUrl,
    });
  } catch (error) {
    const message =
      error instanceof Error
        ? error.message
        : "We could not read that product page.";

    return NextResponse.json(
      {
        error: message,
      },
      {
        status: 400,
      }
    );
  }
}
